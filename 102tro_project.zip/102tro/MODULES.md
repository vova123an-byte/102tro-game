# Модулі гри

Код розбито на модулі в `src/<категорія>/`. Номер у назві файлу — порядок збирання.
Збирання: `python3 tools/build.py --pwa www/index.html` (без `--pwa` — версія для Claude Artifact).
Перевірено: зібраний із модулів файл байт-у-байт збігається з робочою грою.

## Game Core — ядро: утиліти, рендер Three.js, стан, аудіо, ігровий цикл, логіка гравця й авто, запуск
- `src/core/01_header.js` (8 рядків)
- `src/core/02_UTILS.js` (10 рядків)
- `src/core/07_THREE_SETUP.js` (89 рядків)
- `src/core/18_STATE.js` (8 рядків)
- `src/core/20_AUDIO.js` (31 рядків)
- `src/core/31_GAME_LOGIC.js` (138 рядків)
- `src/core/32_LOOP.js` (17 рядків)
- `src/core/34_BOOT.js` (36 рядків)

## Save System — збереження, прогрес, досвід, досягнення
- `src/save/03_SAVE.js` (16 рядків)
- `src/save/29_PROGRESS.js` (10 рядків)

## World — карта, рельєф, дороги, Малинівка, вулиця Садова, Гуляйполе, небо, погода, частинки, імпорт GLB
- `src/world/04_WORLD_LAYOUT.js` (38 рядків)
- `src/world/05_ГУЛЯЙПОЛЕ_планування_вигадане_місто_на_п.js` (23 рядків)
- `src/world/06_GROUND_TEXTURE.js` (57 рядків)
- `src/world/08_BUILD_WORLD.js` (124 рядків)
- `src/world/09_REALISM_MODULE_Етап_1_5_вулиця_Садова.js` (496 рядків)
- `src/world/11_GLB_CORE_власний_розбір_glTF_2_0_glb_без.js` (74 рядків)
- `src/world/12_3D_ASSET_IMPORT_GLB_glTF_2_0.js` (96 рядків)
- `src/world/13_ГУЛЯЙПОЛЕ_забудова.js` (79 рядків)
- `src/world/14_SKY.js` (8 рядків)
- `src/world/15_PARTICLES.js` (14 рядків)
- `src/world/24_ПОГОДА.js` (22 рядків)

## Character — моделі бійця й мешканців
- `src/character/10_NEW_CHARACTER_PICKUP_MODELS.js` (84 рядків)
- `src/character/16_CHARACTERS.js` (31 рядків)

## Vehicles — 5 авто, фізика, гараж, паркування
- `src/vehicles/17_CAR.js` (34 рядків)
- `src/vehicles/21_VEHICLES_5_авто_гараж_102.js` (81 рядків)

## Mobile Platform — сенсорне керування, джойстик, кнопки, клавіатура
- `src/mobile/19_INPUT.js` (39 рядків)

## Drones — 3 дрони, FPV, батарея
- `src/drones/22_DRONES_102.js` (59 рядків)

## Missions — 10 сюжетних місій, головоломка
- `src/missions/23_MISSIONS_3_4.js` (59 рядків)
- `src/missions/25_МІСІЇ_5_10.js` (144 рядків)
- `src/missions/27_MISSIONS.js` (40 рядків)

## NPC — мешканці, діалоги, 20 побічних завдань, косметика
- `src/npc/26_МЕШКАНЦІ_ПОБІЧНІ_ЗАВДАННЯ.js` (73 рядків)

## UI — HUD, мінікарта, діалоги, меню, панелі
- `src/ui/28_DIALOG.js` (17 рядків)
- `src/ui/30_HUD.js` (23 рядків)
- `src/ui/33_MENU_SCREENS.js` (100 рядків)
