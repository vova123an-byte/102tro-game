"""Збирає гру з модулів:  python3 tools/build.py [--pwa] вихідний.html
--pwa додає маніфест, іконки й реєстрацію Service Worker (для хостингу та Capacitor)."""
import sys,os,json
root=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
args=[a for a in sys.argv[1:] if not a.startswith('--')];pwa='--pwa' in sys.argv
mods=json.load(open(os.path.join(root,'src','modules.json'),encoding='utf-8'))
order=sorted(mods,key=lambda m:int(os.path.basename(m[0]).split('_')[0]))
body=''.join(open(os.path.join(root,m[0]),encoding='utf-8').read() for m in order)
html=open(os.path.join(root,'src','index.template.html'),encoding='utf-8').read().replace('/*@@GAME_MODULES@@*/',body,1)
if pwa:
    html=html.replace('<title>','<link rel="manifest" href="manifest.webmanifest">\n<link rel="apple-touch-icon" href="icons/apple-touch-icon.png">\n<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">\n<meta name="apple-mobile-web-app-title" content="102 ТРО">\n<title>',1)
    html=html.replace('</body>',"<script>if('serviceWorker' in navigator)addEventListener('load',function(){navigator.serviceWorker.register('sw.js').catch(function(){})});</script>\n</body>",1)
out=args[0] if args else os.path.join(root,'www','index.html')
open(out,'w',encoding='utf-8').write(html);print('built',out,len(html),'bytes','(PWA)' if pwa else '')
