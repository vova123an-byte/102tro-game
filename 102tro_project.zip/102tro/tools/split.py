"""Одноразово розбиває зібраний index.html на модулі src/<категорія>/NN_назва.js + шаблон."""
import re,sys,os,json
src,root=sys.argv[1],sys.argv[2]
html=open(src,encoding='utf-8').read()
start=html.index("<script>\n'use strict';\nwindow.__gameMain=async function(){\n")
head_end=start+len("<script>\n'use strict';\nwindow.__gameMain=async function(){\n")
end=html.index("\n};\n</script>",head_end)
body=html[head_end:end]
tpl=html[:head_end]+"/*@@GAME_MODULES@@*/"+html[end:]
CAT=[('UTILS','core'),('SAVE','save'),('WORLD LAYOUT','world'),('ГУЛЯЙПОЛЕ: планування','world'),('GROUND TEXTURE','world'),('THREE SETUP','core'),('BUILD WORLD','world'),
 ('REALISM MODULE','world'),('NEW CHARACTER','character'),('GLB CORE','world'),('3D ASSET IMPORT','world'),('ГУЛЯЙПОЛЕ: забудова','world'),('SKY','world'),('PARTICLES','world'),
 ('CHARACTERS','character'),('CAR =','vehicles'),('STATE','core'),('INPUT','mobile'),('AUDIO','core'),('VEHICLES','vehicles'),('DRONES','drones'),('MISSIONS 3','missions'),
 ('ПОГОДА','world'),('МІСІЇ 5','missions'),('МЕШКАНЦІ','npc'),('MISSIONS =','missions'),('DIALOG','ui'),('PROGRESS','save'),('HUD','ui'),('GAME LOGIC','core'),('LOOP','core'),('MENU','ui'),('BOOT','core')]
parts=re.split(r'(?m)^(?=/\* =====)',body)
out=[];n=0
for p in parts:
    if not p:continue
    first=p.split('\n',1)[0]
    cat='core';name='header'
    if first.startswith('/* ='):
        title=re.sub(r'[/*=]','',first).strip()
        for k,c in CAT:
            if k in first: cat=c;break
        name=re.sub(r'[^0-9A-Za-zА-Яа-яІіЇїЄєҐґ]+','_',title).strip('_')[:40]
    n+=1;fn=f"src/{cat}/{n:02d}_{name}.js"
    os.makedirs(os.path.join(root,'src',cat),exist_ok=True)
    open(os.path.join(root,fn),'w',encoding='utf-8').write(p);out.append([fn,cat,len(p.splitlines())])
open(os.path.join(root,'src','index.template.html'),'w',encoding='utf-8').write(tpl)
json.dump(out,open(os.path.join(root,'src','modules.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1)
print(len(out),'modules')
