/* ================= GAME LOGIC ================= */
function nearInteract(){if(P.inCar)return null;
  if(mis&&MDEF[mis.id]&&MDEF[mis.id].interact){const mi=MDEF[mis.id].interact();if(mi)return{k:'mact',l:mi.l,fn:mi.fn}}
  if(dist2(P.x,P.z,npc.grp.position.x,npc.grp.position.z)<3.2)return{k:'npc',l:'ГОВОРИТИ'};
  const cx=C.x-Math.sin(C.yaw)*.3,cz=C.z-Math.cos(C.yaw)*.3;if(dist2(P.x,P.z,cx,cz)<3.6)return{k:'car',l:'СІСТИ'};
  const vn=villagerNear();if(vn>=0)return{k:'npc2',n:vn,l:'ГОВОРИТИ'};
  const pv=nearParked();if(pv)return{k:'veh',t:pv,l:'СІСТИ'};
  return null}
function enterCar(){P.inCar=true;hero.grp.visible=false;SFX.door();setTimeout(()=>{if(P.inCar){SFX.start();C.engine=true}},250);cam.lastDrag=-9;toast('Поїхали! '+(VT[S.vact]||VT.hilux).i+' '+(VT[S.vact]||VT.hilux).n);
  if(mis&&mis.id===1&&mis.step>=1)completeMission(1)}
function exitCar(){if(Math.abs(C.v)>8){toast('Спершу пригальмуй!');return}
  const lx=Math.cos(C.yaw),lz=-Math.sin(C.yaw);
  for(const s of[1,-1,0]){const o=s?{x:C.x+lx*2.2*s,z:C.z+lz*2.2*s}:{x:C.x-Math.sin(C.yaw)*3.6,z:C.z-Math.cos(C.yaw)*3.6};const ox=o.x,oz=o.z;resolve(o,.4);if(Math.hypot(o.x-ox,o.z-oz)<.05){P.x=o.x;P.z=o.z;break}}
  P.y=H(P.x,P.z);P.vy=0;P.inCar=false;hero.grp.visible=true;C.engine=false;SFX.door();P.yaw=C.yaw;cam.yaw=C.yaw}

function updPlayer(dt){
  if(P.inCar){P.x=C.x;P.z=C.z;if(edge.exit)exitCar();return}
  if(D.on){P.vx=P.vz=0;$('#bAct').classList.add('hidden');hero.legs.forEach(l=>l.rotation.x=0);hero.arms.forEach(a=>a.rotation.x=-.6);return}
  const ni=nearInteract(),ba=$('#bAct');if(ni){ba.classList.remove('hidden');ba.textContent=ni.l}else ba.classList.add('hidden');
  if(edge.act&&ni){if(ni.k==='mact'){ni.fn();return}if(ni.k==='car')enterCar();else if(ni.k==='veh'){switchVehicle(ni.t);enterCar()}else if(ni.k==='npc2'){if(typeof talkVillager==='function')talkVillager(ni.n)}else talkNPC();return}

  const run=(inp.run||inp.runK||inp.jm>.95)&&!inp.crouch&&inp.jm>.1;
  let sp=inp.crouch?1.7:run?6.6:3.3;if(inPos(P.x,P.z))sp*=.82;sp*=Math.min(1,inp.jm/.75+.0001);if(inp.jm===0)sp=0;
  const fx=Math.sin(cam.yaw),fz=Math.cos(cam.yaw),rx=-fz,rz=fx; // forward/right
  const mx=rx*inp.jx+fx*(-inp.jy),mz=rz*inp.jx+fz*(-inp.jy),ml=Math.hypot(mx,mz)||1;
  const tvx=inp.jm?mx/ml*sp:0,tvz=inp.jm?mz/ml*sp:0;const acc=P.ground?12:3;
  P.vx=lerp(P.vx,tvx,Math.min(1,dt*acc));P.vz=lerp(P.vz,tvz,Math.min(1,dt*acc));
  P.x+=P.vx*dt;P.z+=P.vz*dt;resolve(P,.38);
  // car as obstacle
  {const o={x:P.x,z:P.z};for(const k of[-1.3,0,1.3]){const cx=C.x+Math.sin(C.yaw)*k,cz=C.z+Math.cos(C.yaw)*k,d=dist2(o.x,o.z,cx,cz);if(d<1.4&&d>0){o.x=cx+(o.x-cx)/d*1.4;o.z=cz+(o.z-cz)/d*1.4}}P.x=o.x;P.z=o.z}
  P.x=clamp(P.x,-288,288);P.z=clamp(P.z,-288,288);
  const gh=H(P.x,P.z);
  if(edge.jump&&P.ground){P.vy=inp.crouch?4:5.6;P.ground=false;SFX.jump();S.stats.jumps++;if(S.stats.jumps>=50)grant('jump')}
  P.vy-=15*dt;P.y+=P.vy*dt;if(P.y<=gh){if(!P.ground&&P.vy<-3)SFX.land();P.y=gh;P.vy=0;P.ground=true}else if(P.y-gh>.25)P.ground=false;
  const spd=Math.hypot(P.vx,P.vz);if(spd>.3)P.yaw=lerpA(P.yaw,Math.atan2(P.vx,P.vz),dt*12);
  // animation
  P.walk+=dt*spd*2.1;const amp=Math.min(1,spd/3.3)*(run?.95:.6);const s=Math.sin(P.walk);
  hero.legs[0].rotation.x=s*amp;hero.legs[1].rotation.x=-s*amp;hero.arms[0].rotation.x=-s*amp*.9;hero.arms[1].rotation.x=s*amp*.9;
  if(hero.knees){const kc=inp.crouch?1.55:0;hero.knees[0].rotation.x=Math.max(0,-s)*amp*1.15+kc;hero.knees[1].rotation.x=Math.max(0,s)*amp*1.15+kc}
  if(hero.elbows){hero.elbows[0].rotation.x=-.25-Math.max(0,s)*amp*.7;hero.elbows[1].rotation.x=-.25-Math.max(0,-s)*amp*.7}
  hero.body.rotation.x=lerp(hero.body.rotation.x,run?.18:0,dt*8);
  const cr=inp.crouch?1:0;hero.body.position.y=lerp(hero.body.position.y,-.38*cr+(P.ground?Math.abs(Math.cos(P.walk))*.05*amp:0),dt*12);
  if(inp.crouch){hero.legs.forEach(l=>l.rotation.x=l.rotation.x*.4-.9);hero.hips.position.y=.95}
  if(!P.ground){hero.legs[0].rotation.x=-.6;hero.legs[1].rotation.x=.3;hero.arms[0].rotation.x=-2.4;hero.arms[1].rotation.x=-2.4}
  // idle breathe
  hero.torso.scale.y=1+Math.sin(gameT*2)*.012;
  hero.grp.position.set(P.x,P.y,P.z);hero.grp.rotation.y=P.yaw;
  // steps & dust
  const st=Math.floor(P.walk/Math.PI);if(st!==P.lastStep&&P.ground&&spd>.5){P.lastStep=st;SFX.step();if(run&&!inPos(P.x,P.z))emit(P.x,P.y+.1,P.z,(Math.random()-.5),.6,(Math.random()-.5),.8,.35,'#9a8462',.35,.7);
    for(const p of puddles)if(dist2(P.x,P.z,p.x,p.z)<Math.max(p.rx,p.rz)){SFX.splash();for(let i=0;i<6;i++)emit(P.x,P.y+.1,P.z,(Math.random()-.5)*2,2+Math.random()*2,(Math.random()-.5)*2,.6,.18,'#9fb0b8',.6,-1);break}}
  if(inPos(P.x,P.z)&&Math.abs(P.x-GAP1)>7&&Math.abs(P.x-GAP2)>7){P.forest=(P.forest||0)+spd*dt;if(P.forest>18)grant('forest')}
  // chevrons
  CHEV.forEach((c,i)=>{if(S.chev.includes(i))return;if(dist2(P.x,P.z,c.x,c.z)<1.6&&Math.abs(P.y-H(c.x,c.z))<3.5){S.chev.push(i);chevMeshes[i].visible=false;SFX.pick();S.coins+=30;addXP(20);toast(`🎖 Шеврон 102 знайдено (${S.chev.length}/${CHEV.length}) · +30 🪙`);if(S.chev.length>=10)grant('chev10');if(S.chev.length>=CHEV.length)grant('chev');persist()}});
}
function updCar(dt){
  const drive=P.inCar;let thr=0,brk=0,steer=0;
  if(drive&&edge.lights){S.lights=(S.lights+1)%3;toast(['💡 Фари: авто','💡 Фари: увімкнено','💡 Фари: вимкнено'][S.lights])}
  if(drive&&edge.ccam){S.cmode=(S.cmode+1)%3;cam.lastDrag=-9;toast(['🎥 Камера: далеко','🎥 Камера: близько','🎥 Камера: з кабіни'][S.cmode])}
  if(drive){thr=(inp.gas||inp.gasK)?1:0;brk=(inp.brake||inp.brakeK)?1:0;steer=inp.steer;if(edge.horn){SFX.horn();S.stats.horn++;if(S.stats.horn>=10)grant('horn')}}
  C.steer=lerp(C.steer,steer,Math.min(1,dt*(steer?5:7)));
  const VS=VT[S.vact]||VT.hilux,sm0=surf(C.x,C.z),sm=sm0>=1?1:sm0+(1-sm0)*VS.off*.6,dmg=C.hp<=0?.5:1;const maxF=VS.max*sm*dmg;
  if(thr){if(C.v<-.3)C.v+=16*dt;else C.v+=VS.acc*dt*(1-Math.max(0,C.v)/maxF*.55)}
  if(brk){if(C.v>.3)C.v-=17*dt;else C.v-=5.5*dt}
  if(!thr&&!brk)C.v-=Math.sign(C.v)*Math.min(Math.abs(C.v),(2.2+(1-sm)*4)*dt);
  if(C.v>maxF)C.v=lerp(C.v,maxF,Math.min(1,dt*1.5));C.v=Math.max(C.v,-7);
  const tr=C.steer*VS.turn*clamp(Math.abs(C.v)/5,0,1)*Math.sign(C.v)*(1-Math.min(.35,Math.abs(C.v)/80));C.yaw-=tr*dt;
  const fx=Math.sin(C.yaw),fz=Math.cos(C.yaw);C.x+=fx*C.v*dt;C.z+=fz*C.v*dt;
  // collisions
  let impact=0;for(const k of[VS.len*.28,-VS.len*.28]){const o={x:C.x+fx*k,z:C.z+fz*k},ox=o.x,oz=o.z;const h=resolve(o,VS.wd*.64);if(h){C.x+=o.x-ox;C.z+=o.z-oz;impact=Math.max(impact,Math.abs(C.v))}}
  if(impact>0){if(impact>3.5){C.v*=-.3;C.hp=Math.max(0,C.hp-impact*1.3*100/VS.hp);C.squash=1;cam.shake=Math.min(1,impact/12);SFX.bump();
      for(let i=0;i<10;i++)emit(C.x+fx*2.4,C.y+1,C.z+fz*2.4,(Math.random()-.5)*5,2+Math.random()*3,(Math.random()-.5)*5,.6,.25,'#ffd27a',.9,-1);
      if(C.hp<=0)toast('💥 Авто «втомилося» — їде повільно. Під’їдь до «Гаража 102» на ремонт');}
    else C.v*=.5}
  // player as obstacle
  if(!drive){const d=dist2(C.x,C.z,P.x,P.z);if(d<1.6&&Math.abs(C.v)>.5)C.v*=.5}
  C.x=clamp(C.x,-288,288);C.z=clamp(C.z,-288,288);
  // terrain pose
  const rx=Math.cos(C.yaw),rz=-Math.sin(C.yaw);// local +x (left)
  const hf=H(C.x+fx*1.6,C.z+fz*1.6),hb=H(C.x-fx*1.6,C.z-fz*1.6),hl=H(C.x+rx*.95,C.z+rz*.95),hr=H(C.x-rx*.95,C.z-rz*.95);
  const ty=(hf+hb+hl+hr)/4;C.y=lerp(C.y,ty,Math.min(1,dt*14));C.pitch=lerp(C.pitch,Math.atan2(hf-hb,3.2),dt*10);C.roll=lerp(C.roll,Math.atan2(hl-hr,1.9),dt*10);
  const bump=sm<.8&&Math.abs(C.v)>2?Math.sin(gameT*23)*.02*Math.min(1,Math.abs(C.v)/10):0;
  car.grp.position.set(C.x,C.y+bump,C.z);car.grp.rotation.set(-C.pitch,C.yaw,C.roll,'YXZ');
  // body roll on turns + squash
  C.squash=Math.max(0,C.squash-dt*2.5);const sq=Math.sin(C.squash*12)*C.squash*.12;
  car.body.rotation.z=lerp(car.body.rotation.z,-C.steer*Math.min(1,Math.abs(C.v)/15)*.07,dt*6);car.body.rotation.x=lerp(car.body.rotation.x,(thr&&C.v<10?-.03:0)+(brk&&C.v>1?.04:0),dt*5);
  car.body.scale.set(1+sq,1-sq,1+sq*.5);
  C.wrot+=C.v*dt/VS.wr;car.wheels.forEach(w=>{w.sp.rotation.x=C.wrot;if(w.f)w.piv.rotation.y=-C.steer*.5});
  // dust, splash, smoke, tracks
  const av=Math.abs(C.v);if(av>4&&sm<1.01){const n=sm<1?2:1;for(let i=0;i<n;i++)if(Math.random()<av/22){const bx=C.x-fx*2.3+rx*(Math.random()-.5)*2,bz=C.z-fz*2.3+rz*(Math.random()-.5)*2;emit(bx,C.y+.3,bz,-fx*av*.15+(Math.random()-.5),.8+Math.random(),-fz*av*.15+(Math.random()-.5),1.6,.6,inPos(C.x,C.z)?'#5a4630':'#a08a66',.45,1.6)}}
  if(av>3)for(const p of puddles){if(dist2(C.x,C.z,p.x,p.z)<Math.max(p.rx,p.rz)+1){if(Math.random()<.5)SFX.splash();for(let i=0;i<14;i++){const s=Math.random()<.5?1:-1;emit(C.x+rx*s*1.1,C.y+.3,C.z+rz*s*1.1,rx*s*(2+Math.random()*3)+(Math.random()-.5),2+Math.random()*3,rz*s*(2+Math.random()*3)+(Math.random()-.5),.7,.22,'#a7b8c0',.7,-1)}break}}
  if(C.hp<45&&Math.random()<dt*(C.hp<=0?12:5))emit(C.x+fx*2,C.y+1.6,C.z+fz*2,(Math.random()-.5)*.5,1.5,(Math.random()-.5)*.5,2,.5,C.hp<=0?'#3a3a3a':'#8a8a8a',.5,1.2);
  if(drive){S.stats.km+=av*dt/1000;if(S.stats.km>=1)grant('km');if(night>.6&&av>5){nightAch+=dt;if(nightAch>20)grant('night')}}
  // headlights
  const hlOn=S.lights===1?(drive||C.engine):S.lights===2?false:(night>.15&&(drive||C.engine));car.spot.intensity=hlOn?2.4*night+.9:0;
  // engine sound
  if(eng&&AC){const on=drive&&C.engine,t=AC.currentTime;const gears=[0,5,10,15,20,26];let g=0;while(g<gears.length-2&&av>gears[g+1])g++;const r=clamp((av-gears[g])/(gears[g+1]-gears[g]),0,1);
    const vp=S.vact==='van'?.85:S.vact==='uaz'?.8:S.vact==='patrol'?.9:1;const f=on?(48+r*70+g*8+(thr?8:0))*vp:40;eng.o1.frequency.setTargetAtTime(f,t,.08);eng.o2.frequency.setTargetAtTime(f*.5,t,.08);eng.f.frequency.setTargetAtTime(300+r*500+(thr?300:0),t,.1);eng.gn.gain.setTargetAtTime(on&&S.sound?.075+(thr?.03:0):0,t,.15);
    windG.gain.setTargetAtTime(.02+av*.002,t,.3)}
}
let night=0;
function updWorld(dt){
  S.tod=(S.tod+dt/480)%1;const a=(S.tod-.25)*Math.PI*2,sy=Math.sin(a),sx=Math.cos(a);
  night=clamp((.08-sy)/.25,0,1);const dusk=clamp(1-Math.abs(sy-.03)/.22,0,1);
  const tx=P.inCar?C.x:P.x,tz=P.inCar?C.z:P.z;
  const sd=new T.Vector3(sx*.75,Math.max(sy,.12),.45).normalize();
  sun.position.set(tx+sd.x*120,sd.y*120,tz+sd.z*120);sun.target.position.set(tx,0,tz);
  updSky();weatherLight();
  stars.material.opacity=night*.9*(1-WX.k.rain);stars.position.copy(camera.position);
  MAT.win.emissive.setRGB(night*.95,night*.7,night*.3);
  WIND.value+=dt*(1+Math.sin(gameT*.13)*.4);
  // flag
  const fp=flagMesh.geometry.attributes.position;for(let i=0;i<fp.count;i++){const x=flagMesh.userData.ox[i];fp.setZ(i,Math.sin(x*3-gameT*5)*.16*(x+1.25)/2.5+Math.sin(x*7-gameT*8)*.03*(x+1.25))}fp.needsUpdate=true;
  if(Math.floor(gameT*2)%4===0)flagMesh.geometry.computeVertexNormals();
  // npc idle: look at player
  const nd=dist2(npc.grp.position.x,npc.grp.position.z,P.x,P.z);npc.grp.rotation.y=lerpA(npc.grp.rotation.y,nd<12?Math.atan2(P.x-npc.grp.position.x,P.z-npc.grp.position.z):Math.PI/2,dt*3);
  npc.arms[1].rotation.x=nd<6?-1.6+Math.sin(gameT*6)*.4:Math.sin(gameT)*.05;npc.head.rotation.z=Math.sin(gameT*.8)*.05;
  // marker bob, chevrons spin
  marker.children[1].position.y=7+Math.sin(gameT*3)*.5;marker.children[1].rotation.y+=dt*2;marker.children[0].material.opacity=.18+Math.sin(gameT*4)*.06;
  chevMeshes.forEach((m,i)=>{m.rotation.y+=dt*2;m.position.y=m.userData.y+Math.sin(gameT*2+i)*.15});
  // ambient birds / crickets
  birdT-=dt;if(birdT<=0){birdT=night>.5?.8+Math.random()*1.5:2+Math.random()*5;night>.5?cricket():bird()}
}
function updCamera(dt){
  const drive=P.inCar;const tx=drive?C.x:P.x,tz=drive?C.z:P.z,ty=drive?C.y+1.9:P.y+(inp.crouch?1.15:1.6);
  if(drive&&S.cmode===2){const fx=Math.sin(C.yaw),fz=Math.cos(C.yaw);camera.position.set(C.x+fx*.35,C.y+(S.vact==='van'?2.05:1.75),C.z+fz*.35);camera.rotation.set(C.pitch*.8-.06,C.yaw+Math.PI,-C.roll*.6,'YXZ');
    const f2=70+Math.min(10,Math.abs(C.v)*.4);if(Math.abs(camera.fov-f2)>.1){camera.fov=f2;camera.updateProjectionMatrix()}return}
  const td=drive?(S.cmode===1?6:9.5)*Math.sqrt((VT[S.vact]||VT.hilux).len/5.3):4.6;cam.dist=lerp(cam.dist,td,dt*3);
  if(drive&&gameT-cam.lastDrag>1.4){cam.yaw=lerpA(cam.yaw,C.yaw+(C.v<-1?Math.PI:0),dt*2.4);cam.pitch=lerp(cam.pitch,.24,dt*1.2)}
  const cp=Math.cos(cam.pitch),sp=Math.sin(cam.pitch);
  let x=tx-Math.sin(cam.yaw)*cam.dist*cp,z=tz-Math.cos(cam.yaw)*cam.dist*cp,y=ty+cam.dist*sp;
  for(let i=1;i<=12;i++){const t=i/12,qx=tx+(x-tx)*t,qy=ty+(y-ty)*t,qz=tz+(z-tz)*t;if(colAt(qx,qz,qy)){const tt=Math.max(.12,(i-1)/12-.03);x=tx+(x-tx)*tt;y=ty+(y-ty)*tt;z=tz+(z-tz)*tt;break}}
  const gh=H(x,z)+.5;if(y<gh)y=gh;
  cam.shake=Math.max(0,cam.shake-dt*2);const sk=cam.shake*.35;
  const cf=1-Math.exp(-dt*9);camera.position.set(lerp(camera.position.x,x,cf)+(Math.random()-.5)*sk,lerp(camera.position.y,y,cf)+(Math.random()-.5)*sk,lerp(camera.position.z,z,cf));
  camera.lookAt(tx,ty,tz);
  const f=62+(drive?Math.min(14,Math.abs(C.v)*.5):0);if(Math.abs(camera.fov-f)>.1){camera.fov=lerp(camera.fov,f,dt*3);camera.updateProjectionMatrix()}}
function menuCamera(dt){const t=gameT*.04;const x=30+Math.cos(t)*120,z=-20+Math.sin(t)*110;camera.position.set(x,H(x,z)+28,z);camera.lookAt(10,4,0)}

