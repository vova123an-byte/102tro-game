/* ================= UTILS ================= */
const rngS=s=>()=>{s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
let rnd=rngS(102);
const clamp=(v,a,b)=>v<a?a:v>b?b:v, lerp=(a,b,t)=>a+(b-a)*t;
const sm=(a,b,v)=>{const t=clamp((v-a)/(b-a),0,1);return t*t*(3-2*t)};
const angD=(a,b)=>{let d=b-a;while(d>Math.PI)d-=Math.PI*2;while(d<-Math.PI)d+=Math.PI*2;return d};
const lerpA=(a,b,t)=>a+angD(a,b)*clamp(t,0,1);
const dist2=(ax,az,bx,bz)=>Math.hypot(bx-ax,bz-az);
function segDist(px,pz,ax,az,bx,bz){const dx=bx-ax,dz=bz-az,l2=dx*dx+dz*dz;let t=((px-ax)*dx+(pz-az)*dz)/l2;t=clamp(t,0,1);return Math.hypot(px-(ax+dx*t),pz-(az+dz*t))}

