/* ================= BOOT ================= */
await tick('Готуємо 3D-сцену…',8);
{
  await buildWorld();
  await tick('Персонажі та пікап…',88);
  const mx=miniC.getContext('2d');mx.drawImage(gcv,0,0,512,512);
  // houses on minimap
  mx.fillStyle='#e8e0cc';for(const h of houses){const s=512/SIZE,sw=Math.abs(Math.sin(h.rot))>.7;const w=(sw?h.d:h.w)*s,d=(sw?h.w:h.d)*s;mx.fillRect((h.x+HALF)*s-w/2,(h.z+HALF)*s-d/2,w,d)}
  mx.fillStyle='#2a3a1a';mx.fillRect(0,(POS0+HALF)*512/SIZE,512,(POS1-POS0)*512/SIZE);
  rebuildHero();
  npc=makeHuman({shirt:'#47453c',pants:'#2f3138',cap:'#3a3936',mustache:true});npc.grp.position.set(-223,0,roadMain(-223)+8.6);npc.grp.position.y=H(npc.grp.position.x,npc.grp.position.z);npc.grp.rotation.y=Math.PI/2;scene.add(npc.grp);
  addCol({t:'c',x:npc.grp.position.x,z:npc.grp.position.z,r:.4});
  rebuildCar();buildGarage();
  // flag at center
  {const y=H(FLAG.x,FLAG.z);const pole=new T.Mesh(GEO.cylB,new T.MeshLambertMaterial({color:0xcfcfcf}));pole.scale.set(.14,8,.14);pole.position.set(FLAG.x,y,FLAG.z);pole.castShadow=true;scene.add(pole);
    const fg=new T.PlaneGeometry(2.5,1.66,14,6);fg.translate(1.25,0,0);const fm=new T.Mesh(fg,new T.MeshLambertMaterial({map:flagTex(),side:T.DoubleSide}));fm.position.set(FLAG.x+.07,y+7.1,FLAG.z);fm.castShadow=true;scene.add(fm);flagMesh=fm;
    const ox=[];const pa=fg.attributes.position;for(let i=0;i<pa.count;i++)ox.push(pa.getX(i)-1.25);fm.userData.ox=ox;addCol({t:'c',x:FLAG.x,z:FLAG.z,r:.2})}
  // marker
  marker=new T.Group();{const beam=new T.Mesh(new T.CylinderGeometry(.9,.9,40,12,1,true),new T.MeshBasicMaterial({color:0xffd500,transparent:true,opacity:.2,depthWrite:false,side:T.DoubleSide}));beam.position.y=20;marker.add(beam);
    const ar=new T.Mesh(new T.ConeGeometry(.8,1.6,4),new T.MeshBasicMaterial({color:0xffd500}));ar.rotation.x=Math.PI;marker.add(ar)}scene.add(marker);
  // chevrons
  const chm=new T.MeshLambertMaterial({color:0xffd500,emissive:0x8a6a00}),chb=new T.MeshLambertMaterial({color:0x2f6fd6,emissive:0x0a2a66});
  CHEV.forEach((c,i)=>{const g=new T.Group();const a=new T.Mesh(new T.CylinderGeometry(.42,.42,.1,6),chm);a.rotation.x=Math.PI/2;g.add(a);const b=new T.Mesh(new T.CylinderGeometry(.26,.26,.12,6),chb);b.rotation.x=Math.PI/2;g.add(b);
    const y=H(c.x,c.z)+1;g.position.set(c.x,y,c.z);g.userData.y=y;g.visible=!S.chev.includes(i);scene.add(g);chevMeshes.push(g)});
  linearizeAll(scene);
  applyQuality();resetWorldPositions(!S.hasGame);spawnParked();spawnVillagers();
  await tick('Перший кадр…',96);
  renderer.render(scene,camera);
  $('#load').style.display='none';state='menu';toMenu();window.__booted=true;
  setTimeout(()=>loadAssetsAtBoot(),300);
  if(window.__streetErr)window.__bootFail('Частину світу не вдалося побудувати ('+window.__streetErr+'). Гра працює, але без цієї частини.');
  requestAnimationFrame(frame);
  setTimeout(()=>{try{localStorage.removeItem('tro102_boot')}catch(e){}},4000);
  try{const l=document.createElement('link');l.rel='stylesheet';l.href='https://fonts.googleapis.com/css2?family=Russo+One&display=swap';document.head.appendChild(l)}catch(e){}
  if(prevCrash)setTimeout(()=>{try{toast('Попередній запуск зупинився — увімкнено низьку якість')}catch(e){}},500);
}