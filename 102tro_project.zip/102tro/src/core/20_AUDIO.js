/* ================= AUDIO ================= */
let AC=null,master,sfxG,musG,eng=null,windG,windF;
function initAudio(){if(AC){if(AC.state==='suspended')AC.resume();return}
  try{AC=new(window.AudioContext||window.webkitAudioContext)()}catch(e){return}
  master=AC.createGain();master.gain.value=S.sound?.8:0;master.connect(AC.destination);
  sfxG=AC.createGain();sfxG.gain.value=1;sfxG.connect(master);musG=AC.createGain();musG.gain.value=S.music?.5:0;musG.connect(master);
  const nb=AC.createBuffer(1,AC.sampleRate*2,AC.sampleRate),nd=nb.getChannelData(0);for(let i=0;i<nd.length;i++)nd[i]=Math.random()*2-1;AC.nb=nb;
  const ns=AC.createBufferSource();ns.buffer=nb;ns.loop=true;windF=AC.createBiquadFilter();windF.type='bandpass';windF.frequency.value=380;windF.Q.value=.7;windG=AC.createGain();windG.gain.value=.025;ns.connect(windF).connect(windG).connect(sfxG);ns.start();
  const o1=AC.createOscillator(),o2=AC.createOscillator(),f=AC.createBiquadFilter(),gn=AC.createGain();o1.type='sawtooth';o2.type='square';f.type='lowpass';f.frequency.value=500;gn.gain.value=0;
  const g2=AC.createGain();g2.gain.value=.5;o1.connect(f);o2.connect(g2).connect(f);f.connect(gn).connect(sfxG);o1.start();o2.start();eng={o1,o2,f,gn};
  musicLoop();
}
function tone(f1,f2,dur,type,vol,delay,dest){if(!AC)return;const t=AC.currentTime+(delay||0);const o=AC.createOscillator(),gn=AC.createGain();o.type=type||'sine';o.frequency.setValueAtTime(f1,t);o.frequency.exponentialRampToValueAtTime(Math.max(20,f2),t+dur);
  gn.gain.setValueAtTime(0.0001,t);gn.gain.exponentialRampToValueAtTime(vol||.1,t+Math.min(.02,dur/4));gn.gain.exponentialRampToValueAtTime(.0001,t+dur);o.connect(gn).connect(dest||sfxG);o.start(t);o.stop(t+dur+.05)}
function noise(dur,freq,vol,type,delay){if(!AC)return;const t=AC.currentTime+(delay||0);const s=AC.createBufferSource();s.buffer=AC.nb;const f=AC.createBiquadFilter();f.type=type||'lowpass';f.frequency.value=freq;const gn=AC.createGain();gn.gain.setValueAtTime(vol,t);gn.gain.exponentialRampToValueAtTime(.0001,t+dur);s.connect(f).connect(gn).connect(sfxG);s.start(t,Math.random());s.stop(t+dur+.05)}
const SFX={step:()=>noise(.07,inPos(P.x,P.z)?900:600,.09,'lowpass'),jump:()=>tone(300,520,.12,'triangle',.08),land:()=>noise(.12,400,.15),door:()=>{noise(.08,1200,.15,'bandpass');tone(140,90,.12,'square',.06,.05)},
  start:()=>{for(let i=0;i<5;i++)noise(.09,300,.18,'lowpass',i*.1);tone(60,90,.6,'sawtooth',.08,.5)},bump:()=>{noise(.25,250,.35);tone(120,50,.25,'sine',.25)},
  horn:()=>{tone(392,392,.45,'square',.07);tone(494,494,.45,'square',.06)},pick:()=>{[660,880,1320].forEach((f,i)=>tone(f,f,.12,'triangle',.12,i*.08))},ring:()=>{tone(1046,1046,.12,'sine',.14);tone(1568,1568,.2,'sine',.14,.1)},
  win:()=>{[523,659,784,1046,1318].forEach((f,i)=>tone(f,f,.25,'triangle',.13,i*.12))},talk:()=>{for(let i=0;i<4;i++)tone(220+Math.random()*120,200,.06,'square',.04,i*.07)},splash:()=>noise(.3,1800,.12,'highpass')};
function bird(){if(!AC||!S.sound)return;const n=2+Math.random()*4|0,b=2400+Math.random()*1800;for(let i=0;i<n;i++)tone(b+Math.random()*600,b-400+Math.random()*900,.08+Math.random()*.07,'sine',.03,i*.13)}
function cricket(){if(!AC||!S.sound)return;for(let i=0;i<6;i++)tone(4300,4250,.03,'square',.008,i*.06)}
// ambient music: slow minor pads + soft bandura-like plucks
const CH=[[146.8,174.6,220],[116.5,146.8,174.6],[130.8,164.8,196],[110,138.6,164.8]]; // Dm Bb C A
let musStep=0;
function musicLoop(){if(!AC)return;const t=AC.currentTime;const ch=CH[musStep%4];
  if(S.music&&(state==='play'||state==='menu'||state==='pause')){
    ch.forEach(f=>{const o=AC.createOscillator(),gn=AC.createGain(),fl=AC.createBiquadFilter();o.type='triangle';o.frequency.value=f;fl.type='lowpass';fl.frequency.value=900;gn.gain.setValueAtTime(.0001,t);gn.gain.exponentialRampToValueAtTime(.035,t+1.2);gn.gain.exponentialRampToValueAtTime(.0001,t+3.9);o.connect(fl).connect(gn).connect(musG);o.start(t);o.stop(t+4)});
    const sc=[ch[0]*2,ch[1]*2,ch[2]*2,ch[0]*4];for(let i=0;i<4;i++)if(Math.random()<.7)pluck(sc[(Math.random()*4)|0],t+.5+i*.8)}
  musStep++;setTimeout(musicLoop,4000)}
function pluck(f,t){const o=AC.createOscillator(),gn=AC.createGain();o.type='triangle';o.frequency.setValueAtTime(f,t);gn.gain.setValueAtTime(.0001,t);gn.gain.exponentialRampToValueAtTime(.05,t+.01);gn.gain.exponentialRampToValueAtTime(.0001,t+1.1);o.connect(gn).connect(musG);o.start(t);o.stop(t+1.2)}

