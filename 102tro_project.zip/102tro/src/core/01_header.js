const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
const T=window.THREE;
// Сумісність з Three.js r128: BufferGeometry.applyQuaternion з'явився лише в новіших версіях
const _rotM=new T.Matrix4();
function geoRot(g,q){return g.applyMatrix4(_rotM.makeRotationFromQuaternion(q))}
if(T.BufferGeometry&&!T.BufferGeometry.prototype.applyQuaternion){T.BufferGeometry.prototype.applyQuaternion=function(q){return this.applyMatrix4(new T.Matrix4().makeRotationFromQuaternion(q))}}
const tick=(t,p)=>{window.__bootStatus(t,p);return new Promise(r=>setTimeout(r,20))};

