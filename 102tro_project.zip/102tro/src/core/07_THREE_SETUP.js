/* ================= THREE SETUP ================= */
const canvas=$('#gl');
if(!window.__webglOK())throw new Error('WEBGL');
let renderer;
try{renderer=new T.WebGLRenderer({canvas,antialias:QL.aa,powerPreference:'high-performance'})}
catch(e){renderer=new T.WebGLRenderer({canvas,antialias:false,powerPreference:'default'})}
renderer.outputEncoding=T.sRGBEncoding;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1;
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();window.__bootFail('Телефон скинув графічний контекст (забагато пам\'яті). Натисни «БЕЗПЕЧНИЙ РЕЖИМ».')},false);
const scene=new T.Scene();
const camera=new T.PerspectiveCamera(62,1,.1,700);
const hemi=new T.HemisphereLight(0xcfe0ff,0x4a4a2a,.6);scene.add(hemi);
const sun=new T.DirectionalLight(0xfff0d6,.9);scene.add(sun);scene.add(sun.target);
sun.shadow.mapSize.set(1024,1024);const sc=sun.shadow.camera;sc.left=-36;sc.right=36;sc.top=36;sc.bottom=-36;sc.near=1;sc.far=260;sun.shadow.bias=-.0004;sun.shadow.normalBias=.025;
scene.fog=new T.FogExp2(0xa7bccb,QL.fog);
function applyQuality(){
  const q=Q[S.quality]||Q.medium;drScale=1;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,q.dpr));
  const sh=q.shadow>0;renderer.shadowMap.enabled=sh;sun.castShadow=sh;renderer.shadowMap.type=S.quality==='high'?T.PCFSoftShadowMap:T.PCFShadowMap;
  if(sh){sun.shadow.mapSize.set(q.shadow,q.shadow);if(sun.shadow.map){sun.shadow.map.dispose();sun.shadow.map=null}}
  renderer.shadowMap.needsUpdate=true;if(scene.fog&&scene.fog.density!==undefined)scene.fog.density=q.fog;
  scene.traverse(o=>{if(o.material){const m=Array.isArray(o.material)?o.material:[o.material];m.forEach(mm=>mm.needsUpdate=true)}});
  resize();
}
function resize(){const w=window.innerWidth,h=window.innerHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();
  if(pMat)pMat.uniforms.uScale.value=h*renderer.getPixelRatio()/(2*Math.tan(camera.fov*Math.PI/360));
  const m=$('#mini');m.width=m.clientWidth*2||208;m.height=m.clientHeight*2||208;
  $('#rot').classList.toggle('need',!rotDismissed);}
let rotDismissed=false;

/* wind shader */
const WIND={value:0};
function windify(mat,amp){mat.onBeforeCompile=sh=>{sh.uniforms.uTime=WIND;sh.vertexShader='uniform float uTime;\n'+sh.vertexShader.replace('#include <begin_vertex>',
`#include <begin_vertex>
#ifdef USE_INSTANCING
vec3 ip=vec3(instanceMatrix[3][0],instanceMatrix[3][1],instanceMatrix[3][2]);
#else
vec3 ip=vec3(modelMatrix[3][0],modelMatrix[3][1],modelMatrix[3][2]);
#endif
float sw=sin(uTime*1.7+ip.x*.37+ip.z*.23)*${amp.toFixed(3)}*max(0.0,position.y+.5);
transformed.x+=sw;transformed.z+=sw*.6;`)};mat.customProgramCacheKey=()=>'wind'+amp.toFixed(3);return mat}

/* geometries & materials */
const GEO={
  box:new T.BoxGeometry(1,1,1),
  boxB:new T.BoxGeometry(1,1,1).translate(0,.5,0),
  cylB:new T.CylinderGeometry(.5,.5,1,10).translate(0,.5,0),
  trunk:new T.CylinderGeometry(.13,.22,1,5).translate(0,.5,0),
  ico:new T.IcosahedronGeometry(1,0),
  ico1:new T.IcosahedronGeometry(1,1),
  cone:new T.ConeGeometry(.5,1,7).translate(0,.5,0),
  cone4:new T.ConeGeometry(.5,1,4).translate(0,.5,0),
  disc:new T.CylinderGeometry(.5,.5,.12,10),
  puddle:new T.CircleGeometry(1,16).rotateX(-Math.PI/2),
};
(function(){const sh=new T.Shape();sh.moveTo(-.5,0);sh.lineTo(.5,0);sh.lineTo(0,1);sh.lineTo(-.5,0);
  const gg=new T.ExtrudeGeometry(sh,{depth:1,bevelEnabled:false});gg.translate(0,0,-.5);gg.rotateY(Math.PI/2);GEO.prism=gg;})();
const MAT={
  lam:new T.MeshLambertMaterial({color:0xffffff}),
  flat:new T.MeshLambertMaterial({color:0xffffff,flatShading:true}),
  crown:windify(new T.MeshLambertMaterial({color:0xffffff,flatShading:true}),.05),
  grass:windify(new T.MeshLambertMaterial({color:0xffffff,flatShading:true}),.22),
  win:new T.MeshLambertMaterial({color:0x2a3a4a,emissive:0x000000}),
  puddle:new T.MeshPhongMaterial({color:0x56646a,specular:0xbfd0d8,shininess:90,transparent:true,opacity:.88}),
};
/* instanced batcher */
const BATCH={};
const _o=new T.Object3D(),_c=new T.Color();
let PUTREC=null;
function put(key,geo,mat,x,y,z,sx,sy,sz,ry,col,rx,rz,opt){let b=BATCH[key];if(!b)b=BATCH[key]={geo,mat,it:[],cast:!(opt&&opt.noCast),recv:true};b.it.push([x,y,z,sx,sy,sz,ry||0,col||'#ffffff',rx||0,rz||0]);if(PUTREC)PUTREC.push([key,b.it.length-1])}
function flush(){for(const k in BATCH){const b=BATCH[k];const m=new T.InstancedMesh(b.geo,b.mat,b.it.length);
  b.it.forEach((t,i)=>{_o.position.set(t[0],t[1],t[2]);_o.rotation.set(t[8],t[6],t[9],'YXZ');_o.scale.set(t[3],t[4],t[5]);_o.updateMatrix();m.setMatrixAt(i,_o.matrix);m.setColorAt(i,desat(_c.set(t[7])))});
  m.castShadow=b.cast;m.receiveShadow=b.recv;m.instanceMatrix.needsUpdate=true;b.mesh=m;if(m.instanceColor)m.instanceColor.needsUpdate=true;scene.add(m)}}

/* colliders */
const CC=10,CG=new Map();let colStamp=0;
function addCol(c){c.s=0;const b=c.t==='b'?[c.x0,c.z0,c.x1,c.z1]:[c.x-c.r,c.z-c.r,c.x+c.r,c.z+c.r];
  for(let i=Math.floor((b[0]+HALF)/CC);i<=Math.floor((b[2]+HALF)/CC);i++)for(let j=Math.floor((b[1]+HALF)/CC);j<=Math.floor((b[3]+HALF)/CC);j++){const k=i*1000+j;if(!CG.has(k))CG.set(k,[]);CG.get(k).push(c)}return c}
function resolve(o,r){colStamp++;let hit=null;const ci=Math.floor((o.x+HALF)/CC),cj=Math.floor((o.z+HALF)/CC);
  for(let i=ci-1;i<=ci+1;i++)for(let j=cj-1;j<=cj+1;j++){const L=CG.get(i*1000+j);if(!L)continue;for(const c of L){if(c.s===colStamp)continue;c.s=colStamp;
    if(c.off)continue;if(c.t==='b'){if(o.x+r<c.x0||o.x-r>c.x1||o.z+r<c.z0||o.z-r>c.z1)continue;const nx=clamp(o.x,c.x0,c.x1),nz=clamp(o.z,c.z0,c.z1);let dx=o.x-nx,dz=o.z-nz;const d2=dx*dx+dz*dz;
      if(d2<1e-6){const l=o.x-c.x0,rr=c.x1-o.x,t=o.z-c.z0,bb=c.z1-o.z,m=Math.min(l,rr,t,bb);if(m===l){o.x=c.x0-r;hit={nx:-1,nz:0}}else if(m===rr){o.x=c.x1+r;hit={nx:1,nz:0}}else if(m===t){o.z=c.z0-r;hit={nx:0,nz:-1}}else{o.z=c.z1+r;hit={nx:0,nz:1}}continue}
      if(d2>=r*r)continue;const d=Math.sqrt(d2);o.x+=dx/d*(r-d);o.z+=dz/d*(r-d);hit={nx:dx/d,nz:dz/d}}
    else{if(c.off)continue;const dx=o.x-c.x,dz=o.z-c.z,d=Math.hypot(dx,dz),rr=r+c.r;if(d>=rr||d<1e-6)continue;o.x+=dx/d*(rr-d);o.z+=dz/d*(rr-d);hit={nx:dx/d,nz:dz/d}}}}
  return hit}
function boxCol(x,z,hw,hd,rot){const sw=Math.abs(Math.sin(rot))>.7;const a=sw?hd:hw,b=sw?hw:hd;return addCol({t:'b',x0:x-a,x1:x+a,z0:z-b,z1:z+b})}

/* local→world helper for oriented parts */
function L(ox,oz,rot,lx,lz){const c=Math.cos(rot),s=Math.sin(rot);return[ox+lx*c+lz*s,oz-lx*s+lz*c]}

