/* ================= LOOP ================= */
let last=performance.now();
let drT=0,drN=0,drScale=1;
function dynRes(dt){drT+=dt;drN++;if(drT<2)return;const fps=drN/drT;drT=0;drN=0;const q=Q[S.quality]||Q.medium,base=Math.min(window.devicePixelRatio||1,q.dpr);
  const old=drScale;if(fps<38&&drScale>.6)drScale=Math.max(.6,drScale-.15);else if(fps>55&&drScale<1)drScale=Math.min(1,drScale+.1);
  if(old!==drScale){renderer.setPixelRatio(base*drScale);resize()}}
function frame(now){requestAnimationFrame(frame);let dt=(now-last)/1000;last=now;if(dt>.05)dt=.05;if(dt<=0)return;
  if(state==='play'||state==='menu'||state==='dialog'){gameT+=dt;updWorld(dt);updWeather(dt)}
  if(state==='play'){readInput();updPlayer(dt);updCar(dt);garageRepair(dt);updDrone(dt);updSide(dt);updMission(dt);try{updAssets(dt)}catch(e){}dynRes(dt);if(D.on)droneCamera(dt);else updCamera(dt);updHUD();
    saveT+=dt;if(saveT>5){saveT=0;saveState()}}
  else if(state==='dialog'){if(D.on)droneCamera(dt);else updCamera(dt);if(drAud&&AC)drAud.g.gain.setTargetAtTime(0,AC.currentTime,.1)}
  else if(state==='menu'){menuCamera(dt);if(D.on)landDrone('quiet');if(eng&&AC)eng.gn.gain.setTargetAtTime(0,AC.currentTime,.2)}
  if(state!=='load')updParts(dt);
  for(const k in edge)edge[k]=false;
  renderer.render(scene,camera)}
function saveState(){S.pos={x:P.x,z:P.z,yaw:P.yaw,inCar:P.inCar};S.car={x:C.x,z:C.z,yaw:C.yaw,hp:C.hp};S.hasGame=true;S.mis=mis?{id:mis.id,step:mis.step,ring:mis.ring||0}:null;persist()}

