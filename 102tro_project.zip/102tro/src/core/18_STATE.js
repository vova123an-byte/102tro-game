/* ================= STATE ================= */
let state='load'; // load|menu|play|pause|dialog
const P={x:START.x,z:START.z,y:0,vx:0,vz:0,vy:0,yaw:Math.PI/2,ground:true,run:false,crouch:false,walk:0,inCar:false,stepT:0,lastStep:0};
const C={x:-214,z:roadMain(-214)+4.6,y:0,yaw:Math.PI/2,v:0,steer:0,hp:100,squash:0,pitch:0,roll:0,wrot:0,engine:false,odo:0};
let hero,npc,car,flagMesh,marker,ringMeshes=[],chevMeshes=[];
const cam={yaw:Math.PI/2,pitch:.32,dist:4.8,lastDrag:-9,shake:0};
let gameT=0,saveT=0,birdT=3,nightAch=0;

