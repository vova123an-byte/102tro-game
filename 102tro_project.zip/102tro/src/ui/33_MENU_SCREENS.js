/* ================= MENU / SCREENS ================= */
function show(id){['#menu','#panel'].forEach(s=>$(s).classList.add('hidden'));if(id)$(id).classList.remove('hidden');$('#hud').classList.toggle('hidden',!(state==='play'||state==='dialog'))}
function toMenu(){if(state==='play'||state==='pause')saveState();state='menu';show('#menu');$('#dlg').classList.add('hidden');
  const nx=[1,2,3,4,5,6,7,8,9,10].find(i=>!S.done.includes(i));$('#startSub').textContent=nx?`Місія ${nx} · ${MISSIONS[nx-1].n}`:'Кампанію пройдено · вільний світ';}
function newGame(b){if(!b.dataset.c){b.dataset.c=1;b.firstChild.textContent='ТОЧНО? НАТИСНИ ЩЕ РАЗ';setTimeout(()=>{delete b.dataset.c;b.firstChild.textContent='НОВА ГРА'},3500);return}
  const keep={callsign:S.callsign,quality:S.quality,sound:S.sound,music:S.music,sens:S.sens};S=Object.assign(defaults(),keep);persist();try{localStorage.removeItem('tro102_boot')}catch(e){}location.reload()}
function resetWorldPositions(fresh){
  if(!fresh&&S.pos){P.x=S.pos.x;P.z=S.pos.z;P.yaw=S.pos.yaw||0}else{P.x=START.x;P.z=START.z;P.yaw=Math.PI/2}
  if(!fresh&&S.car){C.x=S.car.x;C.z=S.car.z;C.yaw=S.car.yaw;C.hp=S.car.hp??100}else{C.x=-214;C.z=roadMain(-214)+4.6;C.yaw=Math.PI/2;C.hp=100}
  C.v=0;C.y=H(C.x,C.z);P.y=H(P.x,P.z);P.vx=P.vz=P.vy=0;P.inCar=false;hero.grp.visible=true;
  if(!fresh&&S.pos&&S.pos.inCar){P.inCar=true;hero.grp.visible=false;C.engine=true}
  cam.yaw=P.inCar?C.yaw:P.yaw;camera.position.set(P.x-Math.sin(cam.yaw)*5,P.y+3,P.z-Math.cos(cam.yaw)*5)}
function play(mode){initAudio();ringMeshes.forEach(r=>scene.remove(r));ringMeshes=[];
  if(mode==='story'){
    if(S.hasGame&&S.mis&&S.mis.id<=2){clearMissionObjs();mis={id:S.mis.id,step:S.mis.step,t:0};if(mis.id===2){setupM2();mis.ring=S.mis.ring||0;ringMeshes.forEach((r,i)=>r.visible=i>=mis.ring)}resetWorldPositions(false)}
    else if(S.hasGame&&S.mis&&MDEF[S.mis.id]){resetWorldPositions(false);startMission(S.mis.id)}
    else{const m=[1,2,3,4,5,6,7,8,9,10].find(i=>!S.done.includes(i));if(!m){clearMissionObjs();mis=null;resetWorldPositions(!S.hasGame)}else{resetWorldPositions(m<=2);startMission(m)}}}
  else{clearMissionObjs();mis=null;resetWorldPositions(!S.hasGame)}
  S.mode=mode;if(state!=='dialog')state='play';show(null);$('#hud').classList.remove('hidden');hudMode='';
  if(mode==='story'&&mis&&mis.id===1&&mis.step===0)setTimeout(()=>toast('Підійди до дядька Миколи 👴'),600);
  else toast(mode==='free'?'Вільна гра · без обмежень часу':'Продовжуємо!')}
function playStreet(){initAudio();clearMissionObjs();if(D.on)landDrone('quiet');mis=null;S.mode='free';
  P.x=-112;P.z=roadMain(-112)+4.2;P.y=H(P.x,P.z);P.vx=P.vz=P.vy=0;P.yaw=Math.PI/2;P.inCar=false;hero.grp.visible=true;
  C.x=-100;C.z=roadMain(-100)+1.3;C.y=H(C.x,C.z);C.yaw=Math.PI/2;C.v=0;C.engine=false;
  cam.yaw=Math.PI/2+.25;cam.pitch=.2;camera.position.set(P.x-4.5,P.y+2.4,P.z-1);if(S.tod<.27||S.tod>.68)S.tod=.36;
  state='play';show(null);$('#hud').classList.remove('hidden');hudMode='';toast('Вулиця Садова · нова графіка');setTimeout(()=>toast('Праворуч — огляд камерою'),1800)}
$('#glbIn').addEventListener('change',async e=>{const f=e.target.files&&e.target.files[0],k=assetSlotPick;if(!f||!k)return;
  if(f.size>40*1048576){toast('Файл завеликий (понад 40 МБ) — телефон може не впоратися');return}
  toast('Завантажуємо модель «'+f.name+'»…');
  try{const buf=await f.arrayBuffer();await importBuf(k,buf,f.name,0,'user',true);toast(ASLOTS[k].i+' Модель встановлено!');SFX.pick()}
  catch(er){toast('⚠ '+(er&&er.message||er));window.__bootFail('Не вдалося імпортувати «'+f.name+'»: '+(er&&er.message||er))}
  if(state==='menu'||$('#pTitle').textContent==='3D-РЕСУРСИ')openPanel('assets')});
function pauseGame(){if(state!=='play')return;saveState();state='pause';openPanel('pause')}
$('#bPause').addEventListener('pointerdown',e=>{e.stopPropagation();e.preventDefault();pauseGame()});
$$('[data-m]').forEach(b=>b.addEventListener('click',()=>{initAudio();const m=b.dataset.m;if(m==='newgame'){newGame(b);return}if(m==='street')playStreet();else if(m==='start')play('story');else if(m==='free')play('free');else openPanel(m)}));
$('#pBack').addEventListener('click',()=>{if(state==='pause'){state='play';show(null);$('#hud').classList.remove('hidden')}else toMenu()});
$('#rotOk').addEventListener('click',()=>{rotDismissed=true;$('#rot').classList.remove('need')});
function openPanel(k){const b=$('#pBody');let h='',t='';
  if(k==='pause'){t='ПАУЗА';h=`<div class="card"><div class="ic">⏸</div><div class="bd"><div class="nm">Гру збережено</div><div class="ds">${esc(S.callsign)} · рівень ${level()} · 🪙 ${S.coins}</div></div></div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px"><button class="sb y" data-p="resume">▶ ПРОДОВЖИТИ</button><button class="sb" data-p="carfix">🛻 ПОВЕРНУТИ ПІКАП НА ДОРОГУ</button><button class="sb" data-p="garage">ГАРАЖ</button><button class="sb" data-p="shopP">МАГАЗИН</button><button class="sb" data-p="settings">НАЛАШТУВАННЯ</button><button class="sb" data-p="menu">ГОЛОВНЕ МЕНЮ</button></div>
    <div class="nm ru" style="margin:12px 0 4px">Ручні збереження</div>${[0,1,2].map(i=>{let o=null;try{o=JSON.parse(localStorage.getItem(LS+'_slot'+i)||'null')}catch(e){}return`<div class="card"><div class="ic">💾</div><div class="bd"><div class="nm">Слот ${i+1}</div><div class="ds">${o?new Date(o.t).toLocaleString('uk-UA')+' · місій '+(o.S.done||[]).length+'/10 · 🪙 '+o.S.coins:'порожній'}</div></div><button class="sb" data-p="sv:${i}">ЗБЕРЕГТИ</button>${o?`<button class="sb" data-p="ld:${i}">ЗАВАНТАЖИТИ</button>`:''}</div>`}).join('')}<p style="opacity:.7;font-size:11px">Автозбереження відбувається кожні 5 секунд і при закритті гри.</p>
    <p style="opacity:.75;font-size:12px;margin-top:12px">Керування: ліва половина екрана — джойстик (у авто — кермо), права — камера. На клавіатурі: WASD, Shift — біг, Пробіл — стрибок, C — присісти, E — дія.</p>`}
  if(k==='missions'){t='МІСІЇ';h=MISSIONS.map((m,i)=>{const id=i+1,done=S.done.includes(id),impl=id<=10,av=impl&&(id===1||S.done.includes(id-1));return`<div class="card ${av?'':'lock'}"><div class="ic">${done?'✅':av?'🎯':'🔒'}</div><div class="bd"><div class="nm">${id}. ${m.n}</div><div class="ds">${m.d}${done?' · <b>виконано</b>':''}</div></div>${av?`<button class="sb ${done?'':'y'}" data-p="m${id}">${done?'ПОВТОРИТИ':'ГРАТИ'}</button>`:impl?'<span class="tag d">пройди попередню</span>':'<span class="tag d">скоро</span>'}</div>`}).join('')}
  if(k==='garage'){t='ГАРАЖ 102';const at=S.vact,AV=VT[at];h=`<p style="margin-top:0">Активне авто: <b>${AV.i} ${AV.n}</b> (${AV.s}) · міцність ${Math.round(C.hp)}%. Безкоштовний ремонт — заїдь на майданчик біля будівлі «Гараж 102» на в’їзді в село й зупинись.</p>`+VORDER.map(tt=>{const v=VT[tt],un=S.vun.includes(tt),act=tt===at;return`<div class="card ${un?'':'lock'}"><div class="ic">${v.i}</div><div class="bd"><div class="nm">${v.n}</div><div class="ds">${v.s}, без логотипів · ${Math.round(v.max*3.6)} км/год · бездоріжжя ${Math.round(v.off*100)}% · міцність ${v.hp}</div>${un?'':`<div class="ds">🔒 ${v.un}</div>`}</div>${un?(act?'<span class="tag g">активне</span>':`<button class="sb" data-p="vsum:${tt}">ПОДАТИ ДО МЕНЕ</button>`):''}</div>`}).join('')+`<div class="nm ru" style="margin:10px 0 6px">Фарбування «${AV.n}» (🪙 ${S.coins})</div><div class="sw">${CARCOL.map((c,i)=>`<div style="text-align:center;font-size:10px;width:62px"><div class="chip ${vehColor(at)===i?'sel':''}" data-p="col${i}" style="margin:0 auto;background:${c.stripe?'linear-gradient(#2357b8 60%,#ffd500 60%)':c.camo?'repeating-linear-gradient(45deg,#56603a 0 6px,#3e4628 6px 10px,#7a7a4e 10px 13px)':c.c}"></div>${c.n}<br>${S.colors.includes(i)?'✓':c.cost+' 🪙'}</div>`).join('')}</div><div class="nm ru" style="margin:12px 0 6px">Костюм бійця</div>${SKINS.map((sk,i)=>`<div class="card"><div class="ic" style="width:34px;height:34px;border-radius:6px;background:${sk.base};border:3px solid ${sk.c[0]}"></div><div class="bd"><div class="nm">${sk.n}</div></div>${(S.skin||0)===i?'<span class="tag g">вдягнено</span>':`<button class="sb" data-p="skin${i}">${(S.skins||[0]).includes(i)?'ВДЯГНУТИ':sk.cost+' 🪙'}</button>`}</div>`).join('')}`}
  if(k==='drones'){t='ДРОНИ 102';h=`<p style="margin-top:0">Запуск — кнопка <b>ДРОН</b> у грі (пішки). Батарея: <b>${Math.round(S.dbat*100)}%</b>, заряджається, поки дрон не літає (~45 с).</p>`+DRONES.map((d,i)=>{const un=S.drones.includes(i);return`<div class="card ${un?'':'lock'}"><div class="ic">${d.i}</div><div class="bd"><div class="nm">${d.n}</div><div class="ds">${d.d}<br>Швидкість ${Math.round(d.spd*3.6)} км/год · батарея ${Math.round(d.bat/60*10)/10} хв</div></div>${un?(S.drone===i?'<span class="tag g">обрано</span>':`<button class="sb" data-p="dsel:${i}">ОБРАТИ</button>`):`<span class="tag d">${i===1?'місія 4':'після місії 4'}</span>`}</div>`}).join('')}
  if(k==='ach'){t='ДОСЯГНЕННЯ';h=ACH.map(a=>`<div class="card ${S.ach[a.id]?'':'lock'}"><div class="ic">${a.i}</div><div class="bd"><div class="nm">${a.n}</div><div class="ds">${a.d}</div></div>${S.ach[a.id]?'<span class="tag g">✓</span>':a.soon?'<span class="tag d">скоро</span>':''}</div>`).join('')+
    `<div class="nm ru" style="margin:12px 0 6px">Рекорди</div><div class="card"><div class="bd ds">Проїхано: <b>${S.stats.km.toFixed(2)} км</b> · Стрибків: <b>${S.stats.jumps}</b> · Шевронів: <b>${S.chev.length}/${CHEV.length}</b> · Побічних завдань: <b>${Object.values(S.sq||{}).filter(v=>v===2).length}/20</b> · Місій: <b>${S.done.length}/10</b> · Досвід: <b>${S.xp}</b> · Монети: <b>${S.coins}</b></div></div>`}
  if(k==='assets'){t='3D-РЕСУРСИ';h=assetsPanelHTML()}
  if(k==='shop'){t='МАГАЗИН';const AV=VT[S.vact];h=`<p style="margin-top:0">Лише ігрові монети — жодних реальних платежів. У тебе: <b>🪙 ${S.coins}</b>. Фарбування авто — у «Гаражі».</p><div class="nm ru" style="margin:6px 0">Покращення для «${AV.n}»</div>`+
    COS.map(c=>{const own=S.cos[c.k].includes(S.vact);return`<div class="card"><div class="ic">${c.i}</div><div class="bd"><div class="nm">${c.n}</div><div class="ds">Косметика, видно на авто</div></div>${own?'<span class="tag g">встановлено</span>':`<button class="sb" data-p="cos:${c.k}">${c.c} 🪙</button>`}</div>`}).join('')+
    `<div class="nm ru" style="margin:10px 0 6px">Колір дронів</div>`+DCOL.map((d,i)=>`<div class="card"><div class="ic" style="width:30px;height:30px;border-radius:6px;background:${d.c}"></div><div class="bd"><div class="nm">${d.n}</div></div>${S.dcol===i?'<span class="tag g">обрано</span>':`<button class="sb" data-p="dcol:${i}">${S.dcols.includes(i)?'ОБРАТИ':d.cost+' 🪙'}</button>`}</div>`).join('')+
    `<div class="nm ru" style="margin:10px 0 6px">Костюм бійця</div>`+SKINS.map((sk,i)=>`<div class="card"><div class="ic" style="width:34px;height:34px;border-radius:6px;background:${sk.base};border:3px solid ${sk.c[0]}"></div><div class="bd"><div class="nm">${sk.n}</div></div>${(S.skin||0)===i?'<span class="tag g">вдягнено</span>':`<button class="sb" data-p="skin${i}">${(S.skins||[0]).includes(i)?'ВДЯГНУТИ':sk.cost+' 🪙'}</button>`}</div>`).join('')}
  if(k==='settings'){t='НАЛАШТУВАННЯ';h=`<div class="card"><div class="bd"><div class="nm">Позивний</div><input class="cs" id="csIn" maxlength="16" value="${esc(S.callsign)}"></div><button class="sb y" data-p="cs">ЗБЕРЕГТИ</button></div>
    <div class="card"><div class="bd"><div class="nm">Якість графіки</div><div class="ds">Низька — без тіней (слабкі телефони). Середня — тіні, 512px текстури. Висока — м’які тіні, 1024px текстури, більше трави.</div></div><button class="sb" data-p="q">${{low:'НИЗЬКА',medium:'СЕРЕДНЯ',high:'ВИСОКА'}[S.quality]}</button></div>
    <div class="card"><div class="bd"><div class="nm">Перезапустити гру</div><div class="ds">Потрібно, щоб нова якість текстур і трави застосувалася повністю</div></div><button class="sb" data-p="restart">ПЕРЕЗАПУСК</button></div>
    <div class="card"><div class="bd"><div class="nm">Звук</div></div><button class="sb" data-p="snd">${S.sound?'УВІМК':'ВИМК'}</button></div>
    <div class="card"><div class="bd"><div class="nm">Музика</div></div><button class="sb" data-p="mus">${S.music?'УВІМК':'ВИМК'}</button></div>
    <div class="card"><div class="bd"><div class="nm">Чутливість камери</div></div><button class="sb" data-p="sens">${S.sens.toFixed(1)}×</button></div>
    <div class="card"><div class="bd"><div class="nm">Скинути прогрес</div><div class="ds">Видалить збереження на цьому пристрої</div></div><button class="sb" data-p="reset">СКИНУТИ</button></div>
    <p style="opacity:.6;font-size:11px">Прототип «102 ТРО — Гуляйполе: Малинівка» · Етап 1. Гра вигадана: місця, персонажі й події стилізовані.</p>${Object.keys(CREDITS).length?'<p style="opacity:.75;font-size:11px"><b>Авторство 3D-моделей:</b><br>'+Object.values(CREDITS).map(esc).join('<br>')+'</p>':''}`}
  $('#pTitle').textContent=t;b.innerHTML=h;state=state==='pause'?'pause':state;show('#panel');
  if(state!=='pause')$('#hud').classList.add('hidden');panelKind=k}
let panelKind='';
$('#pBody').addEventListener('click',e=>{const el=e.target.closest('[data-p]');if(!el)return;const p=el.dataset.p;initAudio();
  if(p==='view:house'){playStreet();const h=(SLOT.houses||[])[0];if(h){cam.yaw=Math.atan2(h.x-P.x,h.z-P.z);cam.pitch=.12}return}
  if(p.startsWith('cos:')){const c=COS.find(x=>x.k===p.slice(4));if(c&&!S.cos[c.k].includes(S.vact)){if(S.coins<c.c){toast('Не вистачає монет 🪙')}else{S.coins-=c.c;S.cos[c.k].push(S.vact);rebuildCar();SFX.pick();toast(c.i+' Встановлено: '+c.n);persist()}}openPanel('shop');return}
  if(p.startsWith('dcol:')){const i=+p.slice(5),d=DCOL[i];if(!S.dcols.includes(i)){if(S.coins<d.cost){toast('Не вистачає монет 🪙');openPanel('shop');return}S.coins-=d.cost;S.dcols.push(i)}S.dcol=i;SFX.pick();persist();openPanel('shop');return}
  if(p.startsWith('sv:')){const i=+p.slice(3);saveState();try{localStorage.setItem(LS+'_slot'+i,JSON.stringify({t:Date.now(),S}));toast('💾 Збережено в слот '+(i+1))}catch(e){toast('Не вдалося зберегти')}openPanel('pause');return}
  if(p.startsWith('ld:')){const i=+p.slice(3);try{const o=JSON.parse(localStorage.getItem(LS+'_slot'+i)||'null');if(!o){toast('Слот порожній');return}localStorage.setItem(LS,JSON.stringify(o.S));localStorage.removeItem('tro102_boot');toast('Завантажуємо…');setTimeout(()=>location.reload(),300)}catch(e){toast('Не вдалося завантажити')}return}
  if(p.startsWith('dsel:')){const i=+p.slice(5);if(D.on){toast('Спершу поверни дрон')}else if(S.drones.includes(i)){S.drone=i;persist();toast(DRONES[i].i+' Обрано: '+DRONES[i].n)}openPanel('drones');return}
  if(p.startsWith('glb:')){assetSlotPick=p.slice(4);const fi=$('#glbIn');fi.value='';fi.click();return}
  if(p.startsWith('rot:')){const k=p.slice(4),A=ASSET[k];if(A){A.rot=((A.rot||0)+1)%4;try{applyAsset(k)}catch(er){toast('Помилка: '+er.message)}if(A.buf&&A.src==='user')IDB.put(k,{name:A.name,buf:A.buf,rot:A.rot})}openPanel('assets');return}
  if(p.startsWith('del:')){const k=p.slice(4);removeAssetObj(k);delete ASSET[k];IDB.del(k);toast('Повернуто вбудовану модель');openPanel('assets');return}
  if(p==='resume'){state='play';show(null);$('#hud').classList.remove('hidden');return}
  if(p==='menu'){toMenu();return}
  if(p==='settings'){openPanel('settings');return}
  if(p==='garage'){openPanel('garage');return}
  if(p==='shopP'){openPanel('shop');return}
  if(p==='carfix'){C.x=P.x+2;C.z=roadMain(P.x+2);if(Math.abs(C.z-P.z)>60){C.x=-214;C.z=roadMain(-214)+4.6}C.yaw=Math.PI/2;C.v=0;if(P.inCar){P.x=C.x;P.z=C.z}toast('Пікап на дорозі');state='play';show(null);$('#hud').classList.remove('hidden');return}
  if(/^m([3-9]|10)$/.test(p)){const id=+p.slice(1);initAudio();resetWorldPositions(false);startMission(id);if(state!=='dialog')state='play';show(null);$('#hud').classList.remove('hidden');hudMode='';return}
  if(p==='m1'||p==='m2'){const id=+p[1];S.hasGame=false;S.mis=null;if(id===1){S.done=S.done.filter(x=>x!==1&&x!==2)}else if(!S.done.includes(1))S.done.push(1);S.done=S.done.filter(x=>x!==2);play('story');return}
  if(p==='repair'){if(S.coins>=30){S.coins-=30;C.hp=100;SFX.pick();toast('🔧 Пікап як новий')}else toast('Не вистачає монет');persist();openPanel('garage');return}
  if(p.startsWith('vsum:')){const tt=p.slice(5);if(state==='pause'){summonVehicle(tt)}else toast('Подати авто можна під час гри (пауза → Гараж)');openPanel('garage');return}
  if(p.startsWith('col')){const i=+p.slice(3),c=CARCOL[i];if(!S.colors.includes(i)){if(S.coins<c.cost){toast('Не вистачає монет 🪙');return}S.coins-=c.cost;S.colors.push(i)}S.vcol[S.vact]=i;if(S.vact==='hilux')S.carColor=i;rebuildCar();SFX.pick();persist();openPanel('garage');return}
  if(p.startsWith('skin')){const i=+p.slice(4);S.skins=S.skins||[0];if(!S.skins.includes(i)){if(S.coins<SKINS[i].cost){toast('Не вистачає монет 🪙');return}S.coins-=SKINS[i].cost;S.skins.push(i)}S.skin=i;rebuildHero();SFX.pick();persist();openPanel('garage');return}
  if(p==='cs'){const v=($('#csIn').value||'').trim().slice(0,16);if(v){S.callsign=v;persist();toast('Позивний: '+v)}return}
  if(p==='q'){S.quality={low:'medium',medium:'high',high:'low'}[S.quality]||'medium';persist();applyQuality();toast('Повністю застосується після перезапуску');openPanel('settings');return}
  if(p==='restart'){saveState();try{localStorage.removeItem('tro102_boot')}catch(_){}location.reload();return}
  if(p==='snd'){S.sound=!S.sound;if(master)master.gain.value=S.sound?.8:0;persist();openPanel('settings');return}
  if(p==='mus'){S.music=!S.music;if(musG)musG.gain.value=S.music?.5:0;persist();openPanel('settings');return}
  if(p==='sens'){S.sens=S.sens>=1.8?.6:+(S.sens+.3).toFixed(1);persist();openPanel('settings');return}
  if(p==='reset'){if(el.dataset.c){try{localStorage.removeItem(LS)}catch(_){}S=defaults();rebuildCar();rebuildHero();toast('Прогрес скинуто');toMenu()}else{el.dataset.c=1;el.textContent='ТОЧНО?'}return}
});
function rebuildCar(){const old=car;car=makeCar();linearizeAll(car.grp);scene.add(car.grp);if(ASSET.pickup&&ASSET.pickup.gltf)setTimeout(()=>{try{applyAsset('pickup')}catch(e){}},0);if(old){scene.remove(old.grp);car.grp.position.copy(old.grp.position);car.grp.rotation.copy(old.grp.rotation)}}
function rebuildHero(){const vis=hero?hero.grp.visible:true;if(hero)scene.remove(hero.grp);const sk=SKINS[S.skin||0];hero=makeHuman({camo:sk,helm:sk.helm});linearizeAll(hero.grp);hero.grp.visible=vis;if(ASSET.hero&&ASSET.hero.gltf)setTimeout(()=>{try{applyAsset('hero')}catch(e){}},0);scene.add(hero.grp)}
document.addEventListener('visibilitychange',()=>{if(document.hidden){if(state==='play')pauseGame();else if(state!=='load')saveState();if(AC)AC.suspend()}else if(AC)AC.resume()});
addEventListener('resize',resize);addEventListener('orientationchange',()=>setTimeout(resize,200));
document.addEventListener('gesturestart',e=>e.preventDefault());
document.addEventListener('touchmove',e=>{if(!e.target.closest('.pb'))e.preventDefault()},{passive:false});

