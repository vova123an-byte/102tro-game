/* ================= HUD ================= */
function toast(t){const d=document.createElement('div');d.className='toast ru';d.textContent=t;$('#toasts').appendChild(d);setTimeout(()=>d.remove(),2600);while($('#toasts').children.length>3)$('#toasts').firstChild.remove()}
const miniC=document.createElement('canvas');miniC.width=miniC.height=512;
let hudMode='';
function updHUD(){droneOSD();const m=D.on?'drone':P.inCar?'car':'foot';if(m!==hudMode){hudMode=m;$('#hud').className=m;$('#speed').style.display=P.inCar?'block':'none';$('#carhp').style.display=P.inCar?'block':'none'}
  $('#hCs').textContent=S.callsign;$('#hLvl').textContent='Рів. '+level();$('#hCoin').textContent=S.coins;$('#hChev').textContent=S.chev.length+'/'+CHEV.length;
  const l=level(),a=(l-1)*(l-1)*40,b=l*l*40;$('#hXp').style.width=((S.xp-a)/(b-a)*100).toFixed(1)+'%';$('#hCarHp').style.width=C.hp+'%';
  $('#spV').textContent=Math.round(Math.abs(C.v)*3.6);$('#wheelG').setAttribute('transform',`rotate(${(C.steer*120).toFixed(1)})`);
  const o=objective();$('#oT').textContent=o.t;$('#oD').textContent=o.d;
  if(o.tg){const d=Math.round(dist2(P.inCar?C.x:P.x,P.inCar?C.z:P.z,o.tg.x,o.tg.z));$('#oDist').textContent=d+' м';marker.visible=true;marker.position.set(o.tg.x,o.tg.y,o.tg.z)}else{$('#oDist').textContent='';marker.visible=false}
  // minimap
  const mc=$('#mini'),x=mc.getContext('2d'),w=mc.width,h=mc.height,R=110,px=P.inCar?C.x:P.x,pz=P.inCar?C.z:P.z,sc=512/SIZE;
  x.save();x.clearRect(0,0,w,h);x.beginPath();x.arc(w/2,h/2,w/2,0,7);x.clip();
  x.fillStyle='#56702f';x.fillRect(0,0,w,h);const ms=w/(2*R);x.drawImage(miniC,0,0,512,512,w/2-(px+HALF)*ms,h/2-(pz+HALF)*ms,SIZE*ms,SIZE*ms);
  const toM=(ax,az)=>[(ax-px)/R*w/2+w/2,(az-pz)/R*h/2+h/2];
  if(o.tg){const[a1,a2]=toM(o.tg.x,o.tg.z);const ca=[clamp(a1,8,w-8),clamp(a2,8,h-8)];x.fillStyle='#ffd500';x.beginPath();x.arc(ca[0],ca[1],7+Math.sin(gameT*6)*2,0,7);x.fill()}
  if(!P.inCar){const[cx,cz]=toM(C.x,C.z);x.fillStyle='#7cc44a';x.fillRect(cx-5,cz-5,10,10)}
  if(D.on){const[dx,dz]=toM(D.x,D.z);x.fillStyle='#5ad8ff';x.beginPath();x.arc(dx,dz,6,0,7);x.fill()}
  {const[nx,nz]=toM(npc.grp.position.x,npc.grp.position.z);x.fillStyle='#ff8a3a';x.beginPath();x.arc(nx,nz,5,0,7);x.fill()}
  VIL.forEach((v,i)=>{if(!VILN[i]||!VILN[i].mark||!VILN[i].mark.visible)return;const[vx,vz]=toM(v.x,v.z);x.fillStyle='#ffd500';x.beginPath();x.arc(vx,vz,4.5,0,7);x.fill()})
  x.translate(w/2,h/2);x.rotate(-(P.inCar?C.yaw:P.yaw)+Math.PI);x.fillStyle='#fff';x.strokeStyle='#13244a';x.lineWidth=3;x.beginPath();x.moveTo(0,-13);x.lineTo(9,10);x.lineTo(0,5);x.lineTo(-9,10);x.closePath();x.stroke();x.fill();
  x.restore();}

