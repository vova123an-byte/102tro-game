/* ================= DIALOG ================= */
let dlgQ=[],dlgCb=null;
function showDialog(lines,cb){dlgQ=lines.slice();dlgCb=cb||null;state='dialog';$('#dlg').classList.remove('hidden');dlgNext(true)}
function dlgNext(first){if(!first&&!dlgQ.length){}const l=dlgQ.shift();if(!l){$('#dlg').classList.add('hidden');state='play';const cb=dlgCb;dlgCb=null;if(cb)cb();return}
  $('#dWho').textContent=l.w;$('#dTxt').innerHTML=l.t.replace(/\{cs\}/g,esc(S.callsign)).replace(/\n/g,'<br>');SFX.talk()}
$('#dNext').addEventListener('click',()=>dlgNext());
$('#puzGrid').addEventListener('click',e=>{const b=e.target.closest('.pz');if(b&&PUZ)PUZ.tap(+b.dataset.r,+b.dataset.c)});$('#puzX').addEventListener('click',()=>{closePuzzle();toast('Головоломку скасовано — спробуй ще раз')});
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function talkNPC(){S.stats.talk++;grant('talk');
  const first=mis&&mis.id===1&&mis.step===0;
  const lines=first?[{w:'Дядько Микола',t:'О, здоров, {cs}! Ласкаво просимо до Малинівки. Тут кожна хата знає 102-гу!'},
    {w:'Дядько Микола',t:'Твій пікап отам стоїть — ключі під сонцезахисним козирком, як завжди.'},
    {w:'Дядько Микола',t:'Їдь до центру села, там криниця й прапор. А в посадці обережно: така грязюка, що й трактор плаче!'},
    {w:S.callsign,t:'Дякую, дядьку! Слава Україні!'},{w:'Дядько Микола',t:'Героям слава! І заїжджай на вареники 😉'}]
   :[{w:'Дядько Микола',t:['Кажуть, у посадці хтось шеврони 102 загубив. Пошукай!','Біля криниці найсмачніша вода в районі.','Ти ж обережно на дорозі, бо кури тут без правил ходять.','Скоро і дрони привезуть — будеш село з неба бачити!'][Math.random()*4|0]}];
  showDialog(lines,()=>{if(first){mis.step=1;addXP(15);toast('Тепер сядь у пікап')}})}

