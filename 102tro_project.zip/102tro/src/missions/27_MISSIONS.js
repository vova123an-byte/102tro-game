/* ================= MISSIONS ================= */
const MISSIONS=[
 {n:'Прибуття до Малинівки',d:'Знайомство зі світом: поговори з дядьком Миколою і сядь у пікап.',st:1},
 {n:'Пікап 102',d:'Перша поїздка: проїдь контрольні кільця до посадки й повернись до криниці.',st:1},
 {n:'Дорога через посадку',d:'Розмита дорога, повалені дерева й копиці: проїдь 7 кілець і довези запчастини фермеру Івану.',st:1},
 {n:'Небо Малинівки',d:'Навчальна траса на FPV-дроні «Стриж»: 10 кілець за 2,5 хвилини й посадка на майданчик.',st:1},
 {n:'Допомога селу',d:'Завантаж продукти й ліки в сільраді й розвези п’яти родинам.',st:1},
 {n:'Гараж 102',d:'Знайди 4 деталі по всій карті, відремонтуй «Буревій» і забери його собі.',st:1},
 {n:'Загублений зв’язок',d:'Віднови три вузли мобільного зв’язку: головоломка з кабелями.',st:1},
 {n:'Допомога медикам',d:'Вантажним дроном «Чумак» доправ три аптечки до ФАПу.',st:1},
 {n:'Великий турнір',d:'Перегони на авто через Малинівку й Гуляйполе, потім FPV-перегони над містом.',st:1},
 {n:'Герої 102',d:'Після буревію: розчисти дороги, поверни світло, довези генератор — і святкування на площі.',st:1},
];
const RINGS=[[-150,roadMain(-150)],[-70,roadMain(-70)],[12,roadMain(12)],[roadVil(-40),-40],[roadVil(-115),-115],[roadVil(-170),-170]];
let mis=null; // {id,step,...}
function startStory(){const m=[1,2,3,4,5,6,7,8,9,10].find(i=>!S.done.includes(i));if(!m){S.mode='free';mis=null}else startMission(m)}
function setupM2(){mis.ring=0;ringMeshes.forEach(r=>scene.remove(r));ringMeshes=[];
  RINGS.forEach((p,i)=>{const nx=RINGS[Math.min(i+1,RINGS.length-1)],pv=RINGS[Math.max(i-1,0)];const dx=nx[0]-pv[0],dz=nx[1]-pv[1];
    const m=new T.Mesh(new T.TorusGeometry(4.3,.32,8,30),new T.MeshLambertMaterial({color:i%2?0xffd500:0x2f7be0,emissive:i%2?0x665500:0x0a2a66,transparent:true,opacity:.95}));
    m.position.set(p[0],H(p[0],p[1])+4.6,p[1]);m.rotation.y=Math.atan2(dx,dz);scene.add(m);ringMeshes.push(m)})}
function objective(){
  if(!mis){const so=sqObjective();if(so)return so;const nd=Object.values(S.sq||{}).filter(v=>v===2).length;return{t:S.freeWorld?'ВІЛЬНИЙ СВІТ':'ВІЛЬНА ГРА',d:`Побічні завдання ${nd}/20 · шеврони ${S.chev.length}/${CHEV.length} · говори з мешканцями (жовта позначка)`,tg:null}}
  if(mis.id===1){if(mis.step===0)return{t:'МІСІЯ 1 · ПРИБУТТЯ ДО МАЛИНІВКИ',d:'Поговори з дядьком Миколою',tg:npc.grp.position};
    return{t:'МІСІЯ 1 · ПРИБУТТЯ ДО МАЛИНІВКИ',d:'Сядь у пікап «102» (кнопка СІСТИ)',tg:car.grp.position}}
  if(mis.id===2){if(!P.inCar)return{t:'МІСІЯ 2 · ПІКАП 102',d:'Повернись у пікап',tg:car.grp.position};
    if(mis.ring<RINGS.length){const r=RINGS[mis.ring];return{t:'МІСІЯ 2 · ПІКАП 102',d:`Проїдь кільце ${mis.ring+1}/${RINGS.length}`+(mis.ring===4?' · посадка, обережно грязюка!':''),tg:new T.Vector3(r[0],H(r[0],r[1]),r[1])}}
    return{t:'МІСІЯ 2 · ПІКАП 102',d:'Повертайся й зупинись біля криниці в центрі',tg:new T.Vector3(WELL.x,H(WELL.x,WELL.z),WELL.z)}}
  if(MDEF[mis.id]){const md=MDEF[mis.id],o=md.obj(),left=Math.max(0,md.lim-mis.t);return{t:md.t,d:o.d+` · ⏱ ${Math.floor(left/60)}:${String(Math.floor(left%60)).padStart(2,'0')}`,tg:o.tg}}
  return{t:'',d:'',tg:null}}
function updMission(dt){if(!mis)return;mis.t+=dt;
  if(MDEF[mis.id]){const md=MDEF[mis.id];if(mis.t>md.lim){failMission('Час вичерпано.');return}md.update(dt);if(md.ringOp&&mis)md.ringOp();return}
  if(mis.id===2&&P.inCar){if(mis.ring<RINGS.length){const r=RINGS[mis.ring];if(dist2(C.x,C.z,r[0],r[1])<5.2){ringMeshes[mis.ring].visible=false;mis.ring++;SFX.ring();toast(mis.ring<RINGS.length?`Кільце ${mis.ring}/${RINGS.length} ✓`:'Усі кільця! Тепер до криниці');addXP(10)}}
    else if(dist2(C.x,C.z,WELL.x,WELL.z)<11&&Math.abs(C.v)<1.5){completeMission(2)}}
  ringMeshes.forEach((m,i)=>{if(!mis||mis.id!==2)return;m.material.opacity=i===mis.ring?.95:.35;m.rotation.z=Math.sin(gameT*2+i)*.05})}
function completeMission(id){if(!S.done.includes(id))S.done.push(id);SFX.win();const rw=MREW[id]||[100,80],xp=rw[0],co=rw[1];addXP(xp);S.coins+=co;
  if(VUNLOCK[id])unlockVehicle(VUNLOCK[id]);if(id===2)grant('drv');if(id===9)grant('race');if(id===4){grant('dronem');if(!S.drones.includes(2))S.drones.push(2)}persist();
  const next=id+1,hasNext=next===2||!!MDEF[next];
  showDialog([{w:'✅ МІСІЮ ВИКОНАНО',t:`«${MISSIONS[id-1].n}»\n+${xp} досвіду · +${co} монет`+(id===4?'\n📦 Відкрито вантажний дрон «Чумак»':'')+(hasNext?`\nДалі: місія ${next} «${MISSIONS[next-1].n}»`:'\n🎉 Кампанію завершено! Відкрито ВІЛЬНИЙ СВІТ: досліджуй, виконуй побічні завдання й шукай шеврони.')}],()=>{
    if(hasNext){startMission(next);toast('Місія '+next+' · '+MISSIONS[next-1].n)}else{clearMissionObjs();WX.force=null;mis=null;S.mode='free';S.freeWorld=true;persist();toast('Вільний світ відкрито!')}})}

