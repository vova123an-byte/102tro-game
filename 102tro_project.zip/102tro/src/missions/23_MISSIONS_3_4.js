/* ================= MISSIONS 3–4 ================= */
let MOBJ=[],MCOL=[];
function clearMissionObjs(){if(mis&&MDEF[mis.id]&&MDEF[mis.id].cleanup)try{MDEF[mis.id].cleanup()}catch(e){}PARTY=null;if(typeof PUZ!=='undefined'&&PUZ)closePuzzle();MOBJ.forEach(o=>{if(o.parent)o.parent.remove(o)});MOBJ=[];MCOL.forEach(c=>c.off=true);MCOL=[];ringMeshes.forEach(r=>scene.remove(r));ringMeshes=[]}
function ringMesh(x,y,z,i,r){const m=new T.Mesh(new T.TorusGeometry(r||4.3,.32,8,30),new T.MeshLambertMaterial({color:i%2?0xffd500:0x2f7be0,emissive:i%2?0x665500:0x0a2a66,transparent:true,opacity:.95}));m.position.set(x,y,z);scene.add(m);ringMeshes.push(m);return m}
function aimRings(list){ringMeshes.forEach((m,i)=>{const n=list[Math.min(i+1,list.length-1)],p=list[Math.max(i-1,0)];m.lookAt(m.position.x+(n[0]-p[0]),m.position.y+((n[1]||0)-(p[1]||0))*0,m.position.z+(n[2]-p[2]))})}
const M3RING=[-55,-90,-115,-145,-180,-215,-245].map(z=>[roadVil(z),z]);
const M3FARM={x:roadVil(-268)+15,z:-268};
const M4PAD={x:36,z:46};
const M4RING=[[48,9,74],[86,14,52],[104,18,6],[84,15,-52],[44,22,-92],[GAP1,7,-115],[-28,16,-86],[-70,12,-34],[-56,9,22],[-6,11,62]].map(([x,h,z])=>[x,H(x,z)+h,z]);
const MREW={1:[60,40],2:[120,100],3:[160,130],4:[190,150]};
const MINTRO={
  3:[{w:'Штаб 102 · рація',t:'{cs}, прийом! Фермер Іван із хутора за посадкою просить привезти запчастини для трактора.'},{w:'Штаб 102 · рація',t:'Після дощу дорога розмита, у посадці повалені дерева й копиці. Об’їжджай перешкоди, проїдь усі кільця й не розбий пікап.'},{w:'Штаб 102 · рація',t:'Маєш 3 хвилини. Удачі!'}],
  4:[{w:'Інструкторка Оксана',t:'Привіт, {cs}! Сьогодні вчимося літати на FPV-дроні «Стриж». Він швидкий, тож не поспішай на поворотах.'},{w:'Інструкторка Оксана',t:'Ліворуч — рух, праворуч — поворот і нахил камери, кнопки ВГОРУ / ВНИЗ — висота. КАМЕРА перемикає вигляд.'},{w:'Інструкторка Оксана',t:'Пролети 10 кілець за 2,5 хвилини й поверни дрон на майданчик. Одне кільце — в розриві посадки, низько!'}]};
const MDEF={
 3:{t:'МІСІЯ 3 · ДОРОГА ЧЕРЕЗ ПОСАДКУ',lim:180,
  setup(){C.x=roadVil(-28);C.z=-28;C.yaw=Math.PI;C.v=0;C.hp=100;C.y=H(C.x,C.z);P.inCar=true;C.engine=true;hero.grp.visible=false;P.x=C.x;P.z=C.z;cam.yaw=Math.PI;
    M3RING.forEach((p,i)=>ringMesh(p[0],H(p[0],p[1])+4.6,p[1],i));aimRings(M3RING.map(p=>[p[0],0,p[1]]));mis.ring=0;
    const R=rngS(33),logM=MATS.bark;[[-72,1],[-100,-1],[-128,1],[-160,-1],[-195,1],[-228,-1]].forEach(([z,s])=>{const x=roadVil(z)+s*1.5,y=H(x,z);
      const g=cylG(.26,.3,3.6,10);g.rotateZ(Math.PI/2);const m=new T.Mesh(g,logM);m.position.set(x,y+.28,z);m.rotation.y=(R()-.5)*.3;m.castShadow=m.receiveShadow=true;scene.add(m);MOBJ.push(m);
      const br=new T.Mesh(new T.IcosahedronGeometry(.9,0),MATS.lWal);br.position.set(x+s*1.7,y+.6,z);br.scale.set(1.3,.8,1);scene.add(br);MOBJ.push(br);
      MCOL.push(addCol({t:'b',x0:x-1.9,x1:x+1.9,z0:z-.35,z1:z+.35}));
      const hz=z-12,hx=roadVil(hz)-s*1.6,hy=H(hx,hz),hb=new T.Mesh(cylG(.7,.7,1.2,14),std({color:'#c3a560',roughness:1}));hb.rotation.z=Math.PI/2;hb.position.set(hx,hy+.7,hz);hb.castShadow=true;scene.add(hb);MOBJ.push(hb);MCOL.push(addCol({t:'c',x:hx,z:hz,r:.75}))});
    // farm: real house model if loaded + farmer
    const A=ASSET.house;if(A&&A.clones&&A.clones[0]){const c=A.clones[0].obj.clone();c.position.set(M3FARM.x+6,H(M3FARM.x+6,M3FARM.z),M3FARM.z);c.rotation.y=-Math.PI/2;scene.add(c);MOBJ.push(c);MCOL.push(addCol({t:'b',x0:M3FARM.x+3.2,x1:M3FARM.x+8.8,z0:M3FARM.z-3.8,z1:M3FARM.z+3.8,h:5}))}
    const f=makeHuman({shirt:'#5a4a3a',pants:'#33352f',cap:'#2f3a2a',mustache:true});linearizeAll(f.grp);f.grp.position.set(M3FARM.x,H(M3FARM.x,M3FARM.z),M3FARM.z+3);f.grp.rotation.y=-Math.PI/2;scene.add(f.grp);MOBJ.push(f.grp);mis.farmer=f},
  obj(){if(!P.inCar)return{d:'Повернись у пікап',tg:car.grp.position};if(mis.ring<M3RING.length){const r=M3RING[mis.ring];return{d:`Кільце ${mis.ring+1}/${M3RING.length}`+(mis.ring===2?' · розрив посадки, грязюка!':''),tg:new T.Vector3(r[0],H(r[0],r[1]),r[1])}}
    return{d:'Зупинись біля фермера Івана на хуторі',tg:new T.Vector3(M3FARM.x,H(M3FARM.x,M3FARM.z),M3FARM.z+3)}},
  update(dt){if(mis.farmer)mis.farmer.grp.rotation.y=lerpA(mis.farmer.grp.rotation.y,Math.atan2(C.x-M3FARM.x,C.z-M3FARM.z-3),dt*3);
    if(C.hp<=0)return failMission('Пікап «заглух» від ударів. Об’їжджай колоди й копиці обережніше.');
    if(!P.inCar)return;if(mis.ring<M3RING.length){const r=M3RING[mis.ring];if(dist2(C.x,C.z,r[0],r[1])<5.4){ringMeshes[mis.ring].visible=false;mis.ring++;SFX.ring();addXP(8);toast(mis.ring<M3RING.length?`Кільце ${mis.ring}/${M3RING.length} ✓`:'Усі кільця! До хутора')}}
    else if(dist2(C.x,C.z,M3FARM.x,M3FARM.z+3)<9&&Math.abs(C.v)<1.5){showDialog([{w:'Фермер Іван',t:'Ох, дякую, {cs}! Без цих запчастин мій трактор до весни б не завівся.'},{w:'Фермер Іван',t:'Тримай банку меду з нашої пасіки. І передай вітання хлопцям із 102-ї!'}],()=>completeMission(3))}},
  ringOp(){ringMeshes.forEach((m,i)=>{m.material.opacity=i===mis.ring?.95:.3})}},
 4:{t:'МІСІЯ 4 · НЕБО МАЛИНІВКИ',lim:150,
  setup(){if(!S.drones.includes(1)){S.drones.push(1);toast('⚡ Відкрито дрон FPV «Стриж»')}S.drone=1;S.dbat=1;if(D.on)landDrone('quiet');
    P.inCar=false;hero.grp.visible=true;P.x=M4PAD.x-2.5;P.z=M4PAD.z-2.5;P.y=H(P.x,P.z);P.yaw=Math.PI*.75;cam.yaw=P.yaw;
    const pad=new T.Group();const base=new T.Mesh(cylG(1.6,1.6,.06,28),MATS.concrete);base.position.y=.03;pad.add(base);const hm=std({color:'#ffd500',roughness:.6});
    for(const s of[-1,1]){const b=new T.Mesh(boxG(.16,.01,1.4),hm);b.position.set(s*.45,.065,0);pad.add(b)}const cb=new T.Mesh(boxG(.9,.01,.16),hm);cb.position.y=.065;pad.add(cb);
    pad.position.set(M4PAD.x,H(M4PAD.x,M4PAD.z),M4PAD.z);pad.traverse(o=>{if(o.isMesh)o.receiveShadow=true});scene.add(pad);MOBJ.push(pad);
    M4RING.forEach((p,i)=>ringMesh(p[0],p[1],p[2],i,3.6));aimRings(M4RING);mis.ring=0;
    const o=makeHuman({shirt:'#4d5a6a',pants:'#2f3138',cap:'#3b4a3b'});linearizeAll(o.grp);o.grp.position.set(M4PAD.x+2.5,H(M4PAD.x+2.5,M4PAD.z),M4PAD.z-2);scene.add(o.grp);MOBJ.push(o.grp);mis.inst=o},
  obj(){if(!D.on&&mis.ring<M4RING.length)return{d:mis.ring?'Знову запусти дрон (ДРОН)':'Натисни ДРОН, щоб запустити «Стриж»',tg:new T.Vector3(M4PAD.x,H(M4PAD.x,M4PAD.z),M4PAD.z)};
    if(mis.ring<M4RING.length){const r=M4RING[mis.ring];return{d:`Кільце ${mis.ring+1}/${M4RING.length}`+(mis.ring===5?' · низько, у розриві посадки':''),tg:new T.Vector3(r[0],r[1]-4,r[2])}}
    return{d:'Посади дрон на жовту «Н» біля криниці (знизься або натисни ПОВЕРНУТИ над нею)',tg:new T.Vector3(M4PAD.x,H(M4PAD.x,M4PAD.z),M4PAD.z)}},
  update(dt){if(mis.inst)mis.inst.grp.rotation.y=lerpA(mis.inst.grp.rotation.y,Math.atan2((D.on?D.x:P.x)-mis.inst.grp.position.x,(D.on?D.z:P.z)-mis.inst.grp.position.z),dt*3);
    if(!D.on)return;if(mis.ring<M4RING.length){const r=M4RING[mis.ring];if(Math.hypot(D.x-r[0],D.y-r[1],D.z-r[2])<3.3){ringMeshes[mis.ring].visible=false;mis.ring++;SFX.ring();addXP(6);toast(mis.ring<M4RING.length?`Кільце ${mis.ring}/${M4RING.length} ✓`:'Усі кільця! Повертайся на майданчик')}}
    else{const d=Math.hypot(D.x-M4PAD.x,D.z-M4PAD.z),h=D.y-H(M4PAD.x,M4PAD.z);if(d<2.2&&h<.7)this.finish()}},
  finish(){if(mis.done4)return;mis.done4=true;landDrone('quiet');const t=Math.round(mis.t);
      showDialog([{w:'Інструкторка Оксана',t:`Чиста посадка! Час — ${Math.floor(t/60)}:${String(t%60).padStart(2,'0')}. Батарея ${Math.round(S.dbat*100)}%.`},{w:'Інструкторка Оксана',t:'Ти готовий до справжніх завдань. Тримай доступ до вантажного дрона «Чумак» — він знадобиться для доставки аптечок.'}],()=>completeMission(4))},
  event(e){if(e==='droneLand'&&mis.ring>=M4RING.length&&Math.hypot(D.x-M4PAD.x,D.z-M4PAD.z)<2.6&&D.y-H(M4PAD.x,M4PAD.z)<5){this.finish();return}
    if(e==='droneBat')failMission('Батарея дрона сіла посеред траси. Економ заряд: менше висоти й різких маневрів.')},
  ringOp(){ringMeshes.forEach((m,i)=>{m.material.opacity=i===mis.ring?.95:.28;m.rotation.z+=.01})}}};
function missionEvent(e){if(mis&&MDEF[mis.id]&&MDEF[mis.id].event)MDEF[mis.id].event(e)}
function startMission(id,quiet){clearMissionObjs();WX.force=null;if(D.on)landDrone('quiet');S.mode='story';mis={id,step:0,t:0,ring:0};
  if(id===1||id===2){if(id===2)setupM2();return}
  const md=MDEF[id];if(!md)return;md.setup();state='play';show(null);$('#hud').classList.remove('hidden');hudMode='';
  if(!quiet&&MINTRO[id])showDialog(MINTRO[id],()=>{mis.t=0;toast(MISSIONS[id-1].n)});}
function failMission(reason){if(!mis||mis.failing)return;mis.failing=true;const id=mis.id;SFX.bump();
  showDialog([{w:'❌ МІСІЮ НЕ ВИКОНАНО',t:reason+'\nМісія почнеться спочатку.'}],()=>startMission(id,true))}

