/* ================= МІСІЇ 5–10 ================= */
function npcAt(x,z,o,face){const h=makeHuman(o||{shirt:'#4a4a42',pants:'#2f3138',cap:'#3a3936'});linearizeAll(h.grp);h.grp.position.set(x,H(x,z),z);h.grp.rotation.y=face||0;scene.add(h.grp);MOBJ.push(h.grp);return h}
function lookAtP(h,dt){const tx=P.inCar?C.x:P.x,tz=P.inCar?C.z:P.z;h.grp.rotation.y=lerpA(h.grp.rotation.y,Math.atan2(tx-h.grp.position.x,tz-h.grp.position.z),dt*3)}
const stopped=(x,z,r)=>P.inCar&&dist2(C.x,C.z,x,z)<r&&Math.abs(C.v)<1.6;
const nearFoot=(x,z,r)=>!P.inCar&&!D.on&&dist2(P.x,P.z,x,z)<r;
const V3=(x,z,dy)=>new T.Vector3(x,H(x,z)+(dy||0),z);
function gateOf(h){return{x:h.x+Math.sin(h.rot)*7,z:h.z+Math.cos(h.rot)*7}}
function crateMesh(s){const g=new T.Group(),m=std({color:'#d9cfb4',roughness:.85}),b=new T.Mesh(rbox(.5*s,.36*s,.4*s,.03),m);b.castShadow=true;g.add(b);
  const c=std({color:'#2f8a4a',roughness:.6});const a=new T.Mesh(boxG(.2*s,.06*s,.01),c);a.position.z=.201*s;g.add(a);const b2=new T.Mesh(boxG(.06*s,.2*s,.01),c);b2.position.z=.201*s;g.add(b2);return g}
const RADA={x:30,z:15},FAP={x:76,z:-22},TOWER={x:-60,z:-20};
const M7NODES=[{x:58,z:-182,n:'Вузол «Поле»'},{x:-118,z:150,n:'Вузол «Південь»'},{x:248,z:-40,n:'Вузол «Схід»'}];
const M6PARTS=[{n:'Акумулятор',i:'🔋',x:GAP2+6,z:-109},{n:'Колесо',i:'🛞',x:M3FARM.x-4,z:M3FARM.z-6},{n:'Ремінь ГРМ',i:'⚙️',x:250,z:200},{n:'Фара',i:'💡',x:-14,z:roadMain(-14)+7}];
const M9WP=[[-90,roadMain(-90)],[12,roadMain(12)],[150,roadMain(150)],[225,roadMain(225)+1],[225,70],[225,130],[185,130],[185,70],[225,70],[225,roadMain(225)+1]];
const M9RIV=[{n:'Дід Турбо',t:'uaz',c:'#8a3b30',sp:18.5},{n:'Кум Пилип',t:'l200',c:'#3f5f86',sp:19.5},{n:'Барон Болото',t:'van',c:'#6b6b3a',sp:17.5}];
const M9RINGS=[[205,12,60],[225,10,100],[245,16,140],[265,12,180],[245,20,220],[205,14,240],[185,11,190],[200,9,140]].map(([x,h,z])=>[x,H(x,z)+h,z]);
const M10TREES=[{x:-40,z:roadMain(-40)},{x:roadVil(-60),z:-60},{x:225,z:36}],M10POLES=[{x:-90.5,z:roadMain(-90.5)-6.3},{x:-60,z:roadMain(-60)-6.3}];
Object.assign(MREW,{5:[220,180],6:[240,200],7:[260,220],8:[260,240],9:[300,300],10:[500,500]});
Object.assign(MINTRO,{
 5:[{w:'Голова сільради Ганна',t:'{cs}, добре, що ти тут! Привезли гуманітарку: продукти й ліки для п’яти родин.'},{w:'Голова сільради Ганна',t:'Під’їдь до сільради, завантажимо набори, а тоді розвези по хатах — я позначу їх на карті.'}],
 6:[{w:'Майстер Петрович',t:'Здоров, {cs}! У гаражі стоїть «Буревій» — гарна машина, але розібрана.'},{w:'Майстер Петрович',t:'Треба знайти чотири деталі: акумулятор у посадці, колесо на хуторі, ремінь у міських гаражах Гуляйполя й фару біля зупинки.'},{w:'Майстер Петрович',t:'Збереш — привези в «Гараж 102», і полагодимо разом.'}]
 ,7:[{w:'Зв’язківець Олег',t:'{cs}, у районі пропав мобільний зв’язок — люди не можуть додзвонитися рідним.'},{w:'Зв’язківець Олег',t:'Три вузли зв’язку в полях вимкнулися. Під’їдь до кожної шафи, натисни ДІЯ й з’єднай кабелі, повертаючи плитки.'},{w:'Зв’язківець Олег',t:'Коли всі три запрацюють — повертайся до мене, до вежі за селом.'}]
 ,8:[{w:'Фельдшерка Марія',t:'{cs}, до ФАПу не проїхати — міст на польовій дорозі розмило. А нам потрібні аптечки.'},{w:'Фельдшерка Марія',t:'Візьми вантажний дрон «Чумак». Три ящики стоять біля майданчика в центрі. Знизься над ящиком — він зачепиться.'},{w:'Фельдшерка Марія',t:'Опусти кожен ящик на зелену позначку біля ФАПу. Стеж за батареєю!'}]
 ,9:[{w:'Ведучий турніру',t:'Увага-увага! Великий турнір 102-ї: перегони на авто й на дронах!'},{w:'Ведучий турніру',t:'Суперники: Дід Турбо на «Бобику», Кум Пилип на «Соколі» та Барон Болото на «Мандрівнику». Два кола через Малинівку й Гуляйполе.'},{w:'Ведучий турніру',t:'Перший етап — авто. Займи перше місце. Другий — FPV-перегони над містом швидше за Пані Блискавку!'}]
 ,10:[{w:'Штаб 102 · рація',t:'{cs}, після буревію громаді потрібна допомога. Повалені дерева перекрили дороги, на вулиці Садовій без світла.'},{w:'Штаб 102 · рація',t:'Розчисти три дороги, віднови живлення на двох стовпах і довези генератор із «Гаража 102» до ФАПу.'},{w:'Штаб 102 · рація',t:'Увечері село збирається на площі. Тебе там чекають.'}]});
Object.assign(MDEF,{
 5:{t:'МІСІЯ 5 · ДОПОМОГА СЕЛУ',lim:420,
  setup(){const vil=houses.filter(h=>!h.town);const pick=[];const pref=[[-120,0],[100,0],[0,-80],[0,120],[60,40]];pref.forEach(([px,pz])=>{let b=null,bd=1e9;vil.forEach(h=>{if(pick.includes(h))return;const d=dist2(h.x,h.z,px+10,pz+20);if(d<bd){bd=d;b=h}});if(b)pick.push(b)});
    mis.homes=pick.map(h=>({...gateOf(h),done:false}));mis.loaded=false;mis.head=npcAt(RADA.x-3,RADA.z+2,{shirt:'#6a3a4a',pants:'#2f3138',cap:'#5a4a3a'},0);P.inCar=false;hero.grp.visible=true;
    if(dist2(C.x,C.z,RADA.x,RADA.z)>60){C.x=RADA.x-8;C.z=roadMain(RADA.x-8)+1.4;C.yaw=Math.PI/2;C.v=0;C.y=H(C.x,C.z)}P.x=C.x+2;P.z=C.z+2.2;P.y=H(P.x,P.z)},
  obj(){if(!mis.loaded)return{d:'Під’їдь на авто до сільради й зупинись — завантаження',tg:V3(RADA.x,RADA.z+4)};const left=mis.homes.filter(h=>!h.done);
    if(left.length){const h=left[0];return{d:`Доставлено ${5-left.length}/5 · їдь до наступної хати й зупинись біля воріт`,tg:V3(h.x,h.z)}}return{d:'Повернись до сільради й зупинись',tg:V3(RADA.x,RADA.z+4)}},
  update(dt){lookAtP(mis.head,dt);
    if(!mis.loaded){if(stopped(RADA.x,RADA.z+4,9)){mis.loaded=true;SFX.pick();toast('📦 Завантажено 5 наборів');if(car&&(S.vact==='hilux'||S.vact==='l200')){mis.boxes=[];for(let i=0;i<5;i++){const c=crateMesh(1);c.position.set((i%2?.35:-.35),1.2+Math.floor(i/2)*.36,-1.3-(i%3)*.4);car.body.add(c);mis.boxes.push(c)}}}return}
    const left=mis.homes.filter(h=>!h.done);if(left.length){const h=left[0];if(stopped(h.x,h.z,7)){h.done=true;SFX.pick();addXP(15);S.coins+=10;const nm=['Баба Галя','Дід Степан','Тітка Оля','Пан Василь','Сім’я Коваленків'][4-left.length+1-1]||'Мешканці';
        toast(`🏠 ${nm}: «Дякуємо, синку! Хай береже вас Бог!» (+10 🪙)`);if(mis.boxes&&mis.boxes.length){const b=mis.boxes.pop();b.parent.remove(b)}const n=npcAt(h.x,h.z,{shirt:['#6b4a6a','#4a5a6a','#7a5a3a','#3a5a4a','#5a3a3a'][left.length-1],pants:'#2f3138',cap:'#4a4a42',mustache:left.length%2===1});mis.extra=(mis.extra||[]).concat(n)}}
    else if(stopped(RADA.x,RADA.z+4,9))showDialog([{w:'Голова сільради Ганна',t:'Усі п’ять родин отримали допомогу. Дякую тобі, {cs}!'},{w:'Голова сільради Ганна',t:'Візьми «Мандрівника» — він стоїть біля гаража. На бусі зручно возити людей і вантажі.'}],()=>completeMission(5))},
  cleanup(){if(mis&&mis.boxes)mis.boxes.forEach(b=>b.parent&&b.parent.remove(b))}},
 6:{t:'МІСІЯ 6 · ГАРАЖ 102',lim:900,
  setup(){mis.got=[];mis.pm=M6PARTS.map((p,i)=>{const g=new T.Group(),m=std({color:'#ffd500',emissive:'#6a5500',roughness:.4});const b=new T.Mesh(rbox(.5,.35,.35,.05),m);b.castShadow=true;g.add(b);g.position.set(p.x,H(p.x,p.z)+.6,p.z);scene.add(g);MOBJ.push(g);return g});
    mis.mech=npcAt(GARAGE.x+3,GARAGE.z+5.5,{shirt:'#3a4a6a',pants:'#2a2d3a',cap:'#2a2d3a',mustache:true},0);
    if(!PARKED.patrol&&S.vact!=='patrol'){const o=makeCar('patrol');linearizeAll(o.grp);o.grp.position.set(GARAGE.x+5,H(GARAGE.x+5,GARAGE.z+.5),GARAGE.z+.5);o.grp.children.forEach(c=>{});o.wheels.forEach((w,i)=>{if(i<2)w.piv.visible=false});o.body.rotation.z=.04;scene.add(o.grp);MOBJ.push(o.grp);mis.shell=o}},
  obj(){const left=M6PARTS.filter((p,i)=>!mis.got.includes(i));if(left.length){const i=M6PARTS.indexOf(left[0]);return{d:`Деталі ${mis.got.length}/4 · шукай: ${left.map(p=>p.i+' '+p.n).join(', ')}`,tg:V3(left[0].x,left[0].z)}}
    if(!mis.fixing)return{d:'Привези деталі в «Гараж 102» і підійди до майстра Петровича',tg:V3(GARAGE.x+3,GARAGE.z+5.5)};return{d:`Ремонт «Буревія»: ${Math.round(mis.fix*100)}%`,tg:null}},
  update(dt){lookAtP(mis.mech,dt);mis.pm.forEach((g,i)=>{if(mis.got.includes(i))return;g.rotation.y+=dt*1.5;g.position.y=H(g.position.x,g.position.z)+.6+Math.sin(gameT*3+i)*.12;
      const px=P.inCar?C.x:P.x,pz=P.inCar?C.z:P.z,pp=M6PARTS[i];if(dist2(px,pz,pp.x,pp.z)<(P.inCar?4.5:2.2)){mis.got.push(i);g.visible=false;SFX.pick();addXP(10);toast(`${M6PARTS[i].i} Знайдено: ${M6PARTS[i].n} (${mis.got.length}/4)`)}});
    if(mis.got.length===4&&!mis.fixing&&nearFoot(GARAGE.x+3,GARAGE.z+5.5,4)){mis.fixing=true;mis.fix=0;toast('🔧 Ремонтуємо разом із Петровичем…')}
    if(mis.fixing&&mis.fix<1){mis.fix+=dt/7;if(Math.random()<dt*14)emit(GARAGE.x+5,H(GARAGE.x,GARAGE.z)+1.2,GARAGE.z+2.5,(Math.random()-.5)*3,2+Math.random()*2,(Math.random()-.5)*3,.5,.15,'#ffd27a',.9,-1);if(Math.random()<dt*3)tone(900+Math.random()*400,500,.08,'square',.04);
      if(mis.fix>=1){if(mis.shell)mis.shell.wheels.forEach(w=>w.piv.visible=true);showDialog([{w:'Майстер Петрович',t:'Готово! Чуєш, як муркоче двигун? «Буревій» тепер твій, {cs}.'},{w:'Майстер Петрович',t:'А якщо твоя машина побита — заїжджай сюди, на майданчик. Ремонт для 102-ї безкоштовний!'}],()=>completeMission(6))}}}},
 7:{t:'МІСІЯ 7 · ЗАГУБЛЕНИЙ ЗВ’ЯЗОК',lim:720,
  setup(){mis.fixed=[];mis.cab=M7NODES.map((n,i)=>{const y=H(n.x,n.z),g=new T.Group();const pole=new T.Mesh(cylG(.12,.16,7,6),MATS.concrete);pole.position.y=3.5;g.add(pole);const box=new T.Mesh(boxG(.8,1.2,.5),MATS.galv);box.position.set(0,1.3,.45);g.add(box);
      const led=new T.Mesh(new T.SphereGeometry(.06,8,6),std({color:'#ff3020',emissive:'#ff2010'}));led.position.set(.25,1.85,.71);g.add(led);g.userData.led=led;for(let k=0;k<3;k++){const ant=new T.Mesh(boxG(.12,.9,.06),std({color:'#e8e8e4',roughness:.5}));ant.position.set(Math.cos(k*2.1)*.3,6.6,Math.sin(k*2.1)*.3);ant.rotation.y=-k*2.1;g.add(ant)}
      g.position.set(n.x,y,n.z);g.traverse(o=>{if(o.isMesh)o.castShadow=true});scene.add(g);MOBJ.push(g);MCOL.push(addCol({t:'c',x:n.x,z:n.z,r:.4}));return g});
    const tw=new T.Group();for(const s of[[-1,-1],[1,-1],[-1,1],[1,1]]){const l=new T.Mesh(beamG(V(s[0]*1.4,0,s[1]*1.4),V(s[0]*.3,24,s[1]*.3),.08),MATS.galv);tw.add(l)}for(let h=3;h<24;h+=3){const r=1.4-h/24*1.1;tw.add(new T.Mesh(boxG(r*2,.06,.06),MATS.galv).translateY(h).translateZ(r));tw.add(new T.Mesh(boxG(r*2,.06,.06),MATS.galv).translateY(h).translateZ(-r))}
    tw.position.set(TOWER.x,H(TOWER.x,TOWER.z),TOWER.z);scene.add(tw);MOBJ.push(tw);MCOL.push(addCol({t:'c',x:TOWER.x,z:TOWER.z,r:1.6}));mis.oleg=npcAt(TOWER.x+3,TOWER.z+3,{shirt:'#5a5a4a',pants:'#2f3138',cap:'#ffd500'},0)},
  obj(){const left=M7NODES.filter((n,i)=>!mis.fixed.includes(i));if(left.length){const n=left.reduce((a,b)=>dist2(P.x,P.z,a.x,a.z)<dist2(P.x,P.z,b.x,b.z)?a:b);return{d:`Вузли ${mis.fixed.length}/3 · ${n.n}: підійди до шафи й натисни ДІЯ`,tg:V3(n.x,n.z)}}return{d:'Зв’язок відновлено! Повертайся до Олега біля вежі',tg:V3(TOWER.x+3,TOWER.z+3)}},
  interact(){if(P.inCar||D.on)return null;for(let i=0;i<3;i++){if(mis.fixed.includes(i))continue;const n=M7NODES[i];if(dist2(P.x,P.z,n.x,n.z)<3)return{l:'ДІЯ',fn:()=>openPuzzle(4,3,()=>{mis.fixed.push(i);mis.cab[i].userData.led.material=std({color:'#30ff60',emissive:'#10c030'});SFX.win();addXP(20);toast(`📶 ${n.n} відновлено (${mis.fixed.length}/3)`)})}}return null},
  update(dt){lookAtP(mis.oleg,dt);if(mis.fixed.length===3&&nearFoot(TOWER.x+3,TOWER.z+3,3.5)&&!mis.fin){mis.fin=true;showDialog([{w:'Зв’язківець Олег',t:'Є сигнал! Люди вже телефонують рідним — я чую, як дзвонять телефони по всьому селу.'},{w:'Зв’язківець Олег',t:'Ти справжній майстер, {cs}. Дякую від усієї громади!'}],()=>completeMission(7))}}},
 8:{t:'МІСІЯ 8 · ДОПОМОГА МЕДИКАМ',lim:480,
  setup(){if(!S.drones.includes(2))S.drones.push(2);S.drone=2;S.dbat=1;if(D.on)landDrone('quiet');P.inCar=false;hero.grp.visible=true;P.x=M4PAD.x-2.5;P.z=M4PAD.z-3;P.y=H(P.x,P.z);
    mis.cpos=[0,1,2].map(i=>({x:M4PAD.x+(i-1)*1.4,z:M4PAD.z+2.4,on:true}));mis.crates=mis.cpos.map(q=>{const c=crateMesh(1.4);c.position.set(q.x,H(q.x,q.z)+.25,q.z);scene.add(c);MOBJ.push(c);return c});mis.dl=0;mis.carry=null;
    const f=new T.Group(),y=H(FAP.x,FAP.z);const w=new T.Mesh(boxG(8,3,6),MATS.plasterW);w.position.y=1.5;f.add(w);const r=new T.Mesh(boxG(8.6,.2,6.6),MATS.metalGreen);r.position.y=3.1;f.add(r);
    const sm=signMat('ФАП · МЕДПУНКТ','#f2f2ec','#1f7a4a');const sg=new T.Mesh(planeG(3.6,.7),sm);sg.position.set(0,2.5,3.02);f.add(sg);const cr=std({color:'#1f9a4a',emissive:'#0a3a1a'});const c1=new T.Mesh(boxG(.6,.2,.04),cr);c1.position.set(2.6,2.5,3.03);f.add(c1);const c2=new T.Mesh(boxG(.2,.6,.04),cr);c2.position.set(2.6,2.5,3.03);f.add(c2);
    f.position.set(FAP.x,y,FAP.z-5);f.traverse(o=>{if(o.isMesh){o.castShadow=o.receiveShadow=true}});scene.add(f);MOBJ.push(f);MCOL.push(addCol({t:'b',x0:FAP.x-4,x1:FAP.x+4,z0:FAP.z-8,z1:FAP.z-2,h:3.4}));
    const dz=new T.Mesh(cylG(2,2,.04,24),std({color:'#2fbf5a',emissive:'#0a4a1a',transparent:true,opacity:.6}));dz.position.set(FAP.x,y+.03,FAP.z+2);scene.add(dz);MOBJ.push(dz);mis.maria=npcAt(FAP.x+3,FAP.z,{shirt:'#e8e8e4',pants:'#5a6a8a',cap:'#e8e8e4'},0)},
  obj(){if(!D.on&&mis.dl<3)return{d:`Аптечки ${mis.dl}/3 · запусти вантажний дрон (ДРОН)`,tg:V3(M4PAD.x,M4PAD.z)};if(mis.dl>=3)return{d:'Усі аптечки доставлено! Поверни дрон (ПОВЕРНУТИ)',tg:null};
    if(!mis.carry)return{d:`Аптечки ${mis.dl}/3 · знизься над ящиком біля майданчика`,tg:V3(M4PAD.x,M4PAD.z+2.4)};return{d:`Аптечки ${mis.dl}/3 · неси до ФАПу й опусти на зелену позначку`,tg:V3(FAP.x,FAP.z+2)}},
  update(dt){lookAtP(mis.maria,dt);if(D.crate)D.crate.visible=!!mis.carry;if(!D.on){if(mis.dl>=3&&!mis.fin){mis.fin=true;showDialog([{w:'Фельдшерка Марія',t:'Три аптечки на місці! Тепер маємо чим допомагати людям. Дякую, {cs}!'}],()=>completeMission(8))}return}
    const gy=H(D.x,D.z);if(!mis.carry){for(let i=0;i<3;i++){const q=mis.cpos[i];if(!q.on)continue;if(dist2(D.x,D.z,q.x,q.z)<1.6&&D.y-gy<2.6){q.on=false;mis.carry=mis.crates[i];mis.carry.visible=false;SFX.pick();toast('📦 Ящик зачеплено');break}}}
    else if(dist2(D.x,D.z,FAP.x,FAP.z+2)<2.4&&D.y-gy<3){const c=mis.carry;mis.carry=null;c.position.set(FAP.x+(mis.dl-1)*.9,gy+.25,FAP.z+2);c.visible=true;mis.dl++;SFX.ring();addXP(15);toast(`💚 Аптечку доставлено (${mis.dl}/3)`)}},
  event(e){if(e==='droneBat')failMission('Батарея «Чумака» сіла з вантажем. Літай нижче й без зайвих маневрів.')}},
 9:{t:'МІСІЯ 9 · ВЕЛИКИЙ ТУРНІР',lim:600,
  setup(){mis.stage=0;mis.lap=0;mis.wp=0;mis.cd=4;mis.riv=[];const start=M9WP[0];
    C.x=start[0];C.z=start[1]+1.5;C.yaw=Math.PI/2;C.v=0;C.y=H(C.x,C.z);C.hp=100;P.inCar=true;C.engine=true;hero.grp.visible=false;cam.yaw=C.yaw;
    M9RIV.forEach((r,i)=>{const o=makeCar(r.t);o.paint.map=texPaint(r.c,false);o.paint.needsUpdate=true;linearizeAll(o.grp);scene.add(o.grp);MOBJ.push(o.grp);
      const rv={o,n:r.n,sp:r.sp,x:start[0]-5-i*5,z:start[1]-1.5+(i%2)*3,yaw:Math.PI/2,v:0,wp:1,lap:0,prog:0,fin:false};mis.riv.push(rv)});
    M9WP.forEach((p,i)=>{const m=ringMesh(p[0],H(p[0],p[1])+4.8,p[1],i,5.5);m.material.opacity=.25});aimRings(M9WP.map(p=>[p[0],0,p[1]]));mis.ring=1},
  obj(){if(mis.stage===0){if(mis.cd>0)return{d:`Старт через ${Math.ceil(mis.cd-1)||'…'}`,tg:null};const pos=1+mis.riv.filter(r=>r.prog>mis.wp).length;const w=M9WP[mis.wp%M9WP.length];return{d:`Авто: коло ${Math.min(2,mis.lap+1)}/2 · місце ${pos}/4`,tg:V3(w[0],w[1])}}
    if(mis.stage===1){if(!D.on)return{d:'Етап 2: запусти FPV «Стриж» (ДРОН). Рекорд Пані Блискавки — 70 с',tg:null};const r=M9RINGS[Math.min(mis.ring,M9RINGS.length-1)];return{d:`FPV: кільце ${mis.ring+1}/8 · ${(mis.dt||0).toFixed(1)} с`,tg:new T.Vector3(r[0],r[1]-4,r[2])}}return{d:'',tg:null}},
  update(dt){if(mis.stage===0){if(mis.cd>0){const b=Math.ceil(mis.cd);mis.cd-=dt;C.v=0;if(Math.ceil(mis.cd)!==b&&mis.cd>0)tone(600,600,.15,'square',.1);if(mis.cd<=0){tone(1200,1200,.4,'square',.12);toast('🏁 СТАРТ!')}return}
      const N=M9WP.length;if(P.inCar){const w=M9WP[mis.wp%N];if(dist2(C.x,C.z,w[0],w[1])<9){mis.wp++;SFX.ring();if(mis.wp%N===0){mis.lap++;toast(mis.lap<2?'Коло 2/2!':'🏁 Фініш!')}}}
      ringMeshes.forEach((m,i)=>m.material.opacity=i===mis.wp%N?.9:.15);
      for(const r of mis.riv){if(r.fin)continue;const w=M9WP[r.wp%N],dx=w[0]-r.x,dz=w[1]-r.z,d=Math.hypot(dx,dz);const nx=M9WP[(r.wp+1)%N],turn=Math.abs(angD(Math.atan2(dx,dz),Math.atan2(nx[0]-w[0],nx[1]-w[1])));
        const myProg=mis.wp,band=clamp(1+(myProg-r.prog)*.03,.85,1.12),tgt=r.sp*band*(d<25?1-Math.min(.45,turn*.3):1);r.v=lerp(r.v,tgt,dt*.8);r.yaw=lerpA(r.yaw,Math.atan2(dx,dz),dt*2.6);
        r.x+=Math.sin(r.yaw)*r.v*dt;r.z+=Math.cos(r.yaw)*r.v*dt;if(d<8){r.wp++;if(r.wp%N===0)r.lap++;if(r.lap>=2){r.fin=true;mis.finished=(mis.finished||0)+1}}r.prog=r.wp+(1-Math.min(1,d/60))*.9;
        const y=H(r.x,r.z);r.o.grp.position.set(r.x,y,r.z);r.o.grp.rotation.set(0,r.yaw,0);r.o.wheels.forEach(wh=>wh.sp.rotation.x+=r.v*dt/.42);
        if(P.inCar&&dist2(r.x,r.z,C.x,C.z)<2.6){const a=Math.atan2(C.x-r.x,C.z-r.z);C.x+=Math.sin(a)*.25;C.z+=Math.cos(a)*.25;C.v*=.97;r.v*=.9}}
      if(mis.lap>=2){const place=1+(mis.finished||0);if(place===1){showDialog([{w:'Ведучий турніру',t:'Перше місце на авто — {cs}! Другий етап — FPV-перегони: 8 кілець над містом швидше за 70 секунд!'}],()=>{mis.stage=1;mis.ring=0;mis.dt=0;clearRingsOnly();M9RINGS.forEach((p,i)=>ringMesh(p[0],p[1],p[2],i,3.8));aimRings(M9RINGS);
          mis.riv.forEach(r=>r.o.grp.visible=false);if(!S.drones.includes(1))S.drones.push(1);S.drone=1;S.dbat=1;if(P.inCar){C.v=0;exitCar()}})}else failMission(`Місце ${place}. Для перемоги потрібне перше! Зрізай повороти й не врізайся в суперників.`)}return}
    if(mis.stage===1){ringMeshes.forEach((m,i)=>m.material.opacity=i===mis.ring?.95:.2);if(!D.on)return;mis.dt+=dt;const r=M9RINGS[mis.ring];
      if(r&&Math.hypot(D.x-r[0],D.y-r[1],D.z-r[2])<3.4){ringMeshes[mis.ring].visible=false;mis.ring++;SFX.ring();if(mis.ring>=8){const t=mis.dt;landDrone('quiet');
        if(t<=70)showDialog([{w:'Ведучий турніру',t:`${t.toFixed(1)} с! Рекорд Пані Блискавки побито! Абсолютний переможець турніру — {cs}!`}],()=>completeMission(9));else failMission(`Час ${t.toFixed(1)} с — повільніше за рекорд 70 с. Ще раз!`)}}
      if(mis.dt>110)failMission('Задовго. Тримай висоту й лети прямо крізь кільця.')}},
  event(e){if(e==='droneBat')failMission('Батарея сіла до фінішу.')}},
 10:{t:'МІСІЯ 10 · ГЕРОЇ 102',lim:1200,
  setup(){WX.force='storm';setWeather('storm',true);S.tod=.62;mis.trees=M10TREES.map((t,i)=>{const g=new T.Group(),y=H(t.x,t.z);const tr=new T.Mesh(cylG(.32,.4,9,9),MATS.bark);tr.rotation.z=Math.PI/2;tr.rotation.y=(i-1)*.5;tr.position.y=.4;g.add(tr);
      for(let k=0;k<4;k++){const c=new T.Mesh(new T.IcosahedronGeometry(1.4,0),MATS.lWal);c.position.set(3+k*.6,.9,(k%2-.5)*1.4);c.scale.set(1.2,.8,1);g.add(c)}g.position.set(t.x,y,t.z);g.traverse(o=>{if(o.isMesh)o.castShadow=true});scene.add(g);MOBJ.push(g);
      const col=addCol({t:'b',x0:t.x-4.6,x1:t.x+4.6,z0:t.z-1.2,z1:t.z+1.2});MCOL.push(col);return{g,col,done:false,p:0}});
    mis.poles=M10POLES.map(p=>({...p,done:false}));mis.gen=0;mis.party=false},
  obj(){const tl=mis.trees.filter(t=>!t.done);if(tl.length){const t=tl[0],i=mis.trees.indexOf(t),T0=M10TREES[i];return{d:`Дерева ${3-tl.length}/3 · під’їдь на авто впритул і зупинись — буксируємо`,tg:V3(T0.x,T0.z)}}
    const pl=mis.poles.filter(p=>!p.done);if(pl.length)return{d:`Живлення ${2-pl.length}/2 · підійди до стовпа з іскрами й натисни ДІЯ`,tg:V3(pl[0].x,pl[0].z)};
    if(mis.gen===0)return{d:'Забери генератор у «Гаражі 102» (зупинись на майданчику)',tg:V3(GARAGE.x,GARAGE.z+7)};if(mis.gen===1)return{d:'Довези генератор до ФАПу й зупинись',tg:V3(FAP.x,FAP.z+4)};return{d:'Свято на площі біля криниці! Підійди до людей',tg:V3(WELL.x-6,WELL.z)}},
  interact(){if(P.inCar||D.on)return null;for(const p of mis.poles){if(!p.done&&mis.trees.every(t=>t.done)&&dist2(P.x,P.z,p.x,p.z)<3.2)return{l:'ДІЯ',fn:()=>openPuzzle(3,3,()=>{p.done=true;SFX.win();addXP(20);toast('⚡ Світло на вулиці Садовій повернулося ('+mis.poles.filter(q=>q.done).length+'/2)')})}}return null},
  update(dt){for(let i=0;i<mis.trees.length;i++){const t=mis.trees[i];if(t.done)continue;const T0=M10TREES[i];if(stopped(T0.x,T0.z,9.5)){t.p+=dt/3;if(Math.random()<dt*10)emit(T0.x,H(T0.x,T0.z)+1,T0.z,(Math.random()-.5)*2,1.5,(Math.random()-.5)*2,1,.4,'#8a7a5a',.5,1);
        if(t.p>=1){t.done=true;t.col.off=true;t.g.visible=false;SFX.pick();addXP(15);toast(`🌳 Дорогу розчищено (${mis.trees.filter(q=>q.done).length}/3)`)}}else t.p=Math.max(0,t.p-dt*.3);break}
    for(const p of mis.poles)if(!p.done&&Math.random()<dt*6)emit(p.x,H(p.x,p.z)+8.8,p.z,(Math.random()-.5)*4,1+Math.random()*2,(Math.random()-.5)*4,.4,.12,'#9fd8ff',1,-1);
    if(mis.trees.every(t=>t.done)&&mis.poles.every(p=>p.done)){if(mis.gen===0&&stopped(GARAGE.x,GARAGE.z+7,9)){mis.gen=1;SFX.pick();toast('🔌 Генератор завантажено')}
      else if(mis.gen===1&&stopped(FAP.x,FAP.z+4,10)){mis.gen=2;SFX.win();toast('💡 ФАП має світло! Буревій ущух.');WX.force='clear';setWeather('clear',true);S.tod=.78;startParty()}}
    if(mis.gen===2){updParty(dt);if(!mis.ceremony&&nearFoot(WELL.x-6,WELL.z,7)){mis.ceremony=true;showDialog([
      {w:'Голова сільради Ганна',t:'Дорогі односельці! Сьогодні ми дякуємо людям, які були поруч, коли було найважче.'},
      {w:'Дядько Микола',t:'{cs}, ти привіз нам допомогу, полагодив зв’язок, світло й дороги. Малинівка тебе не забуде!'},
      {w:'Фельдшерка Марія',t:'І ліки доставив, коли до ФАПу не було проїзду. Дякуємо!'},
      {w:'Командир 102 ТРО',t:'За мужність і турботу про громаду — відзнака «Герой 102». Слава Україні!'},
      {w:'Усі',t:'Героям слава! 🇺🇦'}],()=>{grant('hero');S.ach.hero=S.ach.hero||Date.now();completeMission(10)})}}}}});
function clearRingsOnly(){ringMeshes.forEach(r=>scene.remove(r));ringMeshes=[]}
/* святкування */
let PARTY=null;
function startParty(){PARTY={t:0,objs:[]};const cx=WELL.x-4,cz=WELL.z+2;const bulbs=[];const colors=['#ffd500','#2f7be0','#ff6a3a','#7cf05a','#ffffff'];
  for(let i=0;i<36;i++){const a=i/36*Math.PI*2,x=cx+Math.cos(a)*10,z=cz+Math.sin(a)*7,y=H(x,z)+3.2+Math.sin(i*1.3)*.2;const b=new T.Mesh(new T.SphereGeometry(.09,8,6),std({color:colors[i%5],emissive:colors[i%5]}));b.position.set(x,y,z);scene.add(b);MOBJ.push(b);bulbs.push(V(x,y,z))}
  const wp=[];for(let i=0;i<bulbs.length;i++){const a=bulbs[i],b=bulbs[(i+1)%bulbs.length];wp.push(a.x,a.y,a.z,b.x,b.y-.1,b.z)}const wg=new T.BufferGeometry();wg.setAttribute('position',new T.Float32BufferAttribute(wp,3));const ln=new T.LineSegments(wg,new T.LineBasicMaterial({color:0x222222}));scene.add(ln);MOBJ.push(ln);
  const ppl=[{shirt:'#6a3a4a',cap:'#5a4a3a'},{shirt:'#47453c',cap:'#3a3936',mustache:true},{shirt:'#e8e8e4',cap:'#e8e8e4'},{shirt:'#4d5a6a',cap:'#3b4a3b'},{shirt:'#5a4a3a',cap:'#2f3a2a',mustache:true},{shirt:'#3a4a6a',cap:'#2a2d3a',mustache:true},{shirt:'#7a5a3a',cap:'#4a4a42'},{shirt:'#3a5a4a',cap:'#4a4a42'}];
  ppl.forEach((o,i)=>{const a=i/ppl.length*Math.PI*2,h=npcAt(cx+Math.cos(a)*5,cz+Math.sin(a)*3.5,Object.assign({pants:'#2f3138'},o),a+Math.PI);PARTY.objs.push(h)});
  const cmd=npcAt(cx,cz-1,{camo:SKINS[0],helm:SKINS[0].helm},0);PARTY.objs.push(cmd)}
function updParty(dt){if(!PARTY)return;PARTY.t+=dt;PARTY.objs.forEach((h,i)=>{h.body.position.y=Math.abs(Math.sin(PARTY.t*4+i))*.08;h.arms[1].rotation.x=-1.2+Math.sin(PARTY.t*5+i)*.6;lookAtP(h,dt)});
  if(Math.random()<dt*1.2){const x=WELL.x-4+(Math.random()-.5)*30,z=WELL.z+(Math.random()-.5)*20,y=H(x,z)+22+Math.random()*10,col=['#ffd500','#2f7be0','#ff6a3a','#7cf05a','#ffffff'][Math.random()*5|0];
    for(let i=0;i<40;i++){const a=Math.random()*6.28,b=Math.random()*3.14,s=6+Math.random()*4;emit(x,y,z,Math.cos(a)*Math.sin(b)*s,Math.cos(b)*s,Math.sin(a)*Math.sin(b)*s,1.6,.5,col,1,-1)}noise(.5,600,.25,'lowpass');setTimeout(()=>noise(1.2,300,.2,'lowpass'),200)}}
/* головоломка з’єднання кабелів */
let PUZ=null;
function openPuzzle(cols,rows,onDone){const N=1,E=2,Sb=4,W=8,rot=b=>((b<<1)|(b>>3))&15;
  const grid=[];for(let r=0;r<rows;r++){grid.push([]);for(let c=0;c<cols;c++)grid[r].push(0)}
  const r0=Math.floor(Math.random()*rows),r1=Math.floor(Math.random()*rows);let r=r0,c=0;const path=[[r,c]],seen=new Set([r+','+c]);
  while(c<cols-1||r!==r1){const opts=[];if(c<cols-1)opts.push([r,c+1],[r,c+1]);if(r<rows-1&&!seen.has((r+1)+','+c))opts.push([r+1,c]);if(r>0&&!seen.has((r-1)+','+c))opts.push([r-1,c]);
    if(c===cols-1){opts.length=0;opts.push([r+(r1>r?1:-1),c])}const nx=opts[Math.random()*opts.length|0];if(seen.has(nx[0]+','+nx[1])&&nx[1]===c)continue;path.push(nx);seen.add(nx[0]+','+nx[1]);r=nx[0];c=nx[1]}
  const dirB=(a,b)=>b[0]<a[0]?N:b[0]>a[0]?Sb:b[1]>a[1]?E:W,opp=d=>d===N?Sb:d===Sb?N:d===E?W:E;
  path.forEach((p,i)=>{let b=0;if(i===0)b|=W;else b|=opp(dirB(path[i-1],p));if(i===path.length-1)b|=E;else b|=dirB(p,path[i+1]);grid[p[0]][p[1]]=b});
  const shapes=[5,3,7];for(let rr=0;rr<rows;rr++)for(let cc=0;cc<cols;cc++){if(!grid[rr][cc])grid[rr][cc]=shapes[Math.random()*3|0];const k=1+Math.floor(Math.random()*3);for(let i=0;i<k;i++)grid[rr][cc]=rot(grid[rr][cc])}
  PUZ={grid,cols,rows,r0,r1,onDone,prev:state};state='puzzle';renderPuzzle();$('#puz').classList.remove('hidden');
  function solved(){const q=[[r0,0]];const vis=new Set();if(!(grid[r0][0]&W))return false;while(q.length){const[a,b]=q.shift();const k=a+','+b;if(vis.has(k))continue;vis.add(k);const t=grid[a][b];if(a===r1&&b===cols-1&&(t&E))return true;
      for(const[d,da,db]of[[N,-1,0],[E,0,1],[Sb,1,0],[W,0,-1]]){if(!(t&d))continue;const na=a+da,nb=b+db;if(na<0||nb<0||na>=rows||nb>=cols)continue;if(grid[na][nb]&opp(d))q.push([na,nb])}}return false}
  PUZ.tap=(rr,cc)=>{grid[rr][cc]=rot(grid[rr][cc]);tone(500,700,.05,'square',.05);renderPuzzle();if(solved()){setTimeout(()=>{closePuzzle();onDone()},350)}}}
function renderPuzzle(){const p=PUZ,el=$('#puzGrid');let h='';for(let r=0;r<p.rows;r++){h+=`<div class="pzr"><span class="pzm">${r===p.r0?'⚡▶':''}</span>`;for(let c=0;c<p.cols;c++){const b=p.grid[r][c];const L=(d,x2,y2)=>(b&d)?`<line x1="50" y1="50" x2="${x2}" y2="${y2}" stroke="#ffd500" stroke-width="16" stroke-linecap="round"/>`:'';
    h+=`<button class="pz" data-r="${r}" data-c="${c}"><svg viewBox="0 0 100 100"><rect x="2" y="2" width="96" height="96" rx="10" fill="#26301c" stroke="#56653a" stroke-width="3"/>${L(1,50,0)}${L(2,100,50)}${L(4,50,100)}${L(8,0,50)}<circle cx="50" cy="50" r="10" fill="#ffd500"/></svg></button>`}h+=`<span class="pzm">${r===p.r1?'▶📶':''}</span></div>`}
  el.innerHTML=h;$('#puzInfo').textContent='Торкайся плиток, щоб повертати їх. З’єднай жовтим кабелем вхід ⚡ ліворуч із виходом 📶 праворуч.'}
function closePuzzle(){$('#puz').classList.add('hidden');if(PUZ)state=PUZ.prev==='play'?'play':PUZ.prev;PUZ=null}

