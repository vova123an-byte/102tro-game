/* ================= SAVE ================= */
const LS='tro102_3d_v1';
let isTouch=false;try{isTouch=matchMedia('(pointer:coarse)').matches||('ontouchstart' in window)}catch(e){}
const lowEnd=isTouch;
function defaults(){return{callsign:'Бобер',quality:lowEnd?'medium':'high',sound:true,music:true,sens:1,xp:0,coins:0,carColor:0,colors:[0],story:{m:1,step:0},done:[],ach:{},stats:{km:0,jumps:0,horn:0,night:0,talk:0},chev:[],pos:null,car:null,tod:.3,hasGame:false,mode:'story'}}
let S=defaults();
try{const raw=localStorage.getItem(LS); if(raw){const o=JSON.parse(raw); S=Object.assign(defaults(),o); S.stats=Object.assign(defaults().stats,o.stats||{});}}catch(e){}
function persist(){try{localStorage.setItem(LS,JSON.stringify(S))}catch(e){}}
let prevCrash=false;try{prevCrash=localStorage.getItem('tro102_boot')==='1';localStorage.setItem('tro102_boot','1')}catch(e){}
if(prevCrash||window.__safeMode){S.quality='low'}
const Q={low:{dpr:1,shadow:0,tex:256,grass:1400,ground:1024,aa:false,normal:false,aniso:2,fog:.0062},
  medium:{dpr:1.5,shadow:1024,tex:512,grass:3500,ground:2048,aa:true,normal:true,aniso:4,fog:.0052},
  high:{dpr:2,shadow:2048,tex:1024,grass:7000,ground:2048,aa:true,normal:true,aniso:8,fog:.0048}};
if(!Q[S.quality])S.quality='medium';
const QL=Q[S.quality];

