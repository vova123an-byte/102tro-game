/* ===== ГУЛЯЙПОЛЕ: забудова ===== */
function paintTown(g,TP,K){const R=rngS(515),w=9,sw=2.2;
  const rectW=(x0,z0,x1,z1,c)=>{g.fillStyle=c;g.fillRect(TP(x0),TP(z0),(x1-x0)*K,(z1-z0)*K)};
  rectW(TOWN.x0,TOWN.z0,TOWN.x1,TOWN.z1,'#66704a');
  for(const a of TOWN.av)rectW(a-w/2-sw,TOWN.z0,a+w/2+sw,TOWN.z1,'#8e8b82');rectW(225-w/2-sw,12,225+w/2+sw,TOWN.z0,'#8e8b82');
  for(const z of TOWN.st)rectW(TOWN.x0,z-w/2-sw,TOWN.x1,z+w/2+sw,'#8e8b82');
  for(const a of TOWN.av)rectW(a-w/2,TOWN.z0,a+w/2,TOWN.z1,'#47484b');rectW(225-w/2,12,225+w/2,TOWN.z0,'#47484b');
  for(const z of TOWN.st)rectW(TOWN.x0,z-w/2,TOWN.x1,z+w/2,'#47484b');
  g.fillStyle='#cfcab0';for(const a of TOWN.av)for(let z=TOWN.z0;z<TOWN.z1;z+=6)g.fillRect(TP(a-.08),TP(z),.16*K,2.8*K);
  for(const z of TOWN.st)for(let x=TOWN.x0;x<TOWN.x1;x+=6)g.fillRect(TP(x),TP(z-.08),2.8*K,.16*K);
  g.fillStyle='#e6e1cc';for(const a of TOWN.av)for(const z of TOWN.st){for(let i=-4;i<=4;i+=1.2){g.fillRect(TP(a+i-.3),TP(z+5.2),.6*K,2.4*K);g.fillRect(TP(a+i-.3),TP(z-7.6),.6*K,2.4*K)}}
  rectW(229,134,261,186,'#9a9384');g.fillStyle='#8a8476';for(let i=0;i<900;i++)g.fillRect(TP(229+R()*32),TP(134+R()*52),3,2);
  for(let i=0;i<120;i++){const a=TOWN.av[R()*3|0],z=TOWN.z0+R()*(TOWN.z1-TOWN.z0);g.fillStyle='rgba(30,30,32,.55)';g.beginPath();g.ellipse(TP(a+(R()-.5)*7),TP(z),(.6+R()*1.2)*K,(.4+R()*.8)*K,R()*3,0,7);g.fill()}}
let FACADE=null;
function facadeMats(){if(FACADE)return FACADE;const W=512,Hh=360,c=cnv(W,Hh),e=cnv(W,Hh),x=c.getContext('2d'),xe=e.getContext('2d'),R=rngS(77);
  x.fillStyle='#b9b6ad';x.fillRect(0,0,W,Hh);xe.fillStyle='#000';xe.fillRect(0,0,W,Hh);
  for(let i=0;i<2600;i++){x.fillStyle=R()<.5?'rgba(90,85,78,.08)':'rgba(255,255,255,.06)';x.fillRect(R()*W,R()*Hh,2+R()*6,2+R()*6)}
  x.strokeStyle='rgba(70,68,62,.55)';x.lineWidth=2;for(let i=0;i<=4;i++){x.beginPath();x.moveTo(i*W/4,0);x.lineTo(i*W/4,Hh);x.stroke()}for(let j=0;j<=3;j++){x.beginPath();x.moveTo(0,j*Hh/3);x.lineTo(W,j*Hh/3);x.stroke()}
  const cw=W/4,ch=Hh/3;for(let j=0;j<3;j++)for(let i=0;i<4;i++){const wx=i*cw+cw*.22,wy=j*ch+ch*.22,ww=cw*.56,wh=ch*.56,old=R()<.4;
    x.fillStyle=old?'#6b5a44':'#e8e6df';x.fillRect(wx-4,wy-4,ww+8,wh+8);x.fillStyle='#1d2328';x.fillRect(wx,wy,ww,wh);
    const g=x.createLinearGradient(wx,wy,wx+ww,wy+wh);g.addColorStop(0,'rgba(170,190,205,.35)');g.addColorStop(.5,'rgba(60,70,80,.05)');g.addColorStop(1,'rgba(150,170,185,.25)');x.fillStyle=g;x.fillRect(wx,wy,ww,wh);
    const cur=R();if(cur<.6){x.fillStyle=['rgba(230,225,210,.75)','rgba(200,170,120,.7)','rgba(170,190,160,.6)','rgba(210,190,200,.6)'][R()*4|0];x.fillRect(wx+2,wy+2,ww*.32,wh-4);x.fillRect(wx+ww*.68-2,wy+2,ww*.32,wh-4)}
    x.fillStyle=old?'#6b5a44':'#e8e6df';x.fillRect(wx+ww/2-2,wy,4,wh);x.fillRect(wx,wy+wh*.3,ww/2,3);x.fillStyle='#8d8a82';x.fillRect(wx-6,wy+wh+4,ww+12,5);
    if(R()<.45){xe.fillStyle=['#ffcf8a','#ffe2b0','#f5b870'][R()*3|0];xe.fillRect(wx+2,wy+2,ww-4,wh-4)}}
  const t=mkTex(c),te=mkTex(e);t.repeat.set(1/12,1/8.4);te.repeat.set(1/12,1/8.4);
  FACADE={wall:std({map:t,emissiveMap:te,emissive:'#000000',roughness:.88}),dmg:std({map:t,color:'#6a6258',roughness:.95})};MATS.facade=FACADE.wall;MATS.facadeDmg=FACADE.dmg;
  MATS.bitumen=std({color:'#33302c',roughness:.95});MATS.balc=std({map:TX.concrete,color:'#bdb9b0',roughness:.9});MATS.soot=std({color:'#141210',roughness:1});
  ['#c9c4b8','#b8a88e','#8fa0a8','#a8b39a'].forEach((c,i)=>MATS['shop'+i]=std({map:TX.plaster,color:c,roughness:.9}));
  return FACADE}
function signMat(text,bg,fg){return std({map:textTex(512,112,(x,w,h)=>{x.fillStyle=bg;x.fillRect(0,0,w,h);x.fillStyle=fg;x.font='bold 58px Arial';x.textAlign='center';x.textBaseline='middle';x.fillText(text,w/2,h/2+3)}),emissive:'#000000',roughness:.5})}
function panelBlock(B,cx,cz,len,ry,floors,damaged){const W=12,fh=2.8,Hh=floors*fh+.6,o=MX(cx,0,cz,ry),add=(k,g,x,y,z,r2)=>B.add(k,g,new T.Matrix4().multiplyMatrices(o,MX(x,y,z,r2||0)));
  if(!damaged){add('facade',boxG(len,Hh,W),0,Hh/2,0)}
  else{const cut=len*.28;add('facade',boxG(len-cut,Hh,W),-cut/2,Hh/2,0);add('facade',boxG(cut,Hh*.45,W),len/2-cut/2,Hh*.225,0);
    for(let f=0;f<floors;f++){add('balc',boxG(cut,.22,W*.9),len/2-cut/2,(f+1)*fh*.45+.4,0)}add('soot',planeG(cut*.9,Hh*.5),len/2-cut-.01,Hh*.72,0,-Math.PI/2);
    const R=rngS(cx|0);for(let i=0;i<26;i++){const g=new T.IcosahedronGeometry(.4+R()*1.1,0);add(i%3?'concrete':'balc',g,len/2-cut*R(),.3+R()*1.2,(R()-.5)*W*1.1)}}
  add('bitumen',boxG(damaged?len*.72:len,.2,W),damaged?-len*.14:0,Hh+.1,0);
  for(const s of[-1,1])add('balc',boxG(damaged?len*.72:len,.5,.2),damaged?-len*.14:0,Hh+.35,s*W/2);
  const cols=Math.floor(len/6);for(let i=0;i<cols;i++){const x=-len/2+3+i*6;if(damaged&&x>len/2-len*.3)continue;for(let f=1;f<floors;f++){const gl=(i+f)%3===0;add('balc',boxG(2.6,.12,1.1),x,f*fh+.6,W/2+.55);add(gl?'glass':'balc',gl?planeG(2.6,1.1):boxG(2.6,1.0,.08),x,f*fh+1.15,W/2+1.08)}}
  for(const i of[-1,0,1]){const x=i*len/3;if(damaged&&x>len/2-len*.3)continue;add('concrete',boxG(2.6,.15,1.6),x,2.6,-W/2-.8);add('metalBrown',boxG(1.2,2.1,.08),x,1.05,-W/2-.04);add('concrete',boxG(2.2,.3,1.4),x,.15,-W/2-.7)}
  for(let i=0;i<3;i++)add('brickRed',boxG(.6,1.2,.6),-len/3+i*len/3,Hh+.6,1.5)}
function shopBld(B,cx,cz,w,d,ry,mat,sign,floors){const o=MX(cx,0,cz,ry),add=(k,g,x,y,z,r2)=>B.add(k,g,new T.Matrix4().multiplyMatrices(o,MX(x,y,z,r2||0))),Hh=floors*3.2;
  add(mat,boxG(w,Hh,d),0,Hh/2,0);add('bitumen',boxG(w+.3,.2,d+.3),0,Hh+.1,0);
  for(const x of[-w/4,w/4])add('glass',planeG(w/2-1.2,1.9),x,1.5,d/2+.02);add('metalBrown',boxG(1.1,2.2,.06),0,1.1,d/2+.03);
  if(floors>1)for(let i=0;i<Math.floor(w/3);i++)add('glass',planeG(1.3,1.4),-w/2+1.5+i*3,4.7,d/2+.02);
  if(sign){MATS['sg_'+sign.t]=MATS['sg_'+sign.t]||signMat(sign.t,sign.bg,sign.fg);add('sg_'+sign.t,planeG(Math.min(w-1,6),1.1),0,3.0,d/2+.05)}
  add('metalGreen',boxG(w,.05,1.2),0,2.55,d/2+.6,0)}
async function buildTown(){await tick('Гуляйполе: квартали…',84);const B=new Bld(),R=rngS(4242);facadeMats();
  const blocks=[];[[189,221],[229,261]].forEach(([x0,x1])=>[[74,126],[134,186],[194,246],[254,284]].forEach(([z0,z1])=>blocks.push({x0,x1,z0,z1})));
  const cols=[];
  blocks.forEach((b,i)=>{const cx=(b.x0+b.x1)/2,cz=(b.z0+b.z1)/2;
    if(b.x0===229&&b.z0===134){// площа
      B.add('concrete',boxG(2.2,.4,2.2),MX(cx,.2,cz));B.add('plinthGrey',boxG(1.2,6.5,1.2),MX(cx,3.6,cz));
      MATS['sg_ГУЛЯЙПОЛЕ']=MATS['sg_ГУЛЯЙПОЛЕ']||signMat('ГУЛЯЙПОЛЕ','#e9e4d6','#1d2a52');B.add('sg_ГУЛЯЙПОЛЕ',planeG(5.6,1.1),MX(cx,1.2,cz+1.15));
      for(const[dx,dz]of[[-9,-14],[9,-14],[-9,14],[9,14]]){B.add('woodBrown',boxG(1.8,.06,.4),MX(cx+dx,.46,cz+dz));B.add('dark',boxG(1.6,.44,.3),MX(cx+dx,.22,cz+dz))}
      for(const[dx,dz]of[[-13,-22],[13,-22],[-13,22],[13,22],[-13,0],[13,0]])TREEPL.acacia.push({x:cx+dx,z:cz+dz,s:.9+R()*.2,ry:R()*6});
      FLAGS2.push({x:cx+6,z:cz-6});cols.push({t:'c',x:cx,z:cz,r:1.4});return}
    if(b.x0===229&&b.z0===194){// магазини вздовж проспекту
      shopBld(B,238,cz-14,9,12,-Math.PI/2,'shop0',{t:'АПТЕКА',bg:'#1f7a4a',fg:'#fff'},1);shopBld(B,238,cz+1,9,12,-Math.PI/2,'shop1',{t:'КАФЕ «ЛАСУНКА»',bg:'#7a2f22',fg:'#ffe9b0'},2);
      shopBld(B,238,cz+16,9,12,-Math.PI/2,'shop2',{t:'ПОШТА',bg:'#e8c33a',fg:'#1d2a52'},1);
      cols.push({t:'b',x0:231.6,x1:244.4,z0:cz-19,z1:cz+21,h:7});
      for(let i=0;i<8;i++){const gz=b.z0+3+i*6.2;B.add(['metalGreen','metalBlue','metalBrown','galv'][i%4],boxG(5.8,2.6,6),MX(254,1.3,gz));B.add('galv',planeG(2.6,2.2),MX(250.6,1.1,gz,-Math.PI/2));B.add('bitumen',boxG(6.2,.1,6.3),MX(254,2.65,gz))}
      cols.push({t:'b',x0:250.8,x1:257.2,z0:b.z0,z1:b.z0+50,h:3});return}
    if(b.x0===189&&b.z0===254){shopBld(B,cx,262.5,20,12,Math.PI,'shop3',{t:'ПРОДУКТИ',bg:'#2e5c9a',fg:'#fff'},1);shopBld(B,cx,277.5,14,9,0,'shop1',{t:'БУДМАТЕРІАЛИ',bg:'#e07a1f',fg:'#fff'},1);
      cols.push({t:'b',x0:cx-10.5,x1:cx+10.5,z0:256,z1:282.5,h:7});return}
    const dmg=(b.x0===189&&b.z0===134);const floors=b.z0===74?4:5;
    panelBlock(B,cx,cz,b.z1-b.z0-10,Math.PI/2,floors,dmg);cols.push({t:'b',x0:cx-6.2,x1:cx+6.2,z0:b.z0+5,z1:b.z1-5,h:floors*2.8+1});
    for(const dz of[-12,0,12])if(R()<.75)TREEPL.acacia.push({x:cx+(R()<.5?-10:10),z:cz+dz,s:.8+R()*.3,ry:R()*6})});
  // ліхтарі й дерева вздовж проспекту
  for(let z=30;z<284;z+=24){for(const s of[-1,1]){const x=225+s*7;if(inTown(x,z)&&TOWN.st.some(q=>Math.abs(z-q)<8))continue;const y0=H(x,z);B.add('galv',cylG(.06,.09,6,8),MX(x,y0+3,z));B.add('lamp',boxG(.5,.14,.3),MX(x-s*.6,y0+5.9,z));B.add('galv',beamG(V(x,y0+5.9,z),V(x-s*.6,y0+5.9,z),.03));cols.push({t:'c',x,z,r:.15})}}
  B.flush(scene);cols.forEach(c=>addCol(c));
  // знак на в'їзді
  signPostQuick(229.5,24,-Math.PI/2,['ГУЛЯЙПОЛЕ'],{bg:'#fff',fg:'#111'});
  // припарковані та покинуті авто
  const spots=[[219.8,96,0],[219.8,160,Math.PI],[230.2,214,0],[190.2,232,Math.PI],[259.8,110,0],[199,70-3.2,Math.PI/2],[244,130+3.2,-Math.PI/2],[270.2,150,Math.PI]];
  spots.forEach(([x,z,r],i)=>{const sd=makeSedan();linearizeAll(sd);sd.position.set(x,0,z);sd.rotation.y=r;if(i===3)sd.traverse(o=>{if(o.isMesh&&o.material&&o.material.color)o.material=MATS.soot});scene.add(sd);addCol({t:'c',x:x+Math.sin(r)*1.1,z:z+Math.cos(r)*1.1,r:1});addCol({t:'c',x:x-Math.sin(r)*1.1,z:z-Math.cos(r)*1.1,r:1})});
  for(const f of FLAGS2){const y=H(f.x,f.z),pole=new T.Mesh(cylG(.07,.07,9,8),MATS.galv);pole.position.set(f.x,y+4.5,f.z);scene.add(pole);const fl=new T.Mesh(new T.PlaneGeometry(2.4,1.6),new T.MeshBasicMaterial({map:flagTex(),side:T.DoubleSide}));fl.position.set(f.x+1.25,y+8.1,f.z);scene.add(fl);f.mesh=fl}}
const FLAGS2=[];
function signPostQuick(x,z,ry,lines,o){const y=H(x,z);const p=new T.Mesh(cylG(.05,.05,2.6,6),MATS.galv);p.position.set(x,y+1.3,z);scene.add(p);signMesh(x,y+2.3,z,ry,lines,o,true)}

