/* ===== GLB CORE: власний розбір glTF 2.0 (.glb) без мережі й без fetch ===== */
function glbData(buf){
  const dv=new DataView(buf);if(buf.byteLength<20||dv.getUint32(0,true)!==0x46546C67)throw new Error('це не файл .glb');
  let off=12,json=null,bin=null;
  while(off+8<=buf.byteLength){const len=dv.getUint32(off,true),type=dv.getUint32(off+4,true),s=off+8;
    if(type===0x4E4F534A)json=JSON.parse(new TextDecoder('utf-8').decode(new Uint8Array(buf,s,len)));else if(type===0x004E4942)bin=new Uint8Array(buf,s,len);off=s+len}
  if(!json)throw new Error('у GLB немає опису сцени');
  if(json.extensionsRequired&&json.extensionsRequired.length)throw new Error('модель потребує розширень '+json.extensionsRequired.join(', ')+' (стиснення Draco/KTX2 не підтримується)');
  const g=json,bvs=g.bufferViews||[],bdv=bin?new DataView(bin.buffer,bin.byteOffset,bin.byteLength):null;
  const NC={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},CT={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array};
  const RD={5120:o=>bdv.getInt8(o),5121:o=>bdv.getUint8(o),5122:o=>bdv.getInt16(o,true),5123:o=>bdv.getUint16(o,true),5125:o=>bdv.getUint32(o,true),5126:o=>bdv.getFloat32(o,true)};
  const NM={5120:127,5121:255,5122:32767,5123:65535};
  function acc(i,forceFloat){const a=g.accessors[i],n=NC[a.type],C=CT[a.componentType];if(!n||!C)throw new Error('невідомий формат даних у моделі');
    const asF=forceFloat||a.normalized,out=new (asF&&a.componentType!==5126?Float32Array:C)(a.count*n);if(a.bufferView==null||!bdv)return{arr:out,n};
    const bv=bvs[a.bufferView],es=C.BYTES_PER_ELEMENT,st=bv.byteStride||es*n,base=(bv.byteOffset||0)+(a.byteOffset||0),rd=RD[a.componentType],dv0=a.normalized?NM[a.componentType]:0;
    for(let k=0;k<a.count;k++){const o=base+k*st;for(let j=0;j<n;j++){let v=rd(o+j*es);if(dv0)v=Math.max(v/dv0,-1);out[k*n+j]=v}}return{arr:out,n}}
  // 4x4 column-major helpers
  const I=()=>[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
  const mul=(a,b)=>{const r=new Array(16);for(let c=0;c<4;c++)for(let rI=0;rI<4;rI++){let s=0;for(let k=0;k<4;k++)s+=a[k*4+rI]*b[c*4+k];r[c*4+rI]=s}return r};
  const trs=(t,q,s)=>{t=t||[0,0,0];q=q||[0,0,0,1];s=s||[1,1,1];const[x,y,z,w]=q,x2=x+x,y2=y+y,z2=z+z,xx=x*x2,xy=x*y2,xz=x*z2,yy=y*y2,yz=y*z2,zz=z*z2,wx=w*x2,wy=w*y2,wz=w*z2;
    return[(1-(yy+zz))*s[0],(xy+wz)*s[0],(xz-wy)*s[0],0,(xy-wz)*s[1],(1-(xx+zz))*s[1],(yz+wx)*s[1],0,(xz+wy)*s[2],(yz-wx)*s[2],(1-(xx+yy))*s[2],0,t[0],t[1],t[2],1]};
  const local=n=>n.matrix?n.matrix.slice():trs(n.translation,n.rotation,n.scale);
  const prims=[];const mn=[1e9,1e9,1e9],mx=[-1e9,-1e9,-1e9];
  function visit(ni,parent){const nd=g.nodes[ni],W=mul(parent,local(nd));
    if(nd.mesh!=null){const me=g.meshes[nd.mesh];
      // normal matrix = inverse-transpose of upper 3x3
      const a=W[0],b=W[4],c=W[8],d=W[1],e=W[5],f=W[9],gg=W[2],h=W[6],k=W[10];const det=a*(e*k-f*h)-b*(d*k-f*gg)+c*(d*h-e*gg),id=det?1/det:0;
      const N=[(e*k-f*h)*id,-(b*k-c*h)*id,(b*f-c*e)*id,-(d*k-f*gg)*id,(a*k-c*gg)*id,-(a*f-c*d)*id,(d*h-e*gg)*id,-(a*h-b*gg)*id,(a*e-b*d)*id];// inverse rows
      for(const p of me.primitives){if(p.mode!=null&&p.mode!==4)continue;const at=p.attributes;if(at.POSITION==null)continue;
        const P=acc(at.POSITION,true).arr,cnt=P.length/3,pos=new Float32Array(P.length);
        for(let v=0;v<cnt;v++){const x=P[v*3],y=P[v*3+1],z=P[v*3+2];const X=W[0]*x+W[4]*y+W[8]*z+W[12],Y=W[1]*x+W[5]*y+W[9]*z+W[13],Z=W[2]*x+W[6]*y+W[10]*z+W[14];pos[v*3]=X;pos[v*3+1]=Y;pos[v*3+2]=Z;
          if(X<mn[0])mn[0]=X;if(Y<mn[1])mn[1]=Y;if(Z<mn[2])mn[2]=Z;if(X>mx[0])mx[0]=X;if(Y>mx[1])mx[1]=Y;if(Z>mx[2])mx[2]=Z}
        let nor=null;if(at.NORMAL!=null){const Nn=acc(at.NORMAL,true).arr;nor=new Float32Array(Nn.length);
          for(let v=0;v<cnt;v++){const x=Nn[v*3],y=Nn[v*3+1],z=Nn[v*3+2];// transpose(inverse) * n  => use columns of inverse rows
            let X=N[0]*x+N[3]*y+N[6]*z,Y=N[1]*x+N[4]*y+N[7]*z,Z=N[2]*x+N[5]*y+N[8]*z;const l=Math.hypot(X,Y,Z)||1;nor[v*3]=X/l;nor[v*3+1]=Y/l;nor[v*3+2]=Z/l}}
        const uv=at.TEXCOORD_0!=null?acc(at.TEXCOORD_0,true).arr:null,uv2=at.TEXCOORD_1!=null?acc(at.TEXCOORD_1,true).arr:null;
        let col=null,colN=0;if(at.COLOR_0!=null){const c0=acc(at.COLOR_0,true);col=c0.arr;colN=c0.n}
        let idx;if(p.indices!=null){const ia=acc(p.indices).arr;idx=cnt>65535?Uint32Array.from(ia):(ia instanceof Uint32Array&&cnt<=65535?Uint16Array.from(ia):ia)}else{idx=new (cnt>65535?Uint32Array:Uint16Array)(cnt);for(let v=0;v<cnt;v++)idx[v]=v}
        if(det<0)for(let t=0;t+2<idx.length;t+=3){const s=idx[t+1];idx[t+1]=idx[t+2];idx[t+2]=s}
        prims.push({name:(nd.name||me.name||'mesh'),pos,nor,uv,uv2,col,colN,idx,mat:p.material})}}
    (nd.children||[]).forEach(ci=>visit(ci,W))}
  const sc=(g.scenes||[])[g.scene||0];const roots=sc?sc.nodes:(g.nodes||[]).map((_,i)=>i);roots.forEach(r=>visit(r,I()));
  let tris=0;prims.forEach(p=>tris+=p.idx.length/3);
  return{json:g,bin,bvs,prims,bounds:{min:mn,max:mx},tris,animated:!!((g.animations&&g.animations.length)||(g.skins&&g.skins.length))}}
function glbImages(d,maxSize,onProg){const ims=d.json.images||[];let done=0;
  return Promise.all(ims.map(im=>new Promise(res=>{const fin=v=>{done++;if(onProg)onProg(done,ims.length);res(v)};
    try{if(im.bufferView==null){fin(null);return}const bv=d.bvs[im.bufferView],bytes=new Uint8Array(d.bin.buffer,d.bin.byteOffset+(bv.byteOffset||0),bv.byteLength),blob=new Blob([bytes],{type:im.mimeType||'image/jpeg'});
      const shrink=img=>{if(!maxSize||Math.max(img.width,img.height)<=maxSize)return img;const r=maxSize/Math.max(img.width,img.height),c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.width*r));c.height=Math.max(1,Math.round(img.height*r));c.getContext('2d').drawImage(img,0,0,c.width,c.height);return c};
      const viaData=()=>{const fr=new FileReader();fr.onload=()=>{const img=new Image();img.onload=()=>fin(shrink(img));img.onerror=()=>fin(null);img.src=fr.result};fr.onerror=()=>fin(null);fr.readAsDataURL(blob)};
      let url=null;try{url=URL.createObjectURL(blob)}catch(e){}
      if(!url){viaData();return}const img=new Image();img.onload=()=>{fin(shrink(img));setTimeout(()=>URL.revokeObjectURL(url),2000)};img.onerror=()=>{URL.revokeObjectURL(url);viaData()};img.src=url}
    catch(e){fin(null)}})))}
function glbBuild(d,imgs){const g=d.json,texC={},W={33071:T.ClampToEdgeWrapping,33648:T.MirroredRepeatWrapping,10497:T.RepeatWrapping};let texN=0;
  const tex=(info,srgb)=>{if(!info||info.index==null)return null;const k=info.index+(srgb?'s':'l');if(texC[k])return texC[k];const t=(g.textures||[])[info.index];if(!t||t.source==null||!imgs[t.source])return null;
    const tx=new T.Texture(imgs[t.source]);tx.flipY=false;if(srgb)tx.encoding=T.sRGBEncoding;const sm=(g.samplers||[])[t.sampler]||{};tx.wrapS=W[sm.wrapS]||T.RepeatWrapping;tx.wrapT=W[sm.wrapT]||T.RepeatWrapping;
    tx.anisotropy=Math.min(QL.aniso,renderer.capabilities.getMaxAnisotropy()||1);tx.needsUpdate=true;texC[k]=tx;texN++;return tx};
  const mats=(g.materials||[]).map(m=>{const p=m.pbrMetallicRoughness||{},bc=p.baseColorFactor||[1,1,1,1];
    const mm=new T.MeshStandardMaterial({roughness:p.roughnessFactor!=null?p.roughnessFactor:1,metalness:p.metallicFactor!=null?p.metallicFactor:1});
    mm.color.setRGB(bc[0],bc[1],bc[2]);if(bc[3]<1){mm.opacity=bc[3];mm.transparent=true}
    const map=tex(p.baseColorTexture,true);if(map)mm.map=map;
    const mr=tex(p.metallicRoughnessTexture,false);if(mr){mm.roughnessMap=mr;mm.metalnessMap=mr}
    const nm=tex(m.normalTexture,false);if(nm){mm.normalMap=nm;const s=(m.normalTexture.scale!=null?m.normalTexture.scale:1);mm.normalScale.set(s,-s)}
    const ao=tex(m.occlusionTexture,false);if(ao){mm.aoMap=ao;mm.aoMapIntensity=m.occlusionTexture.strength!=null?m.occlusionTexture.strength:1}
    const em=tex(m.emissiveTexture,true);if(em)mm.emissiveMap=em;if(m.emissiveFactor)mm.emissive.setRGB(m.emissiveFactor[0],m.emissiveFactor[1],m.emissiveFactor[2]);
    if(m.alphaMode==='BLEND'){mm.transparent=true;mm.depthWrite=false}else if(m.alphaMode==='MASK')mm.alphaTest=m.alphaCutoff!=null?m.alphaCutoff:.5;
    mm.side=m.doubleSided?T.DoubleSide:T.FrontSide;mm.name=m.name||'';mm.userData.lin=true;mm.userData.env=1;STD.push(mm);return mm});
  const root=new T.Group();root.name='glb';
  for(const p of d.prims){const geo=new T.BufferGeometry();geo.setAttribute('position',new T.BufferAttribute(p.pos,3));if(p.nor)geo.setAttribute('normal',new T.BufferAttribute(p.nor,3));
    if(p.uv){geo.setAttribute('uv',new T.BufferAttribute(p.uv,2));geo.setAttribute('uv2',new T.BufferAttribute(p.uv2||p.uv,2))}
    if(p.col)geo.setAttribute('color',new T.BufferAttribute(p.col,p.colN));geo.setIndex(new T.BufferAttribute(p.idx,1));if(!p.nor)geo.computeVertexNormals();geo.computeBoundingSphere();geo.computeBoundingBox();
    let mat=p.mat!=null?mats[p.mat]:null;if(!mat){mat=new T.MeshStandardMaterial({color:0xcccccc,roughness:.8,metalness:0});mat.userData.lin=true}
    if(p.col)mat.vertexColors=true;const me=new T.Mesh(geo,mat);me.name=p.name;me.castShadow=true;me.receiveShadow=true;root.add(me)}
  return{scene:root,animations:[],tris:d.tris,texN,imgOk:imgs.filter(Boolean).length,imgTotal:imgs.length,matN:mats.length}}

