/* ===== ГУЛЯЙПОЛЕ: планування (вигадане місто на південному сході карти) ===== */
const TOWN={x0:163,x1:287,z0:44,z1:287,av:[185,225,265],st:[70,130,190,250]};
const inTown=(x,z)=>x>TOWN.x0-4&&x<TOWN.x1+4&&z>TOWN.z0-4&&z<TOWN.z1+4;
function townRoad(x,z){if(Math.abs(x-225)<4.6&&z>12&&z<TOWN.z1)return true;if(!inTown(x,z))return false;
  for(const a of TOWN.av)if(Math.abs(x-a)<4.6)return true;for(const s of TOWN.st)if(Math.abs(z-s)<4.6)return true;return false}
// приватні будинки в крайніх кварталах (беруть участь у заміні справжньою GLB-моделлю)
(function(){const R=rngS(909);for(const z of[84,100,116,144,160,176,204,220,236,264,280]){
  houses.push({x:173.5,z,rot:Math.PI/2,w:7,d:5,roof:ROOFC[R()*6|0],wall:WALLC[R()*5|0],dmg:R()<.18,town:true});
  if(!(z>195&&z<245))houses.push({x:276.5,z,rot:-Math.PI/2,w:7,d:5,roof:ROOFC[R()*6|0],wall:WALLC[R()*5|0],dmg:R()<.18,town:true})}})();

{const inS=(x,z)=>x>-121&&x<-31&&Math.abs(z-roadMain(x))<46;
  for(let i=houses.length-1;i>=0;i--)if(inS(houses[i].x,houses[i].z))houses.splice(i,1);
  for(let i=yards.length-1;i>=0;i--){const y=yards[i];if(inS((y.x0+y.x1)/2,(y.z0+y.z1)/2))yards.splice(i,1)}}
const WELL={x:28,z:34}, FLAG={x:20,z:37}, START={x:-220,z:roadMain(-220)+6.5};
const puddles=[];
for(let i=0;i<34;i++){let x,z; const r=rnd();if(false)continue;
  if(r<.45){x=-260+rnd()*520;z=roadMain(x)+(rnd()-.5)*4}
  else if(r<.75){z=-230+rnd()*400;x=roadVil(z)+(rnd()-.5)*3.5}
  else {x=(rnd()<.5?GAP1:GAP2)+(rnd()-.5)*5;z=POS0+rnd()*(POS1-POS0)}
  if(Math.abs(x-START.x)<20&&Math.abs(z-START.z)<12)continue;if(x>-123&&x<-29&&Math.abs(z-roadMain(x))<10)continue;
  puddles.push({x,z,rx:1+rnd()*1.8,rz:.8+rnd()*1.4});}
const CHEV=[[-40,-114],[118,-60],[-95,70],[roadVil(132)+30,140],[200,-118],[WELL.x+3,WELL.z+2],[-200,-150],[-250,60],[-160,200],[-60,250],[40,230],[130,180],[150,roadMain(150)+12],[100,-200],[-130,-220],[-20,-260],[260,-200],[280,-110],[170,-20],[245,166],[215,142],[284,92],[188,262],[254,190],[-170,roadMain(-170)-36],[roadVil(-250)+20,-250],[-110,-140],[0,-160],[-275,-275],[275,275]].map(([x,z])=>({x,z}));

