/* ================= WORLD LAYOUT ================= */
const SIZE=600,HALF=300,SEG=150,STEP=SIZE/SEG;
const roadMain=x=>20+6*Math.sin(x/60);
const roadVil=z=>10+5*Math.sin(z/50);
const FR=[60,roadMain(60),260,-260];
const POS0=-128,POS1=-102; // посадка (лісосмуга)
const GAP1=roadVil(-115), GAP2=FR[0]+(FR[2]-FR[0])*((-115-FR[1])/(FR[3]-FR[1]));
function rawH(x,z){return 3.4*Math.sin(x*.011+.5)*Math.cos(z*.009)+1.7*Math.sin(x*.027+1.3)*Math.sin(z*.023+.4)+.5*Math.sin(x*.08)*Math.cos(z*.07)+4*Math.sin(x*.005+2)*Math.sin(z*.006+1)}
function flatF(x,z){
  const dm=Math.abs(z-roadMain(x)),dv=Math.abs(x-roadVil(z));
  const inX=1-sm(140,170,Math.abs(x-5)); let f=1-inX*(1-sm(44,64,dm));
  const inZ=1-sm(118,140,Math.abs(z-22)); f=Math.min(f,1-inZ*(1-sm(44,64,dv)));
  {const dx=Math.max(160-x,0,x-292),dz=Math.max(40-z,0,z-292),d=Math.hypot(dx,dz);f=Math.min(f,sm(0,22,d))}
  return f;
}
const HG=new Float32Array((SEG+1)*(SEG+1));
for(let j=0;j<=SEG;j++)for(let i=0;i<=SEG;i++){const x=-HALF+i*STEP,z=-HALF+j*STEP;HG[j*(SEG+1)+i]=rawH(x,z)*flatF(x,z)}
function H(x,z){const fx=clamp((x+HALF)/STEP,0,SEG-.001),fz=clamp((z+HALF)/STEP,0,SEG-.001);const i=fx|0,j=fz|0,tx=fx-i,tz=fz-j,n=SEG+1;
  const a=HG[j*n+i],b=HG[j*n+i+1],c=HG[(j+1)*n+i],d=HG[(j+1)*n+i+1];
  // match triangle split of PlaneGeometry (a-c-b, c-d-b)
  if(tx+tz<1) return a+(b-a)*tx+(c-a)*tz; return d+(c-d)*(1-tx)+(b-d)*(1-tz);}
function onRoad(x,z){if(typeof TOWN!=='undefined'&&townRoad(x,z))return true;return Math.abs(z-roadMain(x))<4||Math.abs(x-roadVil(z))<3.5||segDist(x,z,FR[0],FR[1],FR[2],FR[3])<3.2}
function inPos(x,z){return z>POS0&&z<POS1}
function surf(x,z){if(onRoad(x,z))return 1;if(inPos(x,z))return .45;if(Math.abs(x-5)<150&&Math.abs(z-roadMain(x))<40)return .85;return .7}

// --- village layout
const houses=[],yards=[];
const ROOFC=['#7d8c96','#9a4a32','#b89a55','#5e7a99','#8a6a3e','#6f7f8f'];
const WALLC=['#eee8da','#eee8da','#d6e3ea','#efe2b0','#e8ddd0'];
for(let x=-130;x<=136;x+=22){ if(Math.abs(x-12)<28)continue;
  for(const sd of[-1,1]){ if(rnd()<.1)continue; const rz=roadMain(x);
    houses.push({x,z:rz+sd*15,rot:sd<0?0:Math.PI,w:7,d:5,roof:ROOFC[rnd()*6|0],wall:WALLC[rnd()*5|0],dmg:rnd()<.14});
    yards.push({x0:x-9.5,x1:x+9.5,z0:Math.min(rz+sd*9,rz+sd*36),z1:Math.max(rz+sd*9,rz+sd*36),front:sd<0?'z1':'z0',sd,axis:'z',cx:x,road:rz});
  }}
for(const z of[-90,-68,-46,66,88,110,132]){ for(const sd of[-1,1]){ if(rnd()<.1)continue; const rx=roadVil(z);
  houses.push({x:rx+sd*15,z,rot:sd>0?-Math.PI/2:Math.PI/2,w:7,d:5,roof:ROOFC[rnd()*6|0],wall:WALLC[rnd()*5|0],dmg:rnd()<.14});
  yards.push({x0:Math.min(rx+sd*9,rx+sd*36),x1:Math.max(rx+sd*9,rx+sd*36),z0:z-9.5,z1:z+9.5,sd,axis:'x',cz:z,road:rx});
}}
