/* ================= BUILD WORLD ================= */
let groundTex;
async function buildWorld(){
  await initRealism();
  await tick('Малюємо поля й дороги…',15);
  paintGround();
  await tick('Формуємо пагорби…',35);
  groundTex=new T.CanvasTexture(gcv);groundTex.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());
  const gg=new T.PlaneGeometry(SIZE,SIZE,SEG,SEG);gg.rotateX(-Math.PI/2);
  const pos=gg.attributes.position;for(let i=0;i<pos.count;i++){const x=pos.getX(i),z=pos.getZ(i);const ii=Math.round((x+HALF)/STEP),jj=Math.round((z+HALF)/STEP);pos.setY(i,HG[jj*(SEG+1)+ii])}
  gg.computeVertexNormals();
  const ground=new T.Mesh(gg,groundMat(groundTex));ground.receiveShadow=true;scene.add(ground);
  // outer land
  const outer=new T.Mesh(new T.RingGeometry(298,900,32,1).rotateX(-Math.PI/2),new T.MeshLambertMaterial({color:0x56702f}));outer.position.y=-.3;scene.add(outer);
  await tick('Садимо посадку…',45);
  const R=rngS(55);
  // ---- posadka trees
  const treeCols=['#2f4a1f','#3b5a26','#4a6a2c','#7a7a2a','#9a7a2a','#8a5a22','#556b2f'];
  for(let x=-296;x<296;x+=2.4){ if(Math.abs(x-GAP1)<6||Math.abs(x-GAP2)<6)continue;
    for(let z=POS0+2;z<POS1-1;z+=3.1){ if(R()<.14)continue; const tx=x+(R()-.5)*1.6,tz=z+(R()-.5)*1.6,y=H(tx,tz),h=5+R()*6,cr=1.6+R()*1.6;
      const kind=R(); if(kind<.12){ // poplar-like
        put('trunk',GEO.trunk,MAT.flat,tx,y,tz,1,h*.5,1,0,'#4d3b2a');put('pop',GEO.cone,MAT.crown,tx,y+h*.35,tz,cr*1.3,h*1.15,cr*1.3,0,treeCols[R()*3|0]);}
      else{put('trunk',GEO.trunk,MAT.flat,tx,y,tz,1+R()*.4,h*.7,1+R()*.4,0,'#4d3b2a');
        put('crown',GEO.ico,MAT.crown,tx,y+h*.72,tz,cr*1.1,cr,cr*1.1,R()*3,treeCols[R()*treeCols.length|0]);
        if(R()<.7)put('crown',GEO.ico,MAT.crown,tx+(R()-.5)*1.2,y+h*.95,tz+(R()-.5)*1.2,cr*.75,cr*.7,cr*.75,R()*3,treeCols[R()*treeCols.length|0]);}
      addCol({t:'c',x:tx,z:tz,r:.32});
    }}
  // bushes + tall grass
  for(let i=0;i<1100;i++){const x=-296+R()*592,z=POS0-5+R()*(POS1-POS0+10);if(Math.abs(x-GAP1)<4.5||Math.abs(x-GAP2)<4.5)continue;const s=.7+R()*1.1;
    put('bush',GEO.ico,MAT.crown,x,H(x,z)+s*.4,z,s*1.3,s*.8,s*1.3,R()*3,['#3b5a26','#556b2f','#6b6a2a','#7a5a2a'][R()*4|0]);}
  for(let i=0;i<3200;i++){let x,z;if(i<2200){x=-296+R()*592;z=POS0-9+R()*(POS1-POS0+18)}else{x=-290+R()*580;z=-290+R()*580;if(onRoad(x,z)||(Math.abs(x-5)<150&&Math.abs(z-22)<60))continue}
    if(onRoad(x,z))continue;const s=.5+R()*.9;put('grass',GEO.cone4,MAT.grass,x,H(x,z)-.05,z,s*.5,s*1.2,s*.5,R()*3,['#8a8a4a','#9a8a4a','#6f7f3a','#a8955a'][R()*4|0],0,0,{noCast:1});}
  // roadside poplars (тополі)
  for(let x=-280;x<=280;x+=13){if(Math.abs(x-5)<150)continue;for(const sd of[-1,1]){if(R()<.35)continue;if(sd>0&&x>150)continue;const z=roadMain(x)+sd*(8+R()*2),y=H(x,z),h=11+R()*6;
    put('trunk',GEO.trunk,MAT.flat,x,y,z,1.2,h*.4,1.2,0,'#4d3b2a');put('pop',GEO.cone,MAT.crown,x,y+h*.25,z,2.4,h,2.4,0,R()<.5?'#56662a':'#7a7a2a');addCol({t:'c',x,z,r:.35})}}
  await tick('Будуємо хати…',60);
  // ---- houses
  for(const h of houses){const y=H(h.x,h.z),r=h.rot;PUTREC=h.inst=[];
    put('base',GEO.boxB,MAT.lam,h.x,y-.4,h.z,h.w+.3,.9,h.d+.3,r,R()<.5?'#3d5a8a':'#6b5a48');
    put('wall',GEO.boxB,MAT.lam,h.x,y+.5,h.z,h.w,2.6,h.d,r,h.wall);
    if(!h.dmg)put('roof',GEO.prism,MAT.flat,h.x,y+3.1,h.z,h.w+1,2.3,h.d+1.3,r,h.roof);
    else{put('roof',GEO.prism,MAT.flat,...(()=>{const p=L(h.x,h.z,r,-1.6,0);return[p[0],y+3.1,p[1]]})(),h.w*.55,2.2,h.d+1.3,r,'#4a403a');
      put('beam',GEO.box,MAT.flat,...(()=>{const p=L(h.x,h.z,r,1.8,0);return[p[0],y+3.4,p[1]]})(),3.2,.18,.18,r+.3,'#3a2a1a',.0,.35);
      for(let k=0;k<7;k++){const p=L(h.x,h.z,r,(R()-.5)*9,h.d/2+1+R()*2.5);put('rub',GEO.ico,MAT.flat,p[0],y+.1,p[1],.3+R()*.5,.25+R()*.3,.3+R()*.5,R()*3,R()<.5?'#8a7f70':'#a29a8a')}}
    const ch=L(h.x,h.z,r,1.9,-.9);put('chim',GEO.boxB,MAT.lam,ch[0],y+3.2,ch[1],.55,1.8,.55,r,'#9a7464');
    for(const wx of[-2.2,2.2]){const p=L(h.x,h.z,r,wx,h.d/2+.02);put('frame',GEO.boxB,MAT.lam,p[0],y+1.15,p[1],1.35,1.3,.08,r,'#3d6fb0');const q=L(h.x,h.z,r,wx,h.d/2+.06);put('win',GEO.boxB,MAT.win,q[0],y+1.3,q[1],1,1,.06,r)}
    for(const sx of[-1,1]){const q=L(h.x,h.z,r,sx*(h.w/2+.04),0);put('win',GEO.boxB,MAT.win,q[0],y+1.3,q[1],.06,1,.9,r)}
    const dp=L(h.x,h.z,r,0,h.d/2+.04);put('door',GEO.boxB,MAT.lam,dp[0],y+.5,dp[1],1,2,.08,r,'#6b4a2e');
    PUTREC=null;h.col=boxCol(h.x,h.z,h.w/2+.15,h.d/2+.15,r);h.col.h=5.6;}
  await tick('Паркани, городи, криниці…',70);
  // ---- yards: fences, sheds, gardens, orchard, wells
  for(const y of yards){
    const segs=[];const gate=y.axis==='z'?{z:y.sd<0?y.z1:y.z0,c:y.cx}:{x:y.sd<0?y.x1:y.x0,c:y.cz};
    const edge=(ax,az,bx,bz,isFront)=>{const len=Math.hypot(bx-ax,bz-az),n=Math.ceil(len/2.4);for(let i=0;i<=n;i++){const t=i/n,x=ax+(bx-ax)*t,z=az+(bz-az)*t;
        if(isFront&&Math.abs((y.axis==='z'?x:z)-gate.c)<1.4)continue;put('post',GEO.boxB,MAT.flat,x,H(x,z),z,.13,1.15,.13,0,'#5d4630')}
      const ry=Math.atan2(bx-ax,bz-az);
      if(isFront){const mid=y.axis==='z'?gate.c:gate.c;// split rails around gate
        const parts=y.axis==='z'?[[ax,mid-1.4],[mid+1.4,bx]]:[[az,mid-1.4],[mid+1.4,bz]];
        for(const[p0,p1]of parts){const l=Math.abs(p1-p0);if(l<.5)continue;const cx=y.axis==='z'?(p0+p1)/2:ax,cz=y.axis==='z'?az:(p0+p1)/2;for(const hh of[.45,.9])put('rail',GEO.box,MAT.flat,cx,H(cx,cz)+hh,cz,.06,.07,l,ry,'#7a5a3a')}}
      else{const cx=(ax+bx)/2,cz=(az+bz)/2;for(const hh of[.45,.9])put('rail',GEO.box,MAT.flat,cx,H(cx,cz)+hh,cz,.06,.07,len,ry,'#7a5a3a')}};
    edge(y.x0,y.z0,y.x1,y.z0,(y.axis==='z'&&y.sd>0)); edge(y.x0,y.z1,y.x1,y.z1,(y.axis==='z'&&y.sd<0));
    edge(y.x0,y.z0,y.x0,y.z1,(y.axis==='x'&&y.sd>0)); edge(y.x1,y.z0,y.x1,y.z1,(y.axis==='x'&&y.sd<0));
    // cabbages in garden
    const [gx0,gz0,gx1,gz1]=y.garden;for(let a=gx0+.8;a<gx1;a+=1.4)for(let b=gz0+.8;b<gz1;b+=1.6){if(R()<.35)continue;put('cab',GEO.ico,MAT.flat,a,H(a,b)+.15,b,.32,.28,.32,R()*3,R()<.5?'#7aa35a':'#5f8a45',0,0,{noCast:1})}
    // shed + orchard
    let sx,sz,ox,oz; if(y.axis==='z'){sx=y.x1-2.6;sz=(y.z0+y.z1)/2+y.sd*1.5;ox=y.x0+3;oz=sz}else{sz=y.z1-2.6;sx=(y.x0+y.x1)/2+y.sd*1.5;oz=y.z0+3;ox=sx}
    if(R()<.75){const sh=H(sx,sz);put('shed',GEO.boxB,MAT.lam,sx,sh,sz,3,2.2,2.6,0,'#7b5a3c');put('shedr',GEO.boxB,MAT.flat,sx,sh+2.2,sz,3.5,.12,3.1,0,'#7f8a90',.12);addCol({t:'b',x0:sx-1.6,x1:sx+1.6,z0:sz-1.4,z1:sz+1.4})}
    for(let k=0;k<2;k++){const tx=ox+(R()-.5)*2,tz=oz+(k?3.2:-3.2)*(y.axis==='z'?0:1)+(y.axis==='z'?(k?2:-2)*y.sd:0),ty=H(tx,tz);put('trunk',GEO.trunk,MAT.flat,tx,ty,tz,1.1,2.2,1.1,0,'#5a4430');
      put('crown',GEO.ico,MAT.crown,tx,ty+2.9,tz,1.7,1.4,1.7,R()*3,['#6a7a2a','#9a8a2a','#b07a2a','#4f6a2a'][R()*4|0]);addCol({t:'c',x:tx,z:tz,r:.28})}
    if(R()<.3){let wx,wz;if(y.axis==='z'){wx=y.x0+2.5;wz=y.sd<0?y.z1-3:y.z0+3}else{wz=y.z0+2.5;wx=y.sd<0?y.x1-3:y.x0+3}well(wx,wz,.85)}
  }
  well(WELL.x,WELL.z,1.1);
  // сільрада
  {const x=30,z=5,y=H(x,z);put('wall',GEO.boxB,MAT.lam,x,y,z,13,3.6,8,0,'#e1d7bf');put('roof',GEO.prism,MAT.flat,x,y+3.6,z,14,2,9.2,0,'#6f7f8f');put('base',GEO.boxB,MAT.lam,x,y-.4,z,13.4,.6,8.4,0,'#6b5a48');
    for(const wx of[-4.5,-1.5,3,5.2]){put('win',GEO.boxB,MAT.win,x+wx,y+1.5,z+4.03,1.2,1.2,.06,0)}put('door',GEO.boxB,MAT.lam,x+.8,y+.3,z+4.04,1.4,2.3,.08,0,'#5a3a22');addCol({t:'b',x0:x-6.7,x1:x+6.7,z0:z-4.2,z1:z+4.2});
    signMesh(x+.8,y+3,z+4.1,0,['СІЛЬСЬКА РАДА'],{w:4.2,h:.7,bg:'#2f5fb0',fg:'#fff'},false);}
  // bus stop
  {const x=-8,z=roadMain(-8)+6.5,y=H(x,z);put('stopw',GEO.boxB,MAT.lam,x,y,z+1.1,4.6,2.4,.2,0,'#5e7fa8');put('stopw',GEO.boxB,MAT.lam,x-2.3,y,z,.2,2.4,2.4,0,'#5e7fa8');put('stopw',GEO.boxB,MAT.lam,x+2.3,y,z,.2,2.4,2.4,0,'#5e7fa8');
    put('stopr',GEO.boxB,MAT.flat,x,y+2.4,z,5.2,.15,2.8,0,'#c9c3b0');put('bench',GEO.boxB,MAT.flat,x,y+.45,z+.6,3.8,.12,.5,0,'#7a5a3a');addCol({t:'b',x0:x-2.5,x1:x+2.5,z0:z-1.2,z1:z+1.3});
    signMesh(x+3.4,y+2.4,z-1,0,['🚌 МАЛИНІВКА'],{w:1.6,h:.55,bg:'#fff',fg:'#1b3a7a'},true);}
  // benches near well
  for(const b of[[22,30,0],[34,40,1.2]]){put('bench',GEO.boxB,MAT.flat,b[0],H(b[0],b[1])+.45,b[1],2,.12,.5,b[2],'#7a5a3a');put('post',GEO.boxB,MAT.flat,b[0],H(b[0],b[1]),b[1],.15,.45,.4,b[2],'#5d4630')}
  // tractor, hay, wreck car
  tractor(95,-62,.6);tractor(-150,-40,2.2);
  for(const[hx,hz]of[[-95,72],[-102,66],[-88,80],[150,-70],[156,-64]]){const y=H(hx,hz);put('hay',GEO.cylB,MAT.flat,hx,y,hz,2.6,1.8,2.6,0,'#c9a85a');put('hay',GEO.ico1,MAT.flat,hx,y+1.8,hz,1.3,.8,1.3,0,'#d2b25f');addCol({t:'c',x:hx,z:hz,r:1.3})}
  wreck(-38,-99,1.3,'#6b4a35');wreck(205,-96,.2,'#5a5f4a');wreck(150,roadMain(150)-7,1.7,'#7a2f22');
  // sunflower field (dry, November)
  for(let x=62;x<130;x+=1.5)for(let z=44;z<92;z+=1.6){if(R()<.15)continue;const xx=x+(R()-.5)*.6,zz=z+(R()-.5)*.6,y=H(xx,zz),h=1.5+R()*.5;put('sfs',GEO.trunk,MAT.grass,xx,y,zz,.35,h,.35,0,'#7a6a3a',0,0,{noCast:1});put('sfh',GEO.disc,MAT.flat,xx,y+h,zz,.55,1,.55,0,R()<.5?'#3a2a1a':'#5a4020',.9+R()*.3,0,{noCast:1})}
  // puddles
  for(const p of puddles)put('puddle',GEO.puddle,MAT.puddle,p.x,H(p.x,p.z)+.06,p.z,p.rx,1,p.rz,0,'#ffffff',0,0,{noCast:1});
  // road signs
  const rm=roadMain;
  signPost(-152,rm(-152)+5.8,-Math.PI/2,['МАЛИНІВКА'],{bg:'#fff',fg:'#111'});
  signPost(-152,rm(-152)-5.8,Math.PI/2,['МАЛИНІВКА'],{bg:'#fff',fg:'#111',cross:true});
  signPost(152,rm(152)-5.8,Math.PI/2,['МАЛИНІВКА'],{bg:'#fff',fg:'#111'});
  signPost(152,rm(152)+5.8,-Math.PI/2,['МАЛИНІВКА'],{bg:'#fff',fg:'#111',cross:true});
  signPost(-4,rm(-4)-6,Math.PI,['ГУЛЯЙПОЛЕ  14 км →','← ПОСАДКИ  2 км'],{bg:'#2457a8',fg:'#fff',w:3.4,h:1.3});
  signPost(roadVil(-92)+5,-92,Math.PI,['ОБЕРЕЖНО: ГРЯЗЮКА'],{bg:'#ffd500',fg:'#111',w:2.8,h:.8});
  signPost(-225,rm(-225)-6,Math.PI/2,['102 ТРО','ЛАСКАВО ПРОСИМО'],{bg:'#2c3a1f',fg:'#ffd500',w:2.8,h:1.2});
  await tick('Збираємо сцену…',80);
  flush();
  try{await buildTown()}catch(e){console.error(e);window.__streetErr='Гуляйполе: '+((e&&e.message)||e)}
  try{await buildStreet()}catch(e){console.error(e);window.__streetErr=(e&&e.message)||String(e)}
}
function well(x,z,s){const y=H(x,z);put('wellr',GEO.cylB,MAT.flat,x,y,z,1.7*s,.95*s,1.7*s,0,'#8f8b80');put('welli',GEO.cylB,MAT.lam,x,y+.02,z,1.3*s,.97*s,1.3*s,0,'#1d2226',0,0,{noCast:1});
  for(const sx of[-.8,.8])put('post',GEO.boxB,MAT.flat,x+sx*s,y,z,.14,2.1*s,.14,0,'#5d4630');put('wroof',GEO.prism,MAT.flat,x,y+2.1*s,z,1.9*s,.7*s,1.5*s,0,'#7a5a3a');
  put('crank',GEO.box,MAT.flat,x,y+1.55*s,z,1.7*s,.12,.12,0,'#3a2a1a');put('bucket',GEO.cylB,MAT.flat,x+.2,y+1.0*s,z,.35,.35,.35,0,'#6f7f8f');addCol({t:'c',x,z,r:.95*s})}
function tractor(x,z,r){const y=H(x,z);const p=(lx,lz)=>L(x,z,r,lx,lz);let q;
  q=p(0,.3);put('trb',GEO.boxB,MAT.flat,q[0],y+.9,q[1],1.3,1,3.2,r,'#b0402e');q=p(0,-1);put('trc',GEO.boxB,MAT.flat,q[0],y+1.8,q[1],1.5,1.5,1.5,r,'#9aa8b0');
  for(const[lx,lz,s]of[[-.95,-1,1.7],[.95,-1,1.7],[-.8,1.4,1],[.8,1.4,1]]){q=p(lx,lz);put('wheel',GEO.cylB,MAT.flat,q[0],y+s/2,q[1],s,.5,s,r,'#1d1d1d',0,Math.PI/2)}
  boxCol(x,z,1.3,2,r)}
function wreck(x,z,r,col){const y=H(x,z);let q=L(x,z,r,0,0);put('wrk',GEO.boxB,MAT.flat,q[0],y+.35,q[1],1.8,.7,4.2,r,col);q=L(x,z,r,0,-.3);put('wrk',GEO.boxB,MAT.flat,q[0],y+1.05,q[1],1.6,.65,2,r,'#2a2622');
  for(let k=0;k<5;k++){const qq=L(x,z,r,(rnd()-.5)*1.6,(rnd()-.5)*4);put('rust',GEO.box,MAT.flat,qq[0],y+.72,qq[1],.4,.04,.4,r,'#8a5a30')}boxCol(x,z,1,2.2,r)}
function signTex(lines,o){const c=document.createElement('canvas'),w=512,h=Math.round(512*(o.h||.8)/(o.w||2.6));c.width=w;c.height=h;const x=c.getContext('2d');
  x.fillStyle=o.bg;x.fillRect(0,0,w,h);x.strokeStyle=o.fg;x.lineWidth=10;x.strokeRect(12,12,w-24,h-24);x.fillStyle=o.fg;
  const fs=Math.min(h*.62/lines.length,w*.9/Math.max(...lines.map(l=>l.length))*1.65);x.font=`bold ${fs|0}px "Russo One",Arial,sans-serif`;x.textAlign='center';x.textBaseline='middle';
  lines.forEach((l,i)=>x.fillText(l,w/2,h/2+(i-(lines.length-1)/2)*fs*1.15));
  if(o.cross){x.strokeStyle='#d0202a';x.lineWidth=h*.09;x.beginPath();x.moveTo(30,h-30);x.lineTo(w-30,30);x.stroke()}
  const t=new T.CanvasTexture(c);t.anisotropy=4;return t}
function signMesh(x,y,z,ry,lines,o,dbl){const m=new T.Mesh(new T.PlaneGeometry(o.w||2.6,o.h||.8),new T.MeshLambertMaterial({map:signTex(lines,o),side:dbl?T.DoubleSide:T.FrontSide}));m.position.set(x,y,z);m.rotation.y=ry;scene.add(m);return m}
function signPost(x,z,ry,lines,o){const y=H(x,z),w=o.w||2.6,h=o.h||.8;const p1=L(x,z,ry,-w*.38,-.06),p2=L(x,z,ry,w*.38,-.06);
  put('spost',GEO.boxB,MAT.flat,p1[0],y,p1[1],.09,2.2+h/2,.09,ry,'#9a9a9a');put('spost',GEO.boxB,MAT.flat,p2[0],y,p2[1],.09,2.2+h/2,.09,ry,'#9a9a9a');
  signMesh(x,y+2.2,z,ry,lines,o,false);const back=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshLambertMaterial({color:0x8a8a8a}));back.position.set(x,y+2.2,z);back.rotation.y=ry+Math.PI;scene.add(back);addCol({t:'c',x,z,r:.25})}

