/* ================= PARTICLES ================= */
const PN=500;const pGeo=new T.BufferGeometry();const pPos=new Float32Array(PN*3),pSize=new Float32Array(PN),pA=new Float32Array(PN),pCol=new Float32Array(PN*3);
const pV=new Float32Array(PN*3),pLife=new Float32Array(PN),pMax=new Float32Array(PN),pGrow=new Float32Array(PN);let pIdx=0;
pGeo.setAttribute('position',new T.BufferAttribute(pPos,3));pGeo.setAttribute('size',new T.BufferAttribute(pSize,1));pGeo.setAttribute('alpha',new T.BufferAttribute(pA,1));pGeo.setAttribute('pcol',new T.BufferAttribute(pCol,3));
const pMat=new T.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{uScale:{value:400}},
  vertexShader:'attribute float size;attribute float alpha;attribute vec3 pcol;varying float vA;varying vec3 vC;uniform float uScale;void main(){vA=alpha;vC=pcol;vec4 mv=modelViewMatrix*vec4(position,1.0);gl_PointSize=size*uScale/max(.5,-mv.z);gl_Position=projectionMatrix*mv;}',
  fragmentShader:'varying float vA;varying vec3 vC;void main(){vec2 d=gl_PointCoord-.5;float r=length(d);if(r>.5)discard;gl_FragColor=vec4(vC,vA*(1.0-r*2.0));}'});
const pts=new T.Points(pGeo,pMat);pts.frustumCulled=false;scene.add(pts);
for(let i=0;i<PN;i++)pPos[i*3+1]=-999;
function emit(x,y,z,vx,vy,vz,life,size,col,alpha,grow){const i=pIdx;pIdx=(pIdx+1)%PN;pPos[i*3]=x;pPos[i*3+1]=y;pPos[i*3+2]=z;pV[i*3]=vx;pV[i*3+1]=vy;pV[i*3+2]=vz;pLife[i]=life;pMax[i]=life;pSize[i]=size;pA[i]=alpha;pGrow[i]=grow||0;_c.set(col);pCol[i*3]=_c.r;pCol[i*3+1]=_c.g;pCol[i*3+2]=_c.b}
function updParts(dt){for(let i=0;i<PN;i++){if(pLife[i]<=0)continue;pLife[i]-=dt;if(pLife[i]<=0){pPos[i*3+1]=-999;pA[i]=0;continue}
  pPos[i*3]+=pV[i*3]*dt;pPos[i*3+1]+=pV[i*3+1]*dt;pPos[i*3+2]+=pV[i*3+2]*dt;pV[i*3+1]-=(pGrow[i]<0?9:0)*dt;pV[i*3]*=.98;pV[i*3+2]*=.98;pSize[i]+=Math.abs(pGrow[i])*dt;pA[i]*=Math.pow(.25,dt/pMax[i])}
  pGeo.attributes.position.needsUpdate=true;pGeo.attributes.size.needsUpdate=true;pGeo.attributes.alpha.needsUpdate=true;pGeo.attributes.pcol.needsUpdate=true}

