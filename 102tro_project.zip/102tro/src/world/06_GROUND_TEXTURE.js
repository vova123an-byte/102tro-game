/* ================= GROUND TEXTURE ================= */
const TS=QL.ground,K=TS/SIZE,TP=v=>(v+HALF)*K;
const gcv=document.createElement('canvas');gcv.width=gcv.height=TS;const g=gcv.getContext('2d');
function paintGround(){
  const R=rngS(7);
  g.fillStyle='#627b37';g.fillRect(0,0,TS,TS);
  // fields
  const FK=[['#5a4027','#46321f'],['#56452a','#6f9a3c'],['#a28c55','#8c7746'],['#5f4a30','#33261a'],['#6b863d',null],['#4f5f2f','#6a7d3c']];
  for(let fz=-HALF;fz<HALF;){const fh=70+R()*80;for(let fx=-HALF;fx<HALF;){const fw=80+R()*100;const k=R()*FK.length|0,[b,r]=FK[k],vert=R()<.5;
      const x0=TP(fx+3),z0=TP(fz+3),w=(fw-6)*K,h=(fh-6)*K;g.fillStyle=b;g.fillRect(x0,z0,w,h);
      if(r){g.fillStyle=r;const st=1.7*K;if(k===3){for(let yy=z0+2;yy<z0+h;yy+=st)for(let xx=x0+2;xx<x0+w;xx+=st)g.fillRect(xx,yy,2.2,2.2)}
        else if(vert){for(let xx=x0+1;xx<x0+w;xx+=st)g.fillRect(xx,z0,st*.45,h)}else{for(let yy=z0+1;yy<z0+h;yy+=st)g.fillRect(x0,yy,w,st*.45)}}
      else{for(let i=0;i<w*h/900;i++){g.fillStyle=R()<.5?'#77924a':'#5a7333';g.fillRect(x0+R()*w,z0+R()*h,4+R()*8,3+R()*6)}}
      fx+=fw}fz+=fh}
  // village grass
  g.fillStyle='#64803a';g.beginPath();g.ellipse(TP(5),TP(22),150*K,52*K,0,0,7);g.fill();
  g.fillRect(TP(roadVil(22)-52),TP(-102),104*K,250*K);
  for(let i=0;i<5000;i++){g.fillStyle=R()<.5?'#6e8b43':'#58722f';const x=-150+R()*310,z=-102+R()*250;if(Math.abs(z-22)<52||Math.abs(x-10)<52)g.fillRect(TP(x),TP(z),3,3)}
  // yards & gardens
  for(const y of yards){g.fillStyle='#6f7f3e';g.fillRect(TP(y.x0),TP(y.z0),(y.x1-y.x0)*K,(y.z1-y.z0)*K);
    // garden (far part)
    let gx0,gz0,gx1,gz1; if(y.axis==='z'){gx0=y.x0+1;gx1=y.x1-1; if(y.sd<0){gz0=y.z0+1;gz1=y.z0+11}else{gz0=y.z1-11;gz1=y.z1-1}}
    else{gz0=y.z0+1;gz1=y.z1-1; if(y.sd<0){gx0=y.x0+1;gx1=y.x0+11}else{gx0=y.x1-11;gx1=y.x1-1}}
    y.garden=[gx0,gz0,gx1,gz1]; g.fillStyle='#4c3622';g.fillRect(TP(gx0),TP(gz0),(gx1-gx0)*K,(gz1-gz0)*K);
    g.fillStyle='#3a2a1a'; for(let a=gz0+.6;a<gz1;a+=1.2)g.fillRect(TP(gx0),TP(a),(gx1-gx0)*K,1.6);
    // path to door
    g.fillStyle='#8a7a5a'; if(y.axis==='z'){const zz=y.sd<0?y.z1-6:y.z0;g.fillRect(TP(y.cx-.8),TP(zz),1.6*K,6*K)}else{const xx=y.sd<0?y.x1-6:y.x0;g.fillRect(TP(xx),TP(y.cz-.8),6*K,1.6*K)}
  }
  // square
  g.fillStyle='#9a9384';g.beginPath();g.ellipse(TP(24),TP(36),13*K,9*K,0,0,7);g.fill();
  g.fillStyle='#8a8476';for(let i=0;i<400;i++)g.fillRect(TP(12+R()*24),TP(29+R()*14),3,2);
  // posadka floor
  g.fillStyle='#39482a';g.fillRect(0,TP(POS0-2),TS,(POS1-POS0+4)*K);
  for(let i=0;i<26000;i++){const c=R();g.fillStyle=c<.3?'#7a5a2a':c<.5?'#94672a':c<.7?'#4a3a22':'#2f3c20';g.fillRect(R()*TS,TP(POS0-3+R()*(POS1-POS0+6)),2+R()*3,2+R()*3)}
  // roads
  const line=(pts,w,col,dash)=>{g.strokeStyle=col;g.lineWidth=w*K;g.lineCap='round';g.lineJoin='round';g.setLineDash(dash||[]);g.beginPath();pts.forEach((p,i)=>i?g.lineTo(TP(p[0]),TP(p[1])):g.moveTo(TP(p[0]),TP(p[1])));g.stroke();g.setLineDash([])};
  const off=(pts,o)=>pts.map((p,i)=>{const a=pts[Math.max(0,i-1)],b=pts[Math.min(pts.length-1,i+1)];const dx=b[0]-a[0],dz=b[1]-a[1],l=Math.hypot(dx,dz)||1;return[p[0]-dz/l*o,p[1]+dx/l*o]});
  const roads=[[],[],[]];
  for(let x=-HALF-5;x<=HALF+5;x+=3)roads[0].push([x,roadMain(x)]);
  for(let z=-HALF-5;z<=HALF+5;z+=3)roads[1].push([roadVil(z),z]);
  for(let t=0;t<=1.0001;t+=.02)roads[2].push([FR[0]+(FR[2]-FR[0])*t,FR[1]+(FR[3]-FR[1])*t]);
  const W=[8,7,6.4];
  roads.forEach((r,i)=>line(r,W[i]+2.4,'#55452f'));
  roads.forEach((r,i)=>line(r,W[i],'#7d6443'));
  roads.forEach((r,i)=>{line(off(r,W[i]*.24),.9,'#5f4a31');line(off(r,-W[i]*.24),.9,'#5f4a31');g.globalAlpha=.45;line(r,.9,'#6f8a3e');g.globalAlpha=1});
  for(let i=0;i<9000;i++){const r=roads[R()*3|0],p=r[R()*r.length|0];g.fillStyle=R()<.5?'#8c7350':'#6a5338';g.fillRect(TP(p[0]+(R()-.5)*7),TP(p[1]+(R()-.5)*7),2,2)}
  // mud in posadka gaps
  for(const gx of[GAP1,GAP2]){for(let i=0;i<60;i++){g.fillStyle=R()<.5?'#4a3520':'#3a2a19';g.beginPath();g.ellipse(TP(gx+(R()-.5)*9),TP(POS0+R()*(POS1-POS0)),(1+R()*2)*K,(.6+R())*K,R()*3,0,7);g.fill()}}
  paintTown(g,TP,K);
  // puddles
  for(const p of puddles){g.fillStyle='#3d3426';g.beginPath();g.ellipse(TP(p.x),TP(p.z),(p.rx+.5)*K,(p.rz+.5)*K,0,0,7);g.fill()}
  // noise
  const id=g.getImageData(0,0,TS,TS),d=id.data;
  for(let by=0;by<TS;by+=2)for(let bx=0;bx<TS;bx+=2){const n=(R()*16-8)|0;for(let yy=0;yy<2;yy++){let q=((by+yy)*TS+bx)*4;for(let xx=0;xx<2;xx++,q+=4){const l=d[q]*.3+d[q+1]*.59+d[q+2]*.11;d[q]=l+(d[q]-l)*.7+n+5;d[q+1]=l+(d[q+1]-l)*.7+n+2;d[q+2]=l+(d[q+2]-l)*.7+n-2}}}
  g.putImageData(id,0,0);
}

