/* ================= 3D ASSET IMPORT (GLB / glTF 2.0) ================= */
const ASLOTS={
  house:{n:'Будинки села',i:'🏠',d:'Модель хати ставиться на місце всіх будинків Малинівки (половина — дзеркально). Великі моделі вписуються в ділянку ~11×8 м.',fit:'foot'},
  hero:{n:'Боєць 102',i:'🪖',d:'Людина ≈1,8 м. Якщо в GLB є анімації (idle / walk / run / jump), гра сама їх підхопить.',fit:'height',size:1.8},
  pickup:{n:'Пікап',i:'🛻',d:'Авто ≈5,3 м завдовжки. Вузли з назвою «wheel» крутитимуться під час руху.',fit:'length',size:5.3}};
const ASSET={},SLOT={},CREDITS={};let GLTF_READY=null;
function loadScriptSeq(urls){return new Promise((res,rej)=>{let i=0;const next=()=>{if(i>=urls.length)return rej(new Error('не вдалося завантажити GLTFLoader (перевір інтернет)'));
  const s=document.createElement('script');s.src=urls[i++];s.async=true;let done=false;const to=setTimeout(()=>{if(!done){done=true;next()}},15000);
  s.onload=()=>{if(done)return;done=true;clearTimeout(to);res()};s.onerror=()=>{if(done)return;done=true;clearTimeout(to);next()};document.head.appendChild(s)};next()})}
function gltfLib(){if(T.GLTFLoader)return Promise.resolve();if(!GLTF_READY)GLTF_READY=loadScriptSeq(['vendor/GLTFLoader.js','https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/GLTFLoader.js','https://unpkg.com/three@0.128.0/examples/js/loaders/GLTFLoader.js'])
  .then(()=>{if(!T.GLTFLoader)throw new Error('GLTFLoader не ініціалізувався')}).catch(e=>{GLTF_READY=null;throw e});return GLTF_READY}
const IDB={db:null,
  open(){return new Promise(res=>{try{const r=indexedDB.open('tro102_assets',1);r.onupgradeneeded=()=>{try{r.result.createObjectStore('f')}catch(e){}};r.onsuccess=()=>{this.db=r.result;res(this.db)};r.onerror=()=>res(null);r.onblocked=()=>res(null)}catch(e){res(null)}})},
  async op(mode,fn){const db=this.db||await this.open();if(!db)return null;return new Promise(res=>{try{const tx=db.transaction('f',mode),rq=fn(tx.objectStore('f'));tx.oncomplete=()=>res(rq?rq.result:null);tx.onerror=()=>res(null);tx.onabort=()=>res(null)}catch(e){res(null)}})},
  get(k){return this.op('readonly',s=>s.get(k))},put(k,v){return this.op('readwrite',s=>s.put(v,k))},del(k){return this.op('readwrite',s=>s.delete(k))}};
function isGLB(buf){try{return buf&&buf.byteLength>20&&new DataView(buf).getUint32(0,true)===0x46546C67}catch(e){return false}}
function parseGLB(buf){return gltfLib().then(()=>new Promise((res,rej)=>{const cib=window.createImageBitmap;try{window.createImageBitmap=undefined}catch(e){}try{new T.GLTFLoader().parse(buf,'',res,e=>rej(new Error((e&&e.message)||'файл GLB пошкоджений або не підтримується')))}catch(e){rej(e)}finally{try{window.createImageBitmap=cib}catch(e){}}}))}
function prepModel(gltf,slot,rot,opt){opt=opt||{};const root=gltf.scene||(gltf.scenes&&gltf.scenes[0]);if(!root)throw new Error('у файлі немає 3D-сцени');let tris=0;
  root.traverse(o=>{if(!o.isMesh)return;o.castShadow=true;o.receiveShadow=true;if(o.isSkinnedMesh)o.frustumCulled=false;const g=o.geometry;if(g&&g.attributes&&g.attributes.position)tris+=(g.index?g.index.count:g.attributes.position.count)/3;
    (Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{if(!m)return;m.userData.lin=true;if(m.isMeshStandardMaterial&&STD.indexOf(m)<0){m.userData.env=1;STD.push(m)}
      ['map','normalMap','roughnessMap','metalnessMap','aoMap','emissiveMap'].forEach(k=>{if(m[k])m[k].anisotropy=Math.min(QL.aniso,renderer.capabilities.getMaxAnisotropy()||1)})})});
  const inner=new T.Group(),pivot=new T.Group();inner.add(root);inner.rotation.y=(rot||0)*Math.PI/2;pivot.add(inner);inner.updateMatrixWorld(true);
  let box=new T.Box3().setFromObject(inner),sz=box.getSize(new T.Vector3());const sp=ASLOTS[slot];let s=1;
  if(sp.fit==='height')s=sp.size/Math.max(.01,sz.y);
  else if(sp.fit==='length')s=sp.size/Math.max(.01,sz.z);
  else{const H0=SLOT.house||{W:11,D:8};s=Math.min(H0.W/Math.max(.01,sz.x),H0.D/Math.max(.01,sz.z));if(s>=1&&sz.y>2.5&&sz.y<14)s=1}
  if(!isFinite(s)||s<=0)s=1;inner.scale.setScalar(s);inner.updateMatrixWorld(true);box=new T.Box3().setFromObject(inner);const c=box.getCenter(new T.Vector3());
  inner.position.set(-c.x,opt.keepY?0:-box.min.y,-c.z);sz=box.getSize(new T.Vector3());
  return{pivot,root,tris:Math.round(tris),clips:gltf.animations||[],dims:[sz.x,sz.y,sz.z]}}
function removeAssetObj(slot){const A=ASSET[slot];if(A&&A.pivot&&A.pivot.parent)A.pivot.parent.remove(A.pivot);if(A){A.pivot=null;A.mixer=null;A.act=null;A.cur=null;A.wheels=null}
  if(slot==='house')restoreHouses(A);
  if(slot==='hero'&&hero)hero.body.visible=true;
  if(slot==='pickup'&&car){car.body.children.forEach(c=>c.visible=true);car.wheels.forEach(w=>w.piv.visible=true)}}
function playAct(A,k){if(!A.act||A.cur===k)return;const nx=A.act[k]||A.act.idle;if(!nx)return;if(A.curA===nx){A.cur=k;return}nx.reset();nx.fadeIn(.25);nx.play();if(A.curA)A.curA.fadeOut(.25);A.cur=k;A.curA=nx}
function tintCar(root){const col=CARCOL[S.carColor]||CARCOL[0];root.traverse(o=>{if(!o.isMesh)return;(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{if(m&&m.color&&/paint|body|car|кузов|carpaint/i.test(m.name||'')){m.color.set(col.c).convertSRGBToLinear()}})})}
function applyAsset(slot){const A=ASSET[slot];removeAssetObj(slot);if(!A||!A.gltf)return;
  const m=prepModel(A.gltf,slot,A.rot,A.opt);A.pivot=m.pivot;A.tris=m.tris;A.clips=m.clips.map(c=>c.name||'без назви');A.dims=m.dims;
  if(slot==='house'){placeHouses(A,m)}
  if(slot==='hero'&&hero){hero.body.visible=false;hero.grp.add(m.pivot);A.mixer=null;A.act=null;A.cur=null;A.curA=null;
    if(m.clips.length){A.mixer=new T.AnimationMixer(m.root);const pick=re=>m.clips.find(c=>re.test(c.name||''));
      const map={idle:pick(/idle|stand|breath|rest/i),walk:pick(/walk/i),run:pick(/run|sprint|jog/i),jump:pick(/jump|fall|air/i),crouch:pick(/crouch|sneak/i)};
      if(!map.walk)map.walk=map.run||m.clips[0];if(!map.run)map.run=map.walk;if(!map.idle)map.idle=m.clips[0];A.act={};for(const k in map)if(map[k])A.act[k]=A.mixer.clipAction(map[k]);playAct(A,'idle')}}
  if(slot==='pickup'&&car){car.body.children.forEach(c=>c.visible=false);car.body.add(m.pivot);const hits=[];m.root.traverse(o=>{if(o!==m.root&&/wheel|tire|tyre|колес|rim/i.test(o.name||''))hits.push(o)});
    A.wheels=hits.filter(o=>!hits.some(h=>h!==o&&isAnc(o,h)));car.wheels.forEach(w=>w.piv.visible=A.wheels.length===0);tintCar(m.root)}}
const _zeroM=new T.Matrix4().makeScale(0,0,0),_tmpM=new T.Matrix4();
function houseTargets(){const t=[];(SLOT.houses||[]).forEach(h=>t.push({kind:'street',ref:h,x:h.x,z:h.z,ry:h.ry}));houses.forEach(h=>t.push({kind:'old',ref:h,x:h.x,z:h.z,ry:h.rot}));return t}
function setCol(c,x,z,hw,hd,ry){if(!c)return;if(!c.orig)c.orig=[c.x0,c.x1,c.z0,c.z1];const sw=Math.abs(Math.sin(ry))>.7,a=sw?hd:hw,b=sw?hw:hd;c.x0=x-a;c.x1=x+a;c.z0=z-b;c.z1=z+b}
function placeHouses(A,m){const tg=houseTargets();A.clones=[];const hw=m.dims[0]/2+.12,hd=m.dims[2]/2+.12;
  tg.forEach((t,i)=>{const c=i===0?m.pivot:m.pivot.clone();c.position.set(t.x,H(t.x,t.z),t.z);c.rotation.y=t.ry;if(i%2===1)c.scale.x=-1;scene.add(c);
    const meshes=[];c.traverse(o=>{if(o.isMesh)meshes.push(o)});A.clones.push({obj:c,meshes,x:t.x,z:t.z});
    if(t.kind==='street'){t.ref.proc.visible=false;setCol(t.ref.col,t.x,t.z,hw,hd,t.ry);t.ref.extra.forEach(e=>e.off=true)}
    else{const h=t.ref;h.saved=h.saved||[];(h.inst||[]).forEach(([k,ix],j)=>{const ms=BATCH[k]&&BATCH[k].mesh;if(!ms)return;if(!h.saved[j]){ms.getMatrixAt(ix,_tmpM);h.saved[j]=_tmpM.clone()}ms.setMatrixAt(ix,_zeroM);ms.instanceMatrix.needsUpdate=true});setCol(h.col,t.x,t.z,hw,hd,t.ry)}});
  A.count=tg.length;A.cullT=0}
function restoreHouses(A){if(A&&A.clones)A.clones.forEach(c=>{if(c.obj.parent)c.obj.parent.remove(c.obj)});if(A)A.clones=null;
  (SLOT.houses||[]).forEach(h=>{h.proc.visible=true;if(h.col&&h.col.orig)[h.col.x0,h.col.x1,h.col.z0,h.col.z1]=h.col.orig;h.extra.forEach(e=>e.off=false)});
  houses.forEach(h=>{if(h.saved)(h.inst||[]).forEach(([k,ix],j)=>{const ms=BATCH[k]&&BATCH[k].mesh;if(ms&&h.saved[j]){ms.setMatrixAt(ix,h.saved[j]);ms.instanceMatrix.needsUpdate=true}});if(h.col&&h.col.orig)[h.col.x0,h.col.x1,h.col.z0,h.col.z1]=h.col.orig})}
function cullHouses(dt){const A=ASSET.house;if(!A||!A.clones)return;A.cullT-=dt;if(A.cullT>0)return;A.cullT=.4;const far=S.quality==='low'?110:160,cx=camera.position.x,cz=camera.position.z;
  for(const c of A.clones){const d=Math.hypot(c.x-cx,c.z-cz);c.obj.visible=d<far;const sh=d<55;if(c.sh!==sh){c.sh=sh;c.meshes.forEach(m=>m.castShadow=sh)}}}
function isAnc(a,b){let p=b.parent;while(p){if(p===a)return true;p=p.parent}return false}
async function importBuf(slot,buf,name,rot,src,save,opt){if(!isGLB(buf))throw new Error('це не файл .glb (потрібен бінарний glTF 2.0 одним файлом)');
  setAStat(slot,'load','Розбираємо модель…');const d=glbData(buf);let gltf,info;
  if(!d.animated){const imgs=await glbImages(d,S.quality==='low'?512:1024,(a,b)=>setAStat(slot,'load','Текстури '+a+'/'+b));gltf=glbBuild(d,imgs);info={tris:gltf.tris,tex:gltf.imgOk,texAll:gltf.imgTotal,mat:gltf.matN};
    if(gltf.imgTotal&&gltf.imgOk<gltf.imgTotal)toast('⚠ Завантажено лише '+gltf.imgOk+' з '+gltf.imgTotal+' текстур')}
  else{gltf=await parseGLB(buf.slice(0));info={tris:d.tris,anim:true}}
  ASSET[slot]={name,bytes:buf.byteLength,rot:rot||0,gltf,src,buf,opt:opt||{},info};applyAsset(slot);
  const A=ASSET[slot];setAStat(slot,'ok',(slot==='house'?plBud(A.count||1)+' · ':'')+(info.tris/1000).toFixed(1)+' тис. трикутників'+(info.texAll?' · текстур '+info.tex+'/'+info.texAll:'')+(info.mat?' · PBR-матеріалів '+info.mat:''));
  if(save){const ok=await IDB.put(slot,{name,buf,rot:rot||0});if(ok===null&&!IDB.db)toast('Модель працює, але не збережеться після перезапуску (сховище недоступне)')}}
function updAssets(dt){cullHouses(dt);const A=ASSET.hero;if(A&&A.pivot){if(A.mixer){const sp=Math.hypot(P.vx,P.vz);playAct(A,!P.ground?'jump':(inp.crouch&&A.act.crouch)?'crouch':sp>4.6?'run':sp>.4?'walk':'idle');if(A.curA){A.curA.timeScale=A.cur==='walk'?clamp(sp/1.5,.6,1.6):A.cur==='run'?clamp(sp/5,.8,1.4):1}A.mixer.update(dt)}
    else{const mv=clamp(Math.hypot(P.vx,P.vz)/3,0,1);A.pivot.position.y=Math.abs(Math.sin(P.walk))*.04*mv-(inp.crouch?.35:0);A.pivot.rotation.x=mv*.06}}
  const W=ASSET.pickup;if(W&&W.wheels&&W.wheels.length&&car)W.wheels.forEach(w=>w.rotation.x+=C.v*dt/.42)}
async function fetchProg(url,cb){const r=await fetch(url);if(!r.ok)throw new Error('файл '+url+' недоступний ('+r.status+')');const tot=+r.headers.get('content-length')||0;
  if(!r.body||!r.body.getReader||!tot)return r;const rd=r.body.getReader(),parts=[];let got=0,lastP=-1;for(;;){const{done,value}=await rd.read();if(done)break;parts.push(value);got+=value.length;const p=Math.min(99,Math.floor(got/tot*100));if(p!==lastP&&p%5===0){lastP=p;cb(p)}}
  return new Response(new Blob(parts),{status:200,headers:{'content-type':r.headers.get('content-type')||''}})}
async function loadAssetsAtBoot(){let man=null;try{const r=await fetch('assets/manifest.json',{cache:'no-cache'});if(r.ok)man=await r.json()}catch(e){}
  for(const k of Object.keys(ASLOTS)){try{let rec=await IDB.get(k),src='user';if(!rec&&man&&man[k])setAStat(k,'load','завантаження файлу…');
      if(!rec&&man&&man[k]){const r=await fetchProg('assets/'+man[k].file,p=>setAStat(k,'load','завантаження '+p+'%'));if(r.ok){let buf;if(/\.json$/i.test(man[k].file)){const j=await r.json();const bin=atob(j.b64);const u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);buf=u.buffer}else buf=await r.arrayBuffer();rec={name:man[k].file.replace(/\.json$/i,''),buf,rot:man[k].rot||0,opt:man[k]};src='bundled'}}
      if(!rec||!rec.buf)continue;await importBuf(k,rec.buf,rec.name,rec.rot,src,false,rec.opt);if(rec.opt&&rec.opt.credit)CREDITS[k]=rec.opt.credit;if(ASTAT[k]&&ASTAT[k].st==='ok')toast(ASLOTS[k].i+' Справжня модель: '+ASTAT[k].msg);}
    catch(e){setAStat(k,'err',(e&&e.message)||String(e));window.__bootFail('3D-модель «'+ASLOTS[k].n+'» не завантажилась: '+(e&&e.message||e)+'. Гра працює з вбудованою моделлю.')}}}
const plBud=n=>{const a=n%10,b=n%100;return n+' '+(a===1&&b!==11?'будинок':a>=2&&a<=4&&(b<12||b>14)?'будинки':'будинків')};
let assetSlotPick=null;const ASTAT={};
function setAStat(slot,st,msg){ASTAT[slot]={st,msg};const s=ASLOTS[slot];const ic=st==='ok'?'✅':st==='err'?'❌':'⏳';
  const html=Object.keys(ASTAT).map(k=>{const a=ASTAT[k];return`<div class="as-${a.st}">${a.st==='ok'?'✅':a.st==='err'?'❌':'⏳'} ${ASLOTS[k].i} ${ASLOTS[k].n.split(' ·')[0]}: ${esc(a.msg)}</div>`}).join('');
  const m=document.getElementById('astat');if(m)m.innerHTML=html;const h=document.getElementById('hstat');if(h){h.innerHTML=html;h.style.display=html?'block':'none'}}
function assetsPanelHTML(){const f=b=>b>1048576?(b/1048576).toFixed(1)+' МБ':Math.round(b/1024)+' КБ';
  return `<p style="margin-top:0">Тут можна замінити вбудовані моделі справжніми 3D-моделями у форматі <b>.glb</b>. Файл обирається у «Файлах» iPhone і зберігається <b>лише на цьому пристрої</b>. Щоб модель була в грі для всіх — надішли файл мені в чат, і я вбудую його в гру.</p>`+
  Object.keys(ASLOTS).map(k=>{const s=ASLOTS[k],A=ASSET[k];const st=A&&A.pivot?`✅ <b>${esc(A.name)}</b> · ${f(A.bytes)} · ${(((A.info&&A.info.tris)||A.tris)/1000).toFixed(1)} тис. трикутників${A.count?' · замінено будинків: '+A.count:''}${A.info&&A.info.texAll?' · текстур '+A.info.tex+'/'+A.info.texAll:''}${A.clips&&A.clips.length?' · анімації: '+esc(A.clips.slice(0,6).join(', ')):''}${A.src==='bundled'?' · вбудована в гру':''}${CREDITS[k]&&A.src==='bundled'?'<br>Автор: '+esc(CREDITS[k]):''}`:'Зараз: вбудована процедурна модель гри';
    return `<div class="card"><div class="ic">${s.i}</div><div class="bd"><div class="nm">${s.n}</div><div class="ds">${s.d}</div><div class="ds" style="margin-top:4px;opacity:.95">${st}</div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px"><button class="sb y" data-p="glb:${k}">ВИБРАТИ .GLB</button>${A&&A.pivot&&k==='house'?`<button class="sb y" data-p="view:house">👁 ПОДИВИТИСЯ</button>`:''}${A&&A.pivot?`<button class="sb" data-p="rot:${k}">↻ 90°</button><button class="sb" data-p="del:${k}">ПОВЕРНУТИ ВБУДОВАНУ</button>`:''}</div></div></div>`}).join('')+
  `<div class="nm ru" style="margin:12px 0 4px">Вимоги до файлу</div><div class="ds">• Формат <b>.glb</b> (glTF 2.0 одним файлом). Архіви .zip та .gltf з окремими текстурами не підійдуть.<br>• Без стиснення Draco/KTX2/Meshopt — у цьому середовищі їхні декодери не завантажуються.<br>• Розмір до ~20 МБ, текстури до 2048 px, для телефона краще до 100 тис. трикутників на модель.<br>• Перед моделі має дивитися вперед (вісь +Z). Якщо модель стоїть боком — натисни «↻ 90°».<br>• Для бійця: модель зі скелетом і анімаціями idle / walk / run (назви англійською).</div>
  <div class="nm ru" style="margin:12px 0 4px">Де взяти моделі з дозволом на використання</div><div class="ds">
  • <a href="https://sketchfab.com/search?features=downloadable&type=models" style="color:#ffd84a">Sketchfab</a> — найбільше реалістичних моделей. Фільтр «Downloadable», ліцензії CC0 або CC BY (для CC BY треба вказати автора). При завантаженні обери формат <b>GLB</b>.<br>
  • <a href="https://poly.pizza" style="color:#ffd84a">Poly Pizza</a> — прямі .glb (CC0 / CC BY), але переважно стилізовані.<br>
  • <a href="https://quaternius.com" style="color:#ffd84a">Quaternius</a> — CC0, персонажі з готовими анімаціями (стилізовані).<br>
  • <a href="https://polyhaven.com" style="color:#ffd84a">Poly Haven</a> — CC0 фототекстури й HDRI-небо (моделі там у форматі glTF-архіву).<br>
  Пошукові слова: «village house», «old house», «pickup truck», «soldier», «tree», «wooden fence». Моделі реальних авто — без логотипів брендів.</div>`}

