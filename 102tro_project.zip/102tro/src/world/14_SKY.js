/* ================= SKY ================= */
const starsGeo=new T.BufferGeometry();{const a=new Float32Array(600*3);for(let i=0;i<600;i++){const th=rnd()*Math.PI*2,ph=rnd()*1.3;a[i*3]=Math.cos(th)*Math.cos(ph)*500;a[i*3+1]=Math.sin(ph)*500+20;a[i*3+2]=Math.sin(th)*Math.cos(ph)*500}starsGeo.setAttribute('position',new T.BufferAttribute(a,3))}
const stars=new T.Points(starsGeo,new T.PointsMaterial({color:0xffffff,size:1.6,sizeAttenuation:false,transparent:true,opacity:0,fog:false}));scene.add(stars);
const clouds=new T.Group();scene.add(clouds);
{const cm=new T.MeshLambertMaterial({color:0xffffff,flatShading:true,transparent:true,opacity:.92,fog:false});for(let i=0;i<14;i++){const c=new T.Group();for(let k=0;k<4;k++){const m=new T.Mesh(GEO.ico,cm);m.scale.set(9+rnd()*8,3+rnd()*2,7+rnd()*6);m.position.set(k*9-13,rnd()*2,(rnd()-.5)*6);c.add(m)}c.position.set(-350+rnd()*700,90+rnd()*30,-350+rnd()*700);clouds.add(c)}}
const sunDisc=new T.Mesh(new T.CircleGeometry(14,20),new T.MeshBasicMaterial({color:0xfff1c0,fog:false}));scene.add(sunDisc);
const SKY={day:new T.Color(0xa9c2d6),dusk:new T.Color(0xd9875a),night:new T.Color(0x0b1124)};

