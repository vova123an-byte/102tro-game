/* ================= ПОГОДА ================= */
if(!S.weather)S.weather='clear';
const WX={cur:'clear',force:null,t:120,k:{rain:0,fog:0,storm:0},flash:0,thT:5,drops:null,dropPos:null};
function setWeather(w,quiet){WX.cur=w;S.weather=w;if(!quiet)toast({clear:'☀️ Розвиднілося',rain:'🌧 Почався дощ',fog:'🌫 Насунув туман',storm:'⛈ Буревій!'}[w])}
let rainAud=null;
function updWeather(dt){if(!WX.force){WX.t-=dt;if(WX.t<=0){WX.t=150+Math.random()*180;const r=Math.random();setWeather(r<.5?'clear':r<.78?'rain':'fog')}}else if(WX.cur!==WX.force)setWeather(WX.force,true);
  const w=WX.cur,tg={rain:w==='rain'||w==='storm'?1:0,fog:w==='fog'?1:w==='storm'?.5:0,storm:w==='storm'?1:0};for(const k in WX.k)WX.k[k]=lerp(WX.k[k],tg[k],Math.min(1,dt*.25));
  const rk=WX.k.rain;
  if(rk>.02){if(!WX.drops){const n=S.quality==='low'?500:S.quality==='high'?1600:1000;const g=new T.BufferGeometry();WX.dropPos=new Float32Array(n*6);for(let i=0;i<n;i++){const x=(Math.random()-.5)*60,y=Math.random()*30,z=(Math.random()-.5)*60;WX.dropPos.set([x,y,z,x,y-.7,z],i*6)}
      g.setAttribute('position',new T.BufferAttribute(WX.dropPos,3));WX.drops=new T.LineSegments(g,new T.LineBasicMaterial({color:0xaab6c0,transparent:true,opacity:.35,fog:false}));WX.drops.frustumCulled=false;scene.add(WX.drops)}
    WX.drops.visible=true;WX.drops.material.opacity=.35*rk;const a=WX.dropPos,n=a.length/6,cx=camera.position.x,cy=camera.position.y,cz=camera.position.z,sp=26*dt,wx=(3+WX.k.storm*8)*dt;
    for(let i=0;i<n;i++){const o=i*6;let y=a[o+1]-sp,x=a[o]+wx;if(y<cy-12||Math.abs(x-cx)>30||Math.abs(a[o+2]-cz)>30){y=cy+12+Math.random()*10;x=cx+(Math.random()-.5)*60;a[o+2]=a[o+5]=cz+(Math.random()-.5)*60}a[o]=x;a[o+1]=y;a[o+3]=x-wx*3;a[o+4]=y-.8}
    WX.drops.geometry.attributes.position.needsUpdate=true}else if(WX.drops)WX.drops.visible=false;
  if(AC){if(!rainAud){const s2=AC.createBufferSource();s2.buffer=AC.nb;s2.loop=true;const f=AC.createBiquadFilter();f.type='highpass';f.frequency.value=900;const g2=AC.createGain();g2.gain.value=0;s2.connect(f).connect(g2).connect(sfxG);s2.start();rainAud=g2}
    rainAud.gain.setTargetAtTime(S.sound?rk*.09:0,AC.currentTime,.4)}
  if(WX.k.storm>.5){WX.thT-=dt;if(WX.thT<=0){WX.thT=5+Math.random()*9;WX.flash=1;setTimeout(()=>{noise(2.2,140,.45,'lowpass');tone(60,35,1.8,'sine',.25)},400+Math.random()*900)}}
  WX.flash=Math.max(0,WX.flash-dt*3);
  if(scene.fog&&scene.fog.density!==undefined)scene.fog.density=(Q[S.quality]||Q.medium).fog*(1+WX.k.fog*2.2+rk*.7);
  WIND.value+=dt*(rk*1.5+WX.k.storm*3)}
function weatherLight(){const rk=WX.k.rain,dim=1-rk*.55-WX.k.fog*.3;sun.intensity*=Math.max(.2,dim);if(skyMesh)skyMesh.material.uniforms.uCloud.value=Math.min(1,skyMesh.material.uniforms.uCloud.value+rk*.6+WX.k.fog*.3);
  if(WX.flash>0){hemi.intensity+=WX.flash*2.5}if(MATS.road)MATS.road.roughness=1-rk*.45}

