/* ================= REALISM MODULE (Етап 1.5: вулиця Садова) ================= */
const TX={},MATS={},STD=[];const UP=new T.Vector3(0,1,0);
const _q2=new T.Quaternion(),_e=new T.Euler(),_hsl={h:0,s:0,l:0};
function desat(c){c.getHSL(_hsl);c.setHSL(_hsl.h,_hsl.s*.66,_hsl.l*.92);return c.convertSRGBToLinear()}
function linearizeAll(root){root.traverse(o=>{if(!o.material)return;(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{if(!m||m.userData.lin||m.isShaderMaterial)return;m.userData.lin=true;
  if(m.color)m.color.convertSRGBToLinear();if(m.emissive)m.emissive.convertSRGBToLinear();if(m.map){m.map.encoding=T.sRGBEncoding;m.map.needsUpdate=true}m.needsUpdate=true})})}
function std(o){const m=new T.MeshStandardMaterial(o);if(o.color!==undefined)m.color.convertSRGBToLinear();if(o.emissive!==undefined)m.emissive.convertSRGBToLinear();
  m.userData.lin=true;m.userData.env=o.envMapIntensity!=null?o.envMapIntensity:1;STD.push(m);return m}
const hex2rgb=h=>{const c=new T.Color(h);return[c.r*255,c.g*255,c.b*255]};
function cnv(w,h){const c=document.createElement('canvas');c.width=w;c.height=h||w;return c}
function mkTex(c,o){o=o||{};const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=o.clamp?T.ClampToEdgeWrapping:T.RepeatWrapping;
  t.anisotropy=Math.min(QL.aniso,renderer.capabilities.getMaxAnisotropy()||1);if(o.srgb!==false)t.encoding=T.sRGBEncoding;if(o.rep)t.repeat.set(o.rep[0],o.rep[1]);return t}
function hsh(a,b){const s=Math.sin(a*127.1+b*311.7)*43758.5453;return s-Math.floor(s)}
function VN(seed){const R=rngS(seed),N=256,p=new Float32Array(N*N);for(let i=0;i<N*N;i++)p[i]=R();
  const at=(x,y,per)=>p[(((y%per)+per)%per)*N+(((x%per)+per)%per)];
  function n(x,y,per){const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf);
    const a=at(xi,yi,per),b=at(xi+1,yi,per),c=at(xi,yi+1,per),d=at(xi+1,yi+1,per);return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v}
  return function(x,y,per,oct){let s=0,a=.5,f=1,tot=0;for(let i=0;i<(oct||4);i++){s+=a*n(x*f,y*f,Math.min(256,per*f));tot+=a;a*=.5;f*=2}return s/tot}}
function gen(w,h,fn){const c=cnv(w,h),x=c.getContext('2d'),id=x.createImageData(w,h),d=id.data,hg=new Float32Array(w*h),O=[0,0,0,255,.5];
  for(let j=0;j<h;j++)for(let i=0;i<w;i++){O[3]=255;O[4]=.5;fn(i/w,j/h,O);const o=(j*w+i)*4;d[o]=O[0];d[o+1]=O[1];d[o+2]=O[2];d[o+3]=O[3];hg[j*w+i]=O[4]}
  x.putImageData(id,0,0);return{c,h:hg,w,hh:h}}
function nrm(g,str){if(!QL.normal)return null;const w=g.w,h=g.hh,a=g.h,c=cnv(w,h),x=c.getContext('2d'),id=x.createImageData(w,h),d=id.data;str*=w/512;
  const H=(i,j)=>a[(((j%h)+h)%h)*w+(((i%w)+w)%w)];
  for(let j=0;j<h;j++)for(let i=0;i<w;i++){const dx=(H(i+1,j)-H(i-1,j))*str,dy=(H(i,j+1)-H(i,j-1))*str,l=Math.hypot(dx,dy,1),o=(j*w+i)*4;
    d[o]=(-dx/l*.5+.5)*255;d[o+1]=(dy/l*.5+.5)*255;d[o+2]=(1/l*.5+.5)*255;d[o+3]=255}
  x.putImageData(id,0,0);return mkTex(c,{srgb:false})}
function roughFrom(g,lo,hi){const w=g.w,h=g.hh,c=cnv(w,h),x=c.getContext('2d'),id=x.createImageData(w,h),d=id.data;
  for(let i=0;i<w*h;i++){const v=clamp(lo+(hi-lo)*g.h[i]*1.6,0,1)*255;d[i*4]=v;d[i*4+1]=v;d[i*4+2]=v;d[i*4+3]=255}x.putImageData(id,0,0);return mkTex(c,{srgb:false})}

/* ---- procedural PBR textures ---- */
function texPlaster(){const s=QL.tex,f=VN(11);return gen(s,s,(u,v,O)=>{const n=f(u*6,v*6,6,5),m=f(u*24,v*24,24,3);let b=.84+(n-.5)*.16+(m-.5)*.08;
  const st=f(u*10+5,v*2,10,3);b-=Math.max(0,st-.62)*.5;const cr=Math.abs(f(u*4+9,v*4+1,4,4)-.5),k=(cr<.0042&&f(u*8+2,v*8+5,8,2)>.58)?1:0;
  O[0]=b*238*(k?.55:1);O[1]=b*233*(k?.55:1);O[2]=b*222*(k?.52:1);O[4]=.5+(m-.5)*.7+(n-.5)*.25-k*.5})}
function texBrick(c1,c2,mo,seed){const s=QL.tex,f=VN(seed);return gen(s,s,(u,v,O)=>{const rows=13,row=Math.floor(v*rows),fy=v*rows-row,sh=(row&1)*.5,bx=u*4+sh,bi=Math.floor(bx)%4,fx=bx-Math.floor(bx);
  const n=f(u*32,v*32,32,3);
  if(fy<.14||fx<.035){const g=.72+n*.28;O[0]=mo[0]*g;O[1]=mo[1]*g;O[2]=mo[2]*g;O[4]=.12+n*.1;return}
  const id=hsh(bi,row),e=Math.min(fy-.14,1-fy,(fx-.035)*.3,(1-fx)*.3);const t=.8+id*.32+(n-.5)*.22-(e<.04?.1:0);const c=id<.5?c1:c2;
  O[0]=c[0]*t;O[1]=c[1]*t;O[2]=c[2]*t;O[4]=.62+(n-.5)*.18-(e<.03?.12:0)})}
function texSlate(){const s=QL.tex,f=VN(23);return gen(s,s,(u,v,O)=>{const w=Math.sin(u*8*Math.PI*2)*.5+.5,n=f(u*8,v*8,8,4),m=f(u*40,v*40,40,2),lap=v<.06?1:0;
  let b=.6+w*.14+(n-.5)*.2+(m-.5)*.06-lap*.14;b-=(1-w)*Math.max(0,f(u*16,v*2+3,16,3)-.5)*.6;
  let r=b*170,g=b*172,bb=b*166;const li=f(u*12+7,v*12+3,12,4);if(li>.64){const k=Math.min(1,(li-.64)*5)*.65;r=lerp(r,152,k);g=lerp(g,146,k);bb=lerp(bb,86,k)}
  const ms=f(u*20+1,v*20+9,20,3);if(ms>.68&&w<.45){r*=.68;g*=.76;bb*=.58}
  O[0]=r;O[1]=g;O[2]=bb;O[4]=w*.8+lap*.25+(m-.5)*.1})}
function texMetal(){const s=QL.tex,f=VN(31);return gen(s,s,(u,v,O)=>{const p=(u*5)%1,rib=p<.2?1:p<.3?1-(p-.2)/.1:p<.9?0:(p-.9)/.1;const n=f(u*10,v*10,10,4),m=f(u*50,v*50,50,2);
  const b=.8+(n-.5)*.14+(m-.5)*.05-rib*.05;let r=b*232,g=b*232,bb=b*228;const rs=f(u*6+4,v*6+2,6,5);
  if(rs>.62){const k=Math.min(1,(rs-.62)*4);r=lerp(r,128,k);g=lerp(g,78,k);bb=lerp(bb,46,k)}O[0]=r;O[1]=g;O[2]=bb;O[4]=rib*.9+(m-.5)*.05})}
function texWood(){const s=QL.tex,f=VN(41);return gen(s,s,(u,v,O)=>{const bw=u*6,bi=Math.floor(bw)%6,fx=bw-Math.floor(bw),id=hsh(bi,7);
  const gr=f(u*36+id*40,v*2+id*13,36,3),fine=f(u*96,v*6,96,2),gap=fx<.04||fx>.97;let b=.6+id*.2+(gr-.5)*.28+(fine-.5)*.12;if(gap)b*=.35;
  if(f(u*12+id*3,v*3,12,2)>.84)b*=.86;O[0]=b*186;O[1]=b*170;O[2]=b*150;O[4]=gap?0:.6+(gr-.5)*.4})}
function texBark(){const s=Math.min(512,QL.tex),f=VN(51);return gen(s,s,(u,v,O)=>{const r=Math.abs(f(u*10,v*2,10,4)-.5)*2,n=f(u*40,v*10,40,2),b=.32+r*.38+(n-.5)*.12;O[0]=b*150;O[1]=b*140;O[2]=b*128;O[4]=r})}
function texConcrete(){const s=QL.tex,f=VN(61);return gen(s,s,(u,v,O)=>{const n=f(u*6,v*6,6,5),m=f(u*64,v*64,64,2);let b=.68+(n-.5)*.2+(m-.5)*.1;const pore=m<.24?1:0;if(pore)b*=.78;
  b-=Math.max(0,f(u*8+3,v*2,8,3)-.6)*.4;O[0]=b*206;O[1]=b*203;O[2]=b*196;O[4]=.5+(m-.5)*.4-pore*.3})}
function texSoil(){const s=QL.tex,f=VN(71);return gen(s,s,(u,v,O)=>{const n=f(u*8,v*8,8,5),m=f(u*48,v*48,48,3),cl=Math.max(0,m-.45)*2;const b=.55+(n-.5)*.35+cl*.25;
  let r=b*126,g=b*100,bb=b*76;if(hsh(Math.floor(u*s/3),Math.floor(v*s/3))>.985){r=150;g=145;bb=135}
  if(f(u*12+5,v*12+5,12,3)>.74){r=lerp(r,96,.32);g=lerp(g,98,.32);bb=lerp(bb,66,.32)}O[0]=r;O[1]=g;O[2]=bb;O[4]=n*.4+cl*.6})}
function texAsphalt(){const s=QL.tex,f=VN(77);return gen(s,s,(u,v,O)=>{const n=f(u*8,v*8,8,4),m=hsh(Math.floor(u*s),Math.floor(v*s));let b=.34+(n-.5)*.12+(m>.9?.14:0)-(m<.06?.06:0);
  const cr=Math.abs(f(u*3+2,v*3+7,3,5)-.5),k=(cr<.006&&f(u*6+1,v*6+4,6,2)>.55)?1:0;if(k)b*=.6;O[0]=b*190;O[1]=b*188;O[2]=b*182;O[4]=.5+(m-.5)*.3-k*.4})}
function texDetail(){const s=Math.max(256,Math.min(512,QL.tex)),f=VN(81);const g=gen(s,s,(u,v,O)=>{const n=f(u*16,v*16,16,4),m=f(u*96,v*96,96,2),hh=hsh(Math.floor(u*s),Math.floor(v*s));
  const b=.5+(n-.5)*.34+(m-.5)*.24+(hh-.5)*.08;O[0]=b*255;O[1]=b*258>255?255:b*258;O[2]=b*240});return mkTex(g.c,{srgb:false})}
function texRoad(){const w=Math.max(128,QL.tex/2),h=QL.tex*2,f=VN(91);return gen(w,h,(u,v,O)=>{const x=(u-.5)*7,ax=Math.abs(x),edge=3.05+(f(u*4,v*16,4,3)-.5)*1.3;
  if(ax>edge){O[0]=O[1]=O[2]=0;O[3]=0;O[4]=.5;return}
  const n=f(u*8,v*32,8,4),m=f(u*32,v*128,32,2),rut=Math.abs(ax-.82),inR=rut<.25,rd=inR?Math.cos(rut/.25*Math.PI/2):0;
  const br=.6+(n-.5)*.26+(m-.5)*.12;let r=br*150,g=br*127,b=br*100;
  if(inR){r*=1-rd*.4;g*=1-rd*.42;b*=1-rd*.44;if(rut<.16&&Math.sin(v*h*.9)>.4){r*=.9;g*=.9;b*=.9}}
  const gv=hsh(Math.floor(u*w),Math.floor(v*h));if(gv>.972&&!inR){const k=.6+gv*.5;r=168*k;g=160*k;b=146*k}
  const gN=f(u*16+3,v*64+3,16,3),ga=(ax<.36?.72:0)+(ax>edge-.9?(ax-(edge-.9))/.9:0);
  if(gN<ga){const gg=f(u*64,v*256,64,2);r=lerp(78,124,gg);g=lerp(86,114,gg);b=lerp(54,70,gg)}
  O[0]=r;O[1]=g;O[2]=b;O[4]=.62-rd*.5+(m-.5)*.08+(ax<.36?.06:0)})}
function cardTex(w,h,draw){const c=cnv(w,h),x=c.getContext('2d');draw(x,w,h);return mkTex(c,{clamp:true})}
function texGrass(){return cardTex(256,256,(x,s)=>{const R=rngS(5),cols=['#69753f','#7b7e47','#988e57','#58683a','#a69861','#847848','#5d6f39'];
  for(let i=0;i<75;i++){const bx=6+R()*(s-12),h=s*(.32+R()*.64),w=2+R()*4,bend=(R()-.5)*s*.28;x.fillStyle=cols[R()*cols.length|0];
    x.beginPath();x.moveTo(bx-w,s);x.quadraticCurveTo(bx+bend*.3,s-h*.6,bx+bend,s-h);x.quadraticCurveTo(bx+bend*.3+w*.3,s-h*.6,bx+w,s);x.fill()}})}
function texFlower(){return cardTex(256,256,(x,s)=>{const R=rngS(8);for(let i=0;i<26;i++){const bx=20+R()*(s-40),h=s*(.35+R()*.5);x.strokeStyle='#4d5e30';x.lineWidth=3;x.beginPath();x.moveTo(bx,s);x.lineTo(bx+(R()-.5)*20,s-h);x.stroke();
  for(let k=0;k<3;k++){x.fillStyle='#5a6b38';x.beginPath();x.ellipse(bx+(R()-.5)*16,s-h*R(),9,4,R()*3,0,7);x.fill()}}
  for(let i=0;i<20;i++){const fx=20+R()*(s-40),fy=s*(.1+R()*.5),r=8+R()*7,c=R()<.6?['#e8c33a','#d9a92a']:['#efeae0','#d8d0c4'];x.fillStyle=c[1];x.beginPath();x.arc(fx,fy,r,0,7);x.fill();
    for(let p=0;p<14;p++){const a=p/14*6.283;x.fillStyle=c[0];x.beginPath();x.ellipse(fx+Math.cos(a)*r*.6,fy+Math.sin(a)*r*.6,r*.45,r*.18,a,0,7);x.fill()}}})}
function texLeaves(pal,kind,seed){return cardTex(256,256,(x,s)=>{const R=rngS(seed),n=kind==='acacia'?7:15;
  for(let i=0;i<n;i++){const cx=s*(.16+R()*.68),cy=s*(.16+R()*.68),a=R()*6.28;x.save();x.translate(cx,cy);x.rotate(a);
    if(kind==='acacia'){x.strokeStyle='#6a5a2a';x.lineWidth=2;x.beginPath();x.moveTo(-50,0);x.lineTo(50,0);x.stroke();for(let k=-4;k<=4;k++)for(const sd of[-1,1]){x.fillStyle=pal[R()*pal.length|0];x.beginPath();x.ellipse(k*11,sd*8,7,4.4,sd*.4,0,7);x.fill()}}
    else{const L=kind==='walnut'?48:30,W=L*.42;x.fillStyle=pal[R()*pal.length|0];x.beginPath();x.moveTo(-L/2,0);x.quadraticCurveTo(0,-W,L/2,0);x.quadraticCurveTo(0,W,-L/2,0);x.fill();
      x.strokeStyle='rgba(60,40,20,.45)';x.lineWidth=1.2;x.beginPath();x.moveTo(-L/2-7,0);x.lineTo(L/2,0);x.stroke()}
    x.restore()}
  if(kind==='apple')for(let i=0;i<3;i++){x.fillStyle='#9a3a28';x.beginPath();x.arc(s*(.2+R()*.6),s*(.2+R()*.6),7,0,7);x.fill()}})}
function texCorn(){return cardTex(128,512,(x,w,h)=>{x.strokeStyle='#a89468';x.lineWidth=7;x.beginPath();x.moveTo(w/2,h);x.lineTo(w/2+4,h*.08);x.stroke();const R=rngS(4);
  for(let i=0;i<7;i++){const y=h*(.2+i*.1),sd=i%2?1:-1;x.strokeStyle=['#b8a374','#9c8a5c','#c4b088'][i%3];x.lineWidth=5;x.beginPath();x.moveTo(w/2,y);x.quadraticCurveTo(w/2+sd*44,y-20,w/2+sd*(50+R()*10),y+60+R()*40);x.stroke()}})}
function texLace(){return cardTex(256,256,(x,s)=>{x.strokeStyle='rgba(250,248,240,.95)';x.lineWidth=1.5;for(let i=0;i<=s;i+=16){x.beginPath();x.moveTo(i,0);x.lineTo(i,s);x.stroke();x.beginPath();x.moveTo(0,i);x.lineTo(s,i);x.stroke()}
  for(let i=8;i<s;i+=32)for(let j=8;j<s;j+=32){x.lineWidth=2.5;x.beginPath();x.arc(i,j,7,0,7);x.stroke();x.beginPath();x.arc(i,j,2.5,0,7);x.stroke()}
  x.fillStyle='rgba(250,248,240,.9)';for(let i=0;i<s;i+=10){x.beginPath();x.arc(i,s-4,4,0,Math.PI);x.fill()}})}
function texChain(){return cardTex(128,128,(x,s)=>{x.strokeStyle='#c6caca';x.lineWidth=3;for(let i=-s;i<=s*2;i+=32){x.beginPath();x.moveTo(i,0);x.lineTo(i+s,s);x.stroke();x.beginPath();x.moveTo(i,s);x.lineTo(i+s,0);x.stroke()}})}
function textTex(w,h,fn){const c=cnv(w,h),x=c.getContext('2d');fn(x,w,h);return mkTex(c,{clamp:true})}
function texCamo(sk){if(sk._t)return sk._t;const s=256,f=VN(sk.n.length*7+3),base=hex2rgb(sk.base),cs=sk.c.map(hex2rgb);
  const g=gen(s,s,(u,v,O)=>{const cx=Math.floor(u*64)/64,cy=Math.floor(v*64)/64,a=f(cx*6,cy*6,6,3),b=f(cx*6+17,cy*6+5,6,3),c=f(cx*12+3,cy*12+9,12,2);
    let col=base;if(a>.62)col=cs[0];else if(b>.64)col=cs[1];else if(c>.7)col=cs[2];else if(a<.3)col=cs[3]||base;const k=.95+hsh(Math.floor(u*256),Math.floor(v*256))*.08;O[0]=col[0]*k;O[1]=col[1]*k;O[2]=col[2]*k});
  const t=mkTex(g.c);t.repeat.set(3,3);sk._t=t;return t}
function texPaint(hex,camo){const c=cnv(256),x=c.getContext('2d'),R=rngS(9);x.fillStyle=hex;x.fillRect(0,0,256,256);
  if(camo){const cols=['#3e4628','#6d6f48','#2f3520','#7e7a58'];for(let i=0;i<260;i++){x.fillStyle=cols[R()*4|0];x.fillRect((R()*64|0)*4,(R()*64|0)*4,4*(1+(R()*3|0)),4*(1+(R()*2|0)))}}
  const g=x.createLinearGradient(0,256,0,0);g.addColorStop(0,'rgba(112,92,66,.9)');g.addColorStop(.26,'rgba(132,112,84,.42)');g.addColorStop(.5,'rgba(150,130,100,.1)');g.addColorStop(1,'rgba(150,130,100,0)');x.fillStyle=g;x.fillRect(0,0,256,256);
  for(let i=0;i<500;i++){const yy=256-Math.pow(R(),2)*130;x.fillStyle=`rgba(${88+R()*40|0},${70+R()*30|0},${48+R()*22|0},${.15+R()*.5})`;x.beginPath();x.arc(R()*256,yy,.8+R()*3,0,7);x.fill()}
  const t=mkTex(c,{clamp:true});t.repeat.set(1/6,1/2.2);t.offset.set(.5,0);return t}
function texMosaic(){return textTex(512,256,(x,w,h)=>{const R=rngS(17),cell=8;x.fillStyle='#8f8b82';x.fillRect(0,0,w,h);
  const col=(px,py)=>{const dx=px-120,dy=py-90;if(dx*dx+dy*dy<52*52)return['#d9a03a','#e2b246','#c98a2c'];if(dx*dx+dy*dy<70*70&&((Math.atan2(dy,dx)*8/Math.PI|0)%2===0))return['#d6b45a','#c9a24c'];
    for(const[sx,sy]of[[330,150],[410,120],[470,170]]){const d=Math.hypot(px-sx,py-sy);if(d<16)return['#4a3622','#3b2b1c'];if(d<34)return['#e0b232','#d29d24'];if(py>sy&&Math.abs(px-sx)<4)return['#5c6a34']}
    if(py>190)return(Math.floor(px/24)%2)?['#a99a4a','#b8a855']:['#7d8a44','#6f7d3c'];if(py>150)return['#c9b46a','#bda85c','#d2bf78'];return py<60?['#3f6fa6','#4a7ab0','#5a86b8']:['#7aa0c8','#86aad0','#e8e2d0']};
  for(let j=0;j<h;j+=cell)for(let i=0;i<w;i+=cell){const p=col(i+4,j+4);x.fillStyle=p[R()*p.length|0];x.fillRect(i+1,j+1,cell-1.5,cell-1.5)}})}

/* ---- geometry helpers ---- */
function MX(x,y,z,ry,rx,rz,s){_e.set(rx||0,ry||0,rz||0,'YXZ');_q2.setFromEuler(_e);const sc=s==null?1:s;return new T.Matrix4().compose(new T.Vector3(x,y,z),_q2,new T.Vector3(sc,sc,sc))}
function boxG(w,h,d){const g=new T.BoxGeometry(w,h,d),uv=g.attributes.uv,dm=[[d,h],[d,h],[w,d],[w,d],[w,h],[w,h]];for(let f=0;f<6;f++)for(let k=0;k<4;k++){const i=f*4+k;uv.setXY(i,uv.getX(i)*dm[f][0],uv.getY(i)*dm[f][1])}return g}
function planeG(w,h){const g=new T.PlaneGeometry(w,h),uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*w,uv.getY(i)*h);return g}
function cylG(rt,rb,h,seg,open){const g=new T.CylinderGeometry(rt,rb,h,seg||8,1,!!open),uv=g.attributes.uv,c=Math.PI*(rt+rb);for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*c,uv.getY(i)*h);return g}
const V=(x,y,z)=>new T.Vector3(x,y,z);
function polyG(pts){const p0=pts[0],ax=new T.Vector3().subVectors(pts[1],p0).normalize(),n=new T.Vector3().subVectors(pts[1],p0).cross(new T.Vector3().subVectors(pts[2],p0)).normalize(),ay=new T.Vector3().crossVectors(n,ax),pos=[],nor=[],uv=[],d=new T.Vector3();
  for(let i=1;i<pts.length-1;i++)for(const p of[pts[0],pts[i],pts[i+1]]){pos.push(p.x,p.y,p.z);nor.push(n.x,n.y,n.z);d.subVectors(p,p0);uv.push(d.dot(ax),d.dot(ay))}
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('normal',new T.Float32BufferAttribute(nor,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));return g}
function beamG(a,b,r,seg){const d=new T.Vector3().subVectors(b,a),L=d.length(),g=cylG(r,r,L,seg||6);g.translate(0,L/2,0);_q2.setFromUnitVectors(UP,d.normalize());geoRot(g,_q2);g.translate(a.x,a.y,a.z);return g}
function plankG(a,b,w,t){const d=new T.Vector3().subVectors(b,a),L=d.length(),g=boxG(L,t,w);g.translate(L/2,0,0);_q2.setFromUnitVectors(new T.Vector3(1,0,0),d.normalize());geoRot(g,_q2);g.translate(a.x,a.y,a.z);return g}
const RBC={};
function rbox(w,h,d,r){const k=[w,h,d,r].map(v=>v.toFixed(3)).join();if(RBC[k])return RBC[k].clone();r=Math.min(r,w/2-.002,h/2-.002,d/2-.002);const a=w/2-r,b=h/2-r,s=new T.Shape();s.moveTo(-a,-b);s.lineTo(a,-b);s.lineTo(a,b);s.lineTo(-a,b);s.lineTo(-a,-b);
  const g=new T.ExtrudeGeometry(s,{depth:Math.max(.002,d-2*r),bevelEnabled:true,bevelThickness:r,bevelSize:r,bevelSegments:2,curveSegments:2});g.translate(0,0,-Math.max(.002,d-2*r)/2);RBC[k]=g;return g.clone()}
function blobG(cx,cy,z,rx,ry,R){const pts=[];for(let i=0;i<10;i++){const a=-i/10*Math.PI*2,k=.8+R()*.35;pts.push(V(cx+Math.cos(a)*rx*k,cy+Math.sin(a)*ry*k,z))}return polyG(pts.reverse())}
function mergeGeos(list){const arr=list.map(g=>g.index?g.toNonIndexed():g);let n=0;arr.forEach(g=>n+=g.attributes.position.count);
  const pos=new Float32Array(n*3),nor=new Float32Array(n*3),uv=new Float32Array(n*2);let o=0;
  for(const g of arr){const c=g.attributes.position.count;pos.set(g.attributes.position.array,o*3);if(g.attributes.normal)nor.set(g.attributes.normal.array,o*3);if(g.attributes.uv)uv.set(g.attributes.uv.array,o*2);o+=c}
  const m=new T.BufferGeometry();m.setAttribute('position',new T.BufferAttribute(pos,3));m.setAttribute('normal',new T.BufferAttribute(nor,3));m.setAttribute('uv',new T.BufferAttribute(uv,2));m.computeBoundingSphere();return m}
const DEPTHC=new Map();
function depthMat(m){if(DEPTHC.has(m))return DEPTHC.get(m);const d=new T.MeshDepthMaterial({depthPacking:T.RGBADepthPacking,map:m.map,alphaTest:m.alphaTest});DEPTHC.set(m,d);return d}
function Bld(){this.m=new Map()}
Bld.prototype.add=function(k,g,mx){if(!MATS[k])throw new Error('Немає матеріалу '+k);if(mx)g.applyMatrix4(mx);let l=this.m.get(k);if(!l){l=[];this.m.set(k,l)}l.push(g)};
Bld.prototype.flush=function(par){for(const[k,l]of this.m){const mat=MATS[k],g=mergeGeos(l);l.forEach(x=>x.dispose());const me=new T.Mesh(g,mat);me.castShadow=!mat.userData.noCast;me.receiveShadow=true;
  if(mat.alphaTest)me.customDepthMaterial=depthMat(mat);par.add(me)}this.m.clear()};

/* ---- materials ---- */
let skyMesh=null;
async function initRealism(){
  await tick('Текстури: штукатурка й цегла…',4);
  const pl=texPlaster();TX.plaster=mkTex(pl.c);TX.plasterN=nrm(pl,2.5);
  const br=texBrick([148,70,50],[124,58,42],[176,168,156],12);TX.brick=mkTex(br.c,{rep:[1,1/.975]});TX.brickN=nrm(br,3);if(TX.brickN)TX.brickN.repeat.set(1,1/.975);
  const sb=texBrick([214,208,192],[194,188,174],[150,146,138],13);TX.sil=mkTex(sb.c,{rep:[1,1/.975]});TX.silN=nrm(sb,3);if(TX.silN)TX.silN.repeat.set(1,1/.975);
  await tick('Текстури: шифер, профнастил, дерево…',7);
  const sl=texSlate();TX.slate=mkTex(sl.c,{rep:[1/1.15,1/1.2]});TX.slateN=nrm(sl,4);if(TX.slateN)TX.slateN.repeat.set(1/1.15,1/1.2);
  const mt=texMetal();TX.metal=mkTex(mt.c);TX.metalN=nrm(mt,4);
  const wd=texWood();TX.wood=mkTex(wd.c);TX.woodN=nrm(wd,2.5);
  await tick('Текстури: кора, бетон, ґрунт, дорога…',10);
  const bk=texBark();TX.bark=mkTex(bk.c);TX.barkN=nrm(bk,4);
  const co=texConcrete();TX.concrete=mkTex(co.c);TX.concreteN=nrm(co,2);
  const so=texSoil();TX.soil=mkTex(so.c,{rep:[1/1.5,1/1.5]});TX.soilN=nrm(so,3);if(TX.soilN)TX.soilN.repeat.set(1/1.5,1/1.5);
  const as=texAsphalt();TX.asphalt=mkTex(as.c,{rep:[1/2,1/2]});
  const rd=texRoad();TX.road=mkTex(rd.c);TX.roadN=nrm(rd,5);TX.roadR=roughFrom(rd,.3,1.05);
  TX.detail=texDetail();
  await tick('Трава, листя, дрібниці…',12);
  TX.grass=texGrass();TX.flower=texFlower();TX.corn=texCorn();TX.lace=texLace();TX.chain=texChain();TX.chain.wrapS=TX.chain.wrapT=T.RepeatWrapping;TX.chain.repeat.set(2,2);
  TX.lWal=texLeaves(['#b08a3a','#8f6c2c','#c7a14a','#6e5c2c','#7c7a3a','#a37a30'],'walnut',3);
  TX.lApp=texLeaves(['#a39d3c','#bd8e2c','#7a873c','#a8652c','#8b8a40'],'apple',4);
  TX.lAca=texLeaves(['#b6ad48','#98a03e','#c4a640','#a9a650'],'acacia',5);
  TX.mosaic=texMosaic();
  TX.shop=textTex(512,96,(x,w,h)=>{x.fillStyle='#2e5c9a';x.fillRect(0,0,w,h);x.strokeStyle='#e8e4d8';x.lineWidth=5;x.strokeRect(6,6,w-12,h-12);x.fillStyle='#f2efe6';x.font='bold 62px Arial,sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText('ПРОДУКТИ',w/2,h/2+3)});
  TX.ads=textTex(256,128,(x,w,h)=>{x.fillStyle='#ece6d4';x.fillRect(0,0,w,h);x.fillStyle='#e6dfc8';x.fillRect(132,0,124,128);x.fillStyle='#2a2a2a';x.font='bold 20px Arial';x.fillText('ХЛІБ',14,34);x.font='15px Arial';x.fillText('свіжий щодня',14,58);x.fillText('з 8:00',14,82);
    x.font='bold 17px Arial';x.fillText('Продам',142,30);x.font='13px Arial';x.fillText('дрова, сіно',142,54);x.fillText('тел. 0XX…',142,78);for(let i=0;i<6;i++){x.save();x.translate(146+i*18,100);x.rotate(Math.PI/2);x.fillText('0XX',0,0);x.restore()}});
  TX.bus=textTex(128,128,(x,w,h)=>{x.fillStyle='#2457a8';x.fillRect(0,0,w,h);x.fillStyle='#fff';x.fillRect(22,34,84,50);x.fillStyle='#2457a8';for(let i=0;i<3;i++)x.fillRect(30+i*25,42,18,16);x.fillStyle='#fff';x.beginPath();x.arc(40,88,9,0,7);x.arc(88,88,9,0,7);x.fill()});
  TX.street=textTex(512,128,(x,w,h)=>{x.fillStyle='#2457a8';x.fillRect(0,0,w,h);x.strokeStyle='#fff';x.lineWidth=6;x.strokeRect(8,8,w-16,h-16);x.fillStyle='#fff';x.font='bold 56px Arial';x.textAlign='center';x.textBaseline='middle';x.fillText('вул. САДОВА',w/2,h/2+2)});
  const M=MATS,nm=(n,s)=>n?{normalMap:n,normalScale:new T.Vector2(s,s)}:{};
  M.plasterW=std({map:TX.plaster,color:'#f2efe7',roughness:.95,...nm(TX.plasterN,.7)});
  M.plasterBlue=std({map:TX.plaster,color:'#bfcfd9',roughness:.95,...nm(TX.plasterN,.7)});
  M.plasterY=std({map:TX.plaster,color:'#ddc994',roughness:.95,...nm(TX.plasterN,.7)});
  M.plasterPink=std({map:TX.plaster,color:'#e3cfc0',roughness:.95,...nm(TX.plasterN,.7)});
  M.plinthBlue=std({map:TX.plaster,color:'#4b6380',roughness:.85,...nm(TX.plasterN,.7)});
  M.plinthGrey=std({map:TX.concrete,color:'#a9a59c',roughness:.95,...nm(TX.concreteN,1)});
  M.brickRed=std({map:TX.brick,roughness:.88,...nm(TX.brickN,1)});
  M.brickSil=std({map:TX.sil,roughness:.88,...nm(TX.silN,1)});
  M.saman=std({map:TX.soil,color:'#d8bf98',roughness:1,...nm(TX.soilN,.8)});
  M.slate=std({map:TX.slate,roughness:.86,...nm(TX.slateN,1.2)});
  M.slateDark=std({map:TX.slate,color:'#8f8f8a',roughness:.9,...nm(TX.slateN,1.2)});
  M.metalGreen=std({map:TX.metal,color:'#5b7350',roughness:.5,metalness:.45,...nm(TX.metalN,1.4)});
  M.metalBrown=std({map:TX.metal,color:'#6e4d3c',roughness:.5,metalness:.45,...nm(TX.metalN,1.4)});
  M.metalBlue=std({map:TX.metal,color:'#506d8a',roughness:.5,metalness:.45,...nm(TX.metalN,1.4)});
  M.galv=std({map:TX.metal,color:'#c2c6c6',roughness:.42,metalness:.8});
  M.wood=std({map:TX.wood,roughness:.9,...nm(TX.woodN,1)});
  M.woodBlue=std({map:TX.wood,color:'#7395b5',roughness:.8,...nm(TX.woodN,1)});
  M.woodGreen=std({map:TX.wood,color:'#76906a',roughness:.8,...nm(TX.woodN,1)});
  M.woodWhite=std({map:TX.wood,color:'#e9e7de',roughness:.75,...nm(TX.woodN,.8)});
  M.woodBrown=std({map:TX.wood,color:'#8a6a4c',roughness:.85,...nm(TX.woodN,1)});
  M.bark=std({map:TX.bark,roughness:.95,...nm(TX.barkN,1.4)});
  M.concrete=std({map:TX.concrete,roughness:.95,...nm(TX.concreteN,1)});
  M.soil=std({map:TX.soil,roughness:1,...nm(TX.soilN,1.2)});
  M.asphalt=std({map:TX.asphalt,roughness:.9,polygonOffset:true,polygonOffsetFactor:-1});
  M.road=std({map:TX.road,roughnessMap:TX.roadR,roughness:1,alphaTest:.5,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2,...nm(TX.roadN,1.6)});M.road.userData.noCast=true;
  M.water=std({color:'#2a302b',roughness:.03,metalness:.1,transparent:true,opacity:.9,envMapIntensity:1.8,polygonOffset:true,polygonOffsetFactor:-4,polygonOffsetUnits:-4});M.water.userData.noCast=true;
  M.glass=std({color:'#192026',roughness:.05,metalness:.2,transparent:true,opacity:.62,envMapIntensity:1.6});M.glass.userData.noCast=true;
  M.glassLit=std({color:'#192026',emissive:'#000000',roughness:.05,metalness:.2,transparent:true,opacity:.62,envMapIntensity:1.6});M.glassLit.userData.noCast=true;
  M.interior=std({color:'#1b1915',roughness:1});M.interiorLit=std({color:'#1b1915',emissive:'#000000',roughness:1});
  M.curtain=std({map:TX.lace,color:'#f2efe6',alphaTest:.35,side:T.DoubleSide,roughness:1});M.curtain.userData.noCast=true;
  M.pvc=std({color:'#e9e8e2',roughness:.35});
  M.dark=std({color:'#2c2d2d',roughness:.55,metalness:.55});
  M.gas=std({color:'#d1a82c',roughness:.45,metalness:.25});
  M.rubber=std({color:'#1a1a1a',roughness:.92});
  M.chain=std({map:TX.chain,color:'#b8bcbc',alphaTest:.5,side:T.DoubleSide,metalness:.7,roughness:.5});
  M.grassC=windify(std({map:TX.grass,alphaTest:.45,side:T.DoubleSide,roughness:1}),.12);M.grassC.userData.noCast=true;
  M.flower=windify(std({map:TX.flower,alphaTest:.45,side:T.DoubleSide,roughness:1}),.08);M.flower.userData.noCast=true;
  M.corn=windify(std({map:TX.corn,alphaTest:.4,side:T.DoubleSide,roughness:1}),.035);
  M.lWal=windify(std({map:TX.lWal,alphaTest:.45,side:T.DoubleSide,roughness:.85}),.014);
  M.lApp=windify(std({map:TX.lApp,alphaTest:.45,side:T.DoubleSide,roughness:.85}),.02);
  M.lAca=windify(std({map:TX.lAca,alphaTest:.45,side:T.DoubleSide,roughness:.85}),.012);
  M.mosaic=std({map:TX.mosaic,roughness:.55});
  M.signShop=std({map:TX.shop,emissive:'#000000',roughness:.5});M.paper=std({map:TX.ads,roughness:1});M.busSign=std({map:TX.bus,roughness:.5,side:T.DoubleSide});M.street=std({map:TX.street,roughness:.5,side:T.DoubleSide});
  M.insul=std({color:'#6f9886',roughness:.12,metalness:.1});
  M.lamp=std({color:'#d8d6c8',emissive:'#000000',roughness:.3});
  M.sunHead=std({color:'#3a2c1e',roughness:1});M.stalk=std({color:'#8a7a56',roughness:1});
  M.dish=std({color:'#d6d6d2',roughness:.4,metalness:.3,side:T.DoubleSide});
  ['#8a3b30','#e8e4da','#3f5f86','#c9a640','#6b6b6b'].forEach((c,i)=>{M['cloth'+i]=std({color:c,side:T.DoubleSide,roughness:1})});
  M.plaque=std({color:'#2457a8',roughness:.5});
  // sky dome
  const sm=new T.ShaderMaterial({side:T.BackSide,depthWrite:false,fog:false,uniforms:{uTop:{value:new T.Color()},uHor:{value:new T.Color()},uSun:{value:new T.Vector3(0,1,0)},uSunCol:{value:new T.Color(1,1,1)},uNight:{value:0},uTime:{value:0},uCloud:{value:.6}},
    vertexShader:'varying vec3 vDir;void main(){vDir=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
    fragmentShader:`uniform vec3 uTop,uHor,uSun,uSunCol;uniform float uNight,uTime,uCloud;varying vec3 vDir;
float hs(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float vn(vec2 p){vec2 i=floor(p),f=fract(p);vec2 u=f*f*(3.0-2.0*f);return mix(mix(hs(i),hs(i+vec2(1.,0.)),u.x),mix(hs(i+vec2(0.,1.)),hs(i+vec2(1.,1.)),u.x),u.y);}
float fbm(vec2 p){float v=0.0,a=.5;for(int i=0;i<5;i++){v+=a*vn(p);p=p*2.03+vec2(1.7,9.2);a*=.5;}return v;}
void main(){vec3 d=normalize(vDir);float h=max(d.y,0.0);vec3 col=mix(uHor,uTop,pow(h,.5));float sd=max(dot(d,normalize(uSun)),0.0);
 col+=uSunCol*(pow(sd,900.0)*6.0+pow(sd,14.0)*.22);
 if(d.y>0.0){vec2 cp=d.xz/(d.y+.15)*1.3+vec2(uTime*.006,uTime*.002);float c=fbm(cp);c=smoothstep(.62-uCloud*.32,.95,c)*smoothstep(0.0,.2,d.y);
  vec3 cc=mix(uHor,vec3(.92),.5)*(1.0-uNight*.9);cc*=.75+.25*fbm(cp*2.0+3.0);cc+=uSunCol*pow(sd,5.0)*.35;col=mix(col,cc,c*.88);}
 else col=uHor*.92;
 gl_FragColor=vec4(col,1.0);
 #include <tonemapping_fragment>
 #include <encodings_fragment>
}`});
  skyMesh=new T.Mesh(new T.SphereGeometry(600,32,16),sm);skyMesh.renderOrder=-1;skyMesh.frustumCulled=false;scene.add(skyMesh);
  clouds.visible=false;sunDisc.visible=false;
  // environment lighting from the sky (PMREM)
  try{const es=new T.Scene();const m2=sm.clone();updSkyUniforms(m2.uniforms,.38);es.add(new T.Mesh(new T.SphereGeometry(10,24,12),m2));const pm=new T.PMREMGenerator(renderer);scene.environment=pm.fromScene(es,.03).texture;pm.dispose()}catch(e){console.warn(e)}
}
const SKYC={dT:new T.Color('#7a95ae'),dH:new T.Color('#c3cbcf'),uT:new T.Color('#55658a'),uH:new T.Color('#d39a72'),nT:new T.Color('#04070e'),nH:new T.Color('#121923')};
const _ct=new T.Color(),_ch=new T.Color(),_white=new T.Color(1,1,1);
function skyCols(night,dusk){_ct.copy(SKYC.dT).lerp(SKYC.nT,night).lerp(SKYC.uT,dusk*.6);_ch.copy(SKYC.dH).lerp(SKYC.nH,night).lerp(SKYC.uH,dusk*.65)}
function updSkyUniforms(u,tod){const a=(tod-.25)*Math.PI*2,sy=Math.sin(a),sx=Math.cos(a),night=clamp((.08-sy)/.25,0,1),dusk=clamp(1-Math.abs(sy-.03)/.22,0,1),dayF=clamp(sy*2.5+.05,0,1);
  skyCols(night,dusk);u.uTop.value.copy(_ct).convertSRGBToLinear();u.uHor.value.copy(_ch).convertSRGBToLinear();u.uSun.value.set(sx*.75,sy,.45).normalize();u.uNight.value=night;
  u.uSunCol.value.setRGB(1,.8+.2*dayF,.6+.4*dayF).multiplyScalar(clamp(sy*4+.3,0,1));return{sy,night,dayF}}
function updSky(){if(!skyMesh)return;const u=skyMesh.material.uniforms;const r=updSkyUniforms(u,S.tod);u.uTime.value=gameT;u.uCloud.value=.55+.25*Math.sin(gameT*.01);
  skyMesh.position.copy(camera.position);scene.fog.color.copy(u.uHor.value);
  const sy=r.sy,dayF=r.dayF,L=r.night;
  sun.intensity=dayF*2.1;sun.color.setRGB(1,.8+.2*clamp(sy*3,0,1),.62+.38*clamp(sy*3,0,1));
  hemi.intensity=.1+.42*clamp(sy+.25,0,1);hemi.color.copy(u.uTop.value).lerp(_white,.4);hemi.groundColor.setRGB(.2,.17,.12);
  const ei=.07+.7*dayF;for(const m of STD)m.envMapIntensity=m.userData.env*ei;
  MATS.glassLit.emissive.setRGB(L*1.1,L*.72,L*.34);MATS.interiorLit.emissive.setRGB(L*.85,L*.5,L*.22);MATS.lamp.emissive.setRGB(L*1.6,L*1.35,L*.9);MATS.signShop.emissive.setRGB(L*.2,L*.2,L*.26);if(MATS.facade)MATS.facade.emissive.setRGB(L*.95,L*.9,L*.85);
  renderer.toneMappingExposure=.95+L*.3}
function groundMat(map){map.encoding=T.sRGBEncoding;const m=std({map,roughness:.97,metalness:0,envMapIntensity:.35});
  m.onBeforeCompile=sh=>{sh.uniforms.uDetail={value:TX.detail};sh.vertexShader='varying vec3 vWP;\n'+sh.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvWP=position;');
    sh.fragmentShader='uniform sampler2D uDetail;varying vec3 vWP;\n'+sh.fragmentShader.replace('#include <map_fragment>','#include <map_fragment>\nvec3 dtl=texture2D(uDetail,vWP.xz*.42).rgb*texture2D(uDetail,vWP.xz*.071+.37).rgb*4.0;diffuseColor.rgb*=clamp(dtl,0.0,2.0);')};
  m.customProgramCacheKey=()=>'ground-detail';return m}

/* ---- camera collision against tall colliders ---- */
function colAt(x,z,y){const i=Math.floor((x+HALF)/CC),j=Math.floor((z+HALF)/CC),L=CG.get(i*1000+j);if(!L)return false;
  for(const c of L)if(c.t==='b'&&!c.off&&c.h&&x>c.x0&&x<c.x1&&z>c.z0&&z<c.z1&&(y==null||y<c.h))return true;return false}

/* ---- trees ---- */
const TREES={};const TREEPL={walnut:[],apple:[],acacia:[]};
function makeTree(sp){const R=rngS(sp.seed),bark=[],leaf=[];
  function br(p,dir,len,r,lvl){const g=cylG(r*.68,r,len,lvl===0?8:5,true);g.translate(0,len/2,0);_q2.setFromUnitVectors(UP,dir);geoRot(g,_q2);g.translate(p.x,p.y,p.z);bark.push(g);
    const end=p.clone().addScaledVector(dir,len);
    if(lvl>=sp.levels){for(let k=0;k<sp.leafPer;k++){if(R()>sp.dens)continue;const s1=sp.leafSize*(.7+R()*.6);const c=new T.PlaneGeometry(s1,s1);_e.set(R()*6.3,R()*6.3,R()*6.3);geoRot(c,_q2.setFromEuler(_e));
      const o=new T.Vector3(R()-.5,R()-.5,R()-.5).normalize().multiplyScalar(R()*sp.leafR);c.translate(end.x+o.x,end.y+o.y*.7,end.z+o.z);leaf.push(c)}return}
    const n=lvl===0?sp.main:2+(R()*2|0);
    for(let i=0;i<n;i++){const t=lvl===0?(.55+R()*.4):(.35+R()*.6),s=p.clone().addScaledVector(dir,len*t);let ax=new T.Vector3(R()-.5,R()-.5,R()-.5).cross(dir);if(ax.lengthSq()<1e-4)ax.set(1,0,0);ax.normalize();
      const nd=dir.clone().applyAxisAngle(ax,sp.spread*(.6+R()*.6)).lerp(UP,sp.up).normalize();br(s,nd,len*(lvl===0?sp.l1:.62)*(.75+R()*.4),r*(lvl===0?.55:.6),lvl+1)}
    if(lvl===0&&sp.leader)br(end,dir.clone().lerp(UP,.6).normalize(),len*.55,r*.6,lvl+1)}
  br(new T.Vector3(),new T.Vector3((R()-.5)*.15,1,(R()-.5)*.15).normalize(),sp.trunk,sp.r,0);
  return{bark:mergeGeos(bark),leaf:mergeGeos(leaf)}}
function buildTrees(){
  TREES.walnut=makeTree({seed:3,trunk:3.1,r:.32,main:4,l1:.95,spread:.85,up:.12,levels:3,leafPer:12,dens:.62,leafR:1.2,leafSize:1.2,leader:true});
  TREES.apple=makeTree({seed:7,trunk:1.3,r:.13,main:4,l1:1.5,spread:1.0,up:.08,levels:3,leafPer:8,dens:.55,leafR:.7,leafSize:.8});
  TREES.acacia=makeTree({seed:11,trunk:4.3,r:.24,main:3,l1:.85,spread:.65,up:.25,levels:3,leafPer:8,dens:.5,leafR:1.3,leafSize:1.4,leader:true});
  const LM={walnut:'lWal',apple:'lApp',acacia:'lAca'};
  for(const k in TREEPL){const pl=TREEPL[k];if(!pl.length)continue;const tb=TREES[k];
    const mb=new T.InstancedMesh(tb.bark,MATS.bark,pl.length),ml=new T.InstancedMesh(tb.leaf,MATS[LM[k]],pl.length);
    pl.forEach((p,i)=>{_o.position.set(p.x,H(p.x,p.z)-.05,p.z);_o.rotation.set(0,p.ry,0);_o.scale.setScalar(p.s);_o.updateMatrix();mb.setMatrixAt(i,_o.matrix);ml.setMatrixAt(i,_o.matrix);addCol({t:'c',x:p.x,z:p.z,r:k==='apple'?.18:.32})});
    mb.castShadow=ml.castShadow=true;mb.receiveShadow=ml.receiveShadow=true;ml.customDepthMaterial=depthMat(MATS[LM[k]]);scene.add(mb);scene.add(ml)}}

/* ---- street layout: вулиця Садова ---- */
const SHOWX0=-121,SHOWX1=-31;
const inShow=(x,z)=>x>SHOWX0&&x<SHOWX1&&Math.abs(z-roadMain(x))<46;
const STREET=[
 {px:-108,sd:-1,slot:'house',W:9,D:7.2,wall:'plasterW',plinth:'plinthBlue',roof:'hip',roofM:'slate',frame:'woodBlue',nal:true,nalM:'woodWhite',shutters:'woodBlue',porch:'canopy',canopyM:'metalGreen',gas:true,antenna:true,fence:'picket',fenceM:'woodBlue',lit:true,num:'3',well:true,door:'woodBrown'},
 {px:-86,sd:-1,W:10,D:8.2,wall:'brickRed',plinth:'plinthGrey',roof:'gable',roofM:'slate',gableM:'woodBrown',frame:'pvc',porch:'veranda',gas:true,dish:true,fence:'profile',fenceM:'metalBrown',num:'5',kitchen:true,door:'metalBrown'},
 {px:-64,sd:-1,shop:true,num:'7'},
 {px:-42,sd:-1,W:8,D:6.5,wh:2.55,wall:'plasterY',plinth:'plinthGrey',roof:'gable',roofM:'slateDark',gableM:'plasterY',frame:'woodGreen',damage:true,porch:'canopy',canopyM:'metalBrown',fence:'picketOld',fenceM:'woodGreen',num:'9',door:'woodBrown',antenna:true},
 {px:-104,sd:1,W:10,D:8,wall:'brickSil',plinth:'plinthGrey',roof:'hip',roofM:'metalGreen',frame:'pvc',porch:'canopy',canopyM:'metalGreen',dish:true,gas:true,fence:'profile',fenceM:'metalGreen',num:'4',lit:true,door:'metalBrown'},
 {px:-80,sd:1,W:9,D:7.5,wall:'plasterBlue',plinth:'brickRed',roof:'gable',roofM:'slate',gableM:'woodWhite',frame:'woodWhite',nal:true,nalM:'woodWhite',shutters:'woodGreen',porch:'veranda',fence:'picket',fenceM:'woodGreen',num:'6',kitchen:true,door:'woodBrown',antenna:true},
 {px:-61,sd:1,busstop:true},
 {px:-44,sd:1,W:8.5,D:7,wall:'plasterPink',plinth:'plinthBlue',roof:'hip',roofM:'metalBrown',frame:'pvc',porch:'canopy',canopyM:'metalBrown',gas:true,fence:'picket',fenceM:'woodWhite',num:'8',lit:true,well:true,door:'woodBrown'},
];
const DROPS=[],WIRES=[],GRASSPL=[],FLOWERPL=[];
function plotFrame(sp){const px=sp.px,rz=roadMain(px),th=-Math.atan((roadMain(px+1)-roadMain(px-1))/2);
  const grp=new T.Group();grp.position.set(px,0,rz);grp.rotation.y=sp.sd<0?th:th+Math.PI;scene.add(grp);grp.updateMatrixWorld(true);
  const toW=(lx,lz,ly)=>{const v=new T.Vector3(lx,ly||0,lz).applyMatrix4(grp.matrixWorld);return v};
  const colBox=(x0,z0,x1,z1,h)=>{const ps=[toW(x0,z0),toW(x1,z0),toW(x0,z1),toW(x1,z1)];return addCol({t:'b',x0:Math.min(...ps.map(p=>p.x)),x1:Math.max(...ps.map(p=>p.x)),z0:Math.min(...ps.map(p=>p.z)),z1:Math.max(...ps.map(p=>p.z)),h:h||0})};
  const B={add:(k,g,mx)=>{if(mx)g.applyMatrix4(mx);g.applyMatrix4(grp.matrixWorld);GB.add(k,g)},flush:()=>{}};
  return{grp,toW,colBox,B}}
let GB=null;
function hipRoof(B,k,hx,hz,W,D,ov,ye,yr){const X=W/2+ov,Z=D/2+ov,Lr=Math.max(.3,W-D)/2,o=MX(hx,0,hz);
  B.add(k,polyG([V(-X,ye,Z),V(X,ye,Z),V(Lr,yr,0),V(-Lr,yr,0)]),o);B.add(k,polyG([V(X,ye,-Z),V(-X,ye,-Z),V(-Lr,yr,0),V(Lr,yr,0)]),o);
  B.add(k,polyG([V(X,ye,Z),V(X,ye,-Z),V(Lr,yr,0)]),o);B.add(k,polyG([V(-X,ye,-Z),V(-X,ye,Z),V(-Lr,yr,0)]),o);
  B.add('woodBrown',polyG([V(-X,ye-.02,Z),V(-X,ye-.02,-Z),V(X,ye-.02,-Z),V(X,ye-.02,Z)]),o);
  B.add('woodBrown',boxG(2*X,.2,.03),MX(hx,ye-.09,hz+Z+.015));B.add('woodBrown',boxG(2*X,.2,.03),MX(hx,ye-.09,hz-Z-.015));B.add('woodBrown',boxG(.03,.2,2*Z),MX(hx+X+.015,ye-.09,hz));B.add('woodBrown',boxG(.03,.2,2*Z),MX(hx-X-.015,ye-.09,hz));
  B.add(k,boxG(2*Lr+.1,.07,.24),MX(hx,yr+.015,hz));
  for(const[sx,sz]of[[1,1],[1,-1],[-1,1],[-1,-1]])B.add(k,beamG(V(hx+sx*X,ye,hz+sz*Z),V(hx+sx*Lr,yr+.02,hz),.055,5))}
function gableRoof(B,k,gk,hx,hz,W,D,ov,ox,top,ye,yr){const X=W/2+ox,Z=D/2+ov,o=MX(hx,0,hz);
  B.add(k,polyG([V(-X,ye,Z),V(X,ye,Z),V(X,yr,0),V(-X,yr,0)]),o);B.add(k,polyG([V(X,ye,-Z),V(-X,ye,-Z),V(-X,yr,0),V(X,yr,0)]),o);
  B.add(gk,polyG([V(W/2,top,D/2),V(W/2,top,-D/2),V(W/2,yr-.05,0)]),o);B.add(gk,polyG([V(-W/2,top,-D/2),V(-W/2,top,D/2),V(-W/2,yr-.05,0)]),o);
  B.add('woodBrown',polyG([V(-X,yr-.04,0),V(X,yr-.04,0),V(X,ye-.04,Z),V(-X,ye-.04,Z)]),o);B.add('woodBrown',polyG([V(X,yr-.04,0),V(-X,yr-.04,0),V(-X,ye-.04,-Z),V(X,ye-.04,-Z)]),o);
  B.add('woodBrown',boxG(2*X,.2,.03),MX(hx,ye-.09,hz+Z+.015));B.add('woodBrown',boxG(2*X,.2,.03),MX(hx,ye-.09,hz-Z-.015));
  for(const sx of[-1,1])for(const sz of[-1,1])B.add('woodBrown',plankG(V(hx+sx*(X+.02),ye-.02,hz+sz*(Z+.02)),V(hx+sx*(X+.02),yr+.02,hz),.22,.035));
  B.add(k,boxG(2*X+.06,.06,.32),MX(hx,yr+.015,hz))}
function addWin(B,base,w,h,o){const P=(g,k,x,y,z,ry,rx,rz)=>B.add(k,g,new T.Matrix4().multiplyMatrices(base,MX(x,y,z,ry,rx,rz)));
  P(planeG(w,h),o.lit?'interiorLit':'interior',0,0,.004);
  if(!o.boarded){P(planeG(w-.1,h*.72),'curtain',0,h*.1,.012);P(planeG(w-.06,h-.06),o.lit?'glassLit':'glass',0,0,.026)}
  const f=o.frame,t=.065;P(boxG(w,t,t),f,0,h/2-t/2,.033);P(boxG(w,t,t),f,0,-h/2+t/2,.033);P(boxG(t,h,t),f,-w/2+t/2,0,.033);P(boxG(t,h,t),f,w/2-t/2,0,.033);
  P(boxG(.05,h-.1,.05),f,-w*.12,0,.036);P(boxG(w*.6,.05,.05),f,w*.19,h*.22,.036);
  P(boxG(w+.14,.03,.17),'galv',0,-h/2-.035,.085,0,.14);
  if(o.nal){const m=o.nalM;P(boxG(.11,h+.24,.025),m,-w/2-.075,0,.02);P(boxG(.11,h+.24,.025),m,w/2+.075,0,.02);P(boxG(w+.36,.14,.03),m,0,h/2+.13,.022);
    P(GEO.prism.clone().scale(w+.3,.24,.03),m,0,h/2+.2,.022)}
  if(o.shutters)for(const sx of[-1,1]){P(boxG(w/2,h,.03),o.shutters,sx*(w*.75+.1),0,.03);const L=Math.hypot(w/2,h)*.85;P(boxG(.07,L,.02),o.shutters,sx*(w*.75+.1),0,.05,0,0,sx*Math.atan2(w/2,h))}
  if(o.boarded)for(let i=0;i<4;i++)P(boxG(w+.3,.15,.025),'woodBrown',0,-h/2+.22+i*(h-.4)/3,.07,0,0,i%2?.07:-.05)}
function house(B,sp,hx,hz,R){const W=sp.W,D=sp.D,wh=sp.wh||2.75,pl=.55,top=pl+wh,ov=.55,rise=sp.roof==='hip'?2.15:2.45,ye=top-ov*rise/(D/2),yr=top+rise;
  B.add(sp.plinth||'plinthGrey',boxG(W+.14,pl,D+.14),MX(hx,pl/2,hz));B.add(sp.wall,boxG(W,wh,D),MX(hx,pl+wh/2,hz));
  if(sp.roof==='hip')hipRoof(B,sp.roofM,hx,hz,W,D,ov,ye,yr);else gableRoof(B,sp.roofM,sp.gableM||sp.wall,hx,hz,W,D,ov,.38,top,ye,yr);
  const wo={frame:sp.frame,nal:sp.nal,nalM:sp.nalM,shutters:sp.shutters,lit:sp.lit};
  const nf=sp.mini?1:W>=9.5?3:2,wy=pl+1.45,ww=sp.mini?.9:1.15,wh2=sp.mini?1:1.32;
  for(let i=0;i<nf;i++){const x=hx-W/2+W*(i+.5)/nf;addWin(B,MX(x,wy,hz+D/2),ww,wh2,Object.assign({},wo,{boarded:sp.damage&&i===0}))}
  if(!sp.mini){addWin(B,MX(hx-W/2,wy,hz-D*.18,-Math.PI/2),ww,wh2,wo);if(D>7)addWin(B,MX(hx-W/2,wy,hz+D*.25,-Math.PI/2),ww,wh2,wo);addWin(B,MX(hx+W/2,wy,hz-D*.2,Math.PI/2),ww,wh2,wo)}
  // door on right side + porch
  const dz=hz+D/2-1.5,wx=hx+W/2,dm=MX(wx,pl,dz,Math.PI/2);const DP=(g,k,x,y,z)=>B.add(k,g,new T.Matrix4().multiplyMatrices(dm,MX(x,y,z)));
  DP(boxG(.95,2.02,.06),sp.door||'woodBrown',0,1.01,.03);DP(boxG(1.15,.08,.09),'woodBrown',0,2.06,.04);DP(boxG(.08,2.08,.09),'woodBrown',-.53,1.04,.04);DP(boxG(.08,2.08,.09),'woodBrown',.53,1.04,.04);DP(boxG(.03,.03,.14),'galv',.35,1.0,.09);
  if(!sp.mini){
    if(sp.porch==='veranda'){const vx=wx+1.25,vz=dz;B.add('wood',boxG(2.5,1.0,3.2),MX(vx,pl+.5,vz));B.add('plinthGrey',boxG(2.6,pl,3.3),MX(vx,pl/2,vz));
      for(const[gx,gz,gw,ry]of[[vx+1.25,vz,3.2,Math.PI/2],[vx,vz-1.6,2.5,Math.PI]]){B.add('glass',planeG(gw-.1,1.2),MX(gx,pl+1.65,gz,ry));B.add('curtain',planeG(gw-.2,.8),MX(gx-(ry===Math.PI/2?.02:0),pl+1.75,gz+(ry===Math.PI?.02:0),ry))}
      B.add('glass',planeG(1.3,1.2),MX(vx+.55,pl+1.65,vz+1.6));B.add(sp.door||'woodBrown',boxG(.9,2.05,.05),MX(vx-.65,pl+1.02,vz+1.61));
      for(const[cx,cz]of[[vx-1.22,vz+1.57],[vx+1.22,vz+1.57],[vx+1.22,vz-1.57],[vx-1.22,vz-1.57]])B.add('woodWhite',boxG(.09,1.3,.09),MX(cx,pl+1.65,cz));
      for(let i=1;i<4;i++)B.add('woodWhite',boxG(.06,1.2,.06),MX(vx+1.24,pl+1.65,vz-1.6+i*.8));B.add('woodWhite',boxG(2.55,.1,3.25),MX(vx,pl+2.3,vz));B.add('woodWhite',boxG(2.55,.06,3.25),MX(vx,pl+1.03,vz));
      B.add(sp.roofM,polyG([V(vx+1.5,pl+2.35,vz+1.85),V(vx+1.5,pl+2.35,vz-1.85),V(vx-1.25,top-.05,vz-1.85),V(vx-1.25,top-.05,vz+1.85)]));
      for(let i=0;i<3;i++)B.add('concrete',boxG(.35*(3-i),.18*(i+1),1.2),MX(vx-.65+(3-i)*.175,.09*(i+1),vz+1.6+.6));}
    else{for(let i=0;i<3;i++)B.add('concrete',boxG(.36*(3-i),.18*(i+1),1.5),MX(wx+.18*(3-i),.09*(i+1),dz));
      for(const s of[-1,1])B.add('galv',beamG(V(wx+1.25,0,dz+s*.85),V(wx+1.25,2.85,dz+s*.85),.035));B.add(sp.canopyM||'metalGreen',boxG(1.5,.02,2.1),MX(wx+.72,2.9,dz,0,0,-.14));B.add('galv',boxG(.05,.05,2.1),MX(wx+1.25,2.8,dz))}}
  // chimney, antenna, dish, gas, gutter, plaque
  const cx=hx+W*.2,cz=hz-D*.12;B.add('brickRed',boxG(.5,yr+.9-top,.5),MX(cx,(yr+.9+top)/2,cz));B.add('concrete',boxG(.64,.07,.64),MX(cx,yr+.93,cz));
  if(sp.antenna){const a0=V(cx+.18,yr+.95,cz+.18);B.add('galv',beamG(a0,V(a0.x,a0.y+2.3,a0.z),.022));B.add('galv',beamG(V(a0.x-.9,a0.y+2.1,a0.z),V(a0.x+.9,a0.y+2.1,a0.z),.012));for(let i=0;i<5;i++)B.add('galv',beamG(V(a0.x-.8+i*.4,a0.y+2.1,a0.z-.32),V(a0.x-.8+i*.4,a0.y+2.1,a0.z+.32),.008))}
  if(sp.dish){const dx=hx-W/2+.7,dy=top-.25,dz2=hz+D/2+.45;B.add('galv',beamG(V(dx,dy,hz+D/2),V(dx,dy,dz2),.02));const g=new T.SphereGeometry(.34,14,6,0,Math.PI*2,0,.6);B.add('dish',g,MX(dx,dy+.05,dz2+.05,0,1.15));B.add('galv',beamG(V(dx,dy,dz2),V(dx,dy+.12,dz2+.4),.012))}
  if(sp.gas){const gz=hz+D/2+.12,gy=top-.35;B.add('gas',beamG(V(hx-W/2-.15,gy,gz),V(wx+.12,gy,gz),.03));B.add('gas',beamG(V(wx+.12,gy,gz),V(wx+.12,.4,gz),.03));
    B.add('galv',boxG(.32,.42,.2),MX(wx+.12,1.3,gz+.12));for(let i=0;i<4;i++)B.add('dark',boxG(.04,.04,.12),MX(hx-W/2+i*W/3,gy,gz-.06))}
  if(!sp.mini){const gz=hz+D/2+ov-.08;B.add('galv',beamG(V(hx-W/2-ov,ye-.1,gz),V(hx+W/2+ov,ye-.1,gz),.055,7));B.add('galv',beamG(V(hx-W/2-ov+.1,ye-.1,gz),V(hx-W/2-ov+.1,.15,gz),.045,6));
    B.add('plaque',boxG(.44,.26,.02),MX(hx+W/2-.55,top-.55,hz+D/2+.012));B.add('pvc',planeG(.36,.08),MX(hx+W/2-.55,top-.55,hz+D/2+.023))}
  if(sp.damage){const z=hz+D/2+.006;for(let i=0;i<4;i++){const bx=hx-W/2+1+R()*(W-2),by=pl+.4+R()*(wh-1);B.add(i?'saman':'brickRed',blobG(bx,by,z,.3+R()*.5,.2+R()*.35,R))}
    for(let i=0;i<2;i++){const t=.3+R()*.4,x0=hx-W/2+1.5+R()*(W-3),Z=D/2+ov;const y0=ye+(yr-ye)*t,z0=Z*(1-t)+.03;B.add('interior',polyG([V(x0,y0,hz+z0),V(x0+.8,y0,hz+z0),V(x0+.8,y0+.35,hz+z0-.42),V(x0,y0+.35,hz+z0-.42)]))}}
  return{top,yr,attach:V(wx-1,top+.3,hz+D/2)}}
function fenceRun(B,kind,mat,x0,x1,zf,R,col){const L=x1-x0;if(L<.3)return;
  if(kind==='profile'){for(let x=x0;x<=x1+.01;x+=Math.max(.5,L/Math.ceil(L/2.5)))B.add('dark',boxG(.06,2.0,.06),MX(x,1.0,zf));B.add(mat,boxG(L,1.78,.012),MX((x0+x1)/2,1.0,zf+.02));B.add('dark',boxG(L,.05,.05),MX((x0+x1)/2,1.92,zf+.02))}
  else{const old=kind==='picketOld';for(let x=x0;x<=x1+.01;x+=Math.max(.5,L/Math.ceil(L/2.5)))B.add(old?'woodBrown':'dark',old?boxG(.09,1.5,.09):cylG(.035,.035,1.5,6),MX(x,.75,zf));
    for(const y of[.35,1.1])B.add('woodBrown',boxG(L,.08,.025),MX((x0+x1)/2,y,zf-.03));
    for(let x=x0+.08;x<x1-.04;x+=.135){if(old&&R()<.07)continue;B.add(old&&R()<.35?'wood':mat,PICKET.clone(),MX(x,.06,zf,0,0,old?(R()-.5)*.07:0))}}
  if(col)col()}
let PICKET=null;
function buildPlot(sp){const R=rngS(sp.px*7+3),F=plotFrame(sp),B=F.B,zf=-7.5;
  if(sp.shop)return buildShop(sp,F,R);if(sp.busstop)return buildBusStop(sp,F);
  const hx=-2,hz=zf-5-sp.D/2;let HB=B,SB=null;
  SB=new Bld();HB={add:(k,g,mx)=>{if(mx)g.applyMatrix4(mx);g.applyMatrix4(F.grp.matrixWorld);SB.add(k,g)}};
  const hres=house(HB,sp,hx,hz,R),W=sp.W,D=sp.D;
  const pg=new T.Group();SB.flush(pg);scene.add(pg);const hc=F.toW(hx,hz);const HT={proc:pg,x:hc.x,y:0,z:hc.z,ry:F.grp.rotation.y,extra:[]};(SLOT.houses=SLOT.houses||[]).push(HT);
  if(sp.slot){const c=F.toW(hx+.9,hz);SLOT[sp.slot]={proc:pg,x:c.x,y:0,z:c.z,ry:F.grp.rotation.y,W:W+2.4,D:D+1.4}}
  HT.col=F.colBox(hx-W/2-.1,hz-D/2-.1,hx+W/2+.1,hz+D/2+.1,hres.yr+.5);
  if(sp.porch==='veranda')HT.extra.push(F.colBox(hx+W/2,hz+D/2-3.1,hx+W/2+2.55,hz+D/2+.1,3.4));
  // front fence with open wicket (хвіртка) and closed gate (ворота)
  const fk=sp.fence,fm=sp.fenceM,FC=(a,b)=>()=>F.colBox(a,zf-.12,b,zf+.12,0);
  fenceRun(B,fk,fm,-11,4.3,zf,R,FC(-11,4.3));fenceRun(B,fk,fm,5.4,6.4,zf,R,FC(5.4,6.4));fenceRun(B,fk,fm,9.4,11,zf,R,FC(9.4,11));
  const gm=fk==='profile'?fm:fm;for(const gx of[7.15,8.65])B.add(gm,boxG(1.46,fk==='profile'?1.8:1.45,.04),MX(gx,fk==='profile'?1.0:.8,zf));
  B.add('dark',boxG(3,.05,.05),MX(7.9,fk==='profile'?1.9:1.5,zf+.03));F.colBox(6.4,zf-.12,9.4,zf+.12,0);
  B.add(fm,boxG(1.0,fk==='profile'?1.75:1.4,.04),MX(4.35+.5*Math.cos(1.2),fk==='profile'?1.0:.78,zf-.5*Math.sin(1.2),1.2));
  // side fences (сітка-рабиця)
  for(const sx of[-10.95,10.95]){const z0=zf,z1=-46,L=z0-z1;for(let z=z0;z>=z1-.01;z-=L/Math.ceil(L/2.5))B.add('galv',cylG(.03,.03,1.6,6),MX(sx,.8,z));B.add('chain',planeG(L,1.5),MX(sx,.82,(z0+z1)/2,Math.PI/2));
    B.add('galv',beamG(V(sx,1.58,z0),V(sx,1.58,z1),.012));F.colBox(sx-.1,z1,sx+.1,z0,0)}
  // path slabs from wicket to door
  const ex=hx+W/2+(sp.porch==='veranda'?.6:1.2),ez=sp.porch==='veranda'?hz+D/2+.6+1.4:hz+D/2-1.5;
  for(let t=0;t<=1.0001;t+=1/9){const x=lerp(4.85,ex,Math.min(1,t*1.3)),z=lerp(zf-.4,ez,t);B.add('concrete',boxG(.62,.05,.62),MX(x,.025,z,0,0,0))}
  B.add('soil',polyG([V(6.4,.012,zf),V(9.4,.012,zf),V(9.4,.012,-30),V(6.4,.012,-30)]));
  // shed, woodpile, toilet
  {const sx=7.6,sz=-31.5;B.add('wood',boxG(4,2.3,3.2),MX(sx,1.15,sz));B.add('slate',polyG([V(sx-2.3,2.15,sz+1.9),V(sx+2.3,2.15,sz+1.9),V(sx+2.3,2.75,sz-1.9),V(sx-2.3,2.75,sz-1.9)]));
    B.add('woodBrown',boxG(1,1.9,.05),MX(sx-.8,.95,sz+1.62));F.colBox(sx-2.05,sz-1.65,sx+2.05,sz+1.65,3);
    for(let r=0;r<6;r++)for(let i=0;i<12;i++){const g=cylG(.1+R()*.03,.1,.45,7);g.rotateX(Math.PI/2);B.add('bark',g,MX(sx-2.3+i*.2+(r%2)*.1,.12+r*.19,sz+2.0))}
    B.add('wood',boxG(1.1,2.1,1.1),MX(9.7,1.05,-44.3));B.add('slate',boxG(1.4,.04,1.4),MX(9.7,2.15,-44.3,0,.1));F.colBox(9.1,-44.9,10.3,-43.7,2.3)}
  if(sp.kitchen){const kx=-7.2,kz=hz-D/2-5.5;const kr=house(B,{W:4,D:3.6,wh:2.3,wall:sp.wall,plinth:sp.plinth,roof:'gable',roofM:sp.roofM,gableM:sp.gableM||sp.wall,frame:sp.frame,mini:true,door:sp.door},kx,kz,R);F.colBox(kx-2.1,kz-1.9,kx+2.1,kz+1.9,kr.yr+.3)}
  if(sp.well){const wx=-8.4,wz=zf-2.6;B.add('concrete',cylG(.62,.62,.9,14),MX(wx,.45,wz));B.add('interior',new T.CircleGeometry(.5,14).rotateX(-Math.PI/2),MX(wx,.905,wz));
    for(const s of[-1,1])B.add('woodBrown',boxG(.1,1.9,.1),MX(wx+s*.62,.95,wz));B.add('slate',GEO.prism.clone().scale(1.7,.55,1.4),MX(wx,1.9,wz));B.add('woodBrown',cylG(.06,.06,1.3,8).rotateZ(Math.PI/2),MX(wx,1.5,wz));
    B.add('galv',cylG(.15,.12,.28,10),MX(wx+.3,1.1,wz));F.colBox(wx-.7,wz-.7,wx+.7,wz+.7,2.2)}
  // clothesline
  {const z=hz-D/2-2.5;for(const x of[-10,-3.5])B.add('galv',cylG(.03,.03,2.0,6),MX(x,1.0,z));WIRES.push([F.toW(-10,z,1.95),F.toW(-3.5,z,1.95),.12]);
    for(let i=0;i<4;i++)B.add('cloth'+(R()*5|0),planeG(.5+R()*.3,.55+R()*.35),MX(-9+i*1.4,1.6,z,R()*.3-.15,0,0))}
  // garden: dug potato ridges, dry corn, sunflower stalks
  for(let z=-35;z>-45.5;z-=.8){const g=new T.CylinderGeometry(.24,.24,13.5,7,1,false,0,Math.PI);g.rotateZ(Math.PI/2);g.scale(1,.55,1);B.add('soil',g,MX(-3.2,0,z))}
  B.add('soil',polyG([V(-10.8,.01,-34.5),V(3.6,.01,-34.5),V(3.6,.01,-45.8),V(-10.8,.01,-45.8)]));
  for(let x=4.4;x<10.6;x+=.7)for(let z=-35;z>-42;z-=.8){if(R()<.15)continue;const g1=planeG(.7,2.1),g2=planeG(.7,2.1);g2.rotateY(Math.PI/2);B.add('corn',g1,MX(x+R()*.2,1.05,z,R()*3));B.add('corn',g2,MX(x+R()*.2,1.05,z,R()*3))}
  for(let i=0;i<9;i++){const x=4.6+R()*3.6,z=-42.6-R()*3,h=1.6+R()*.4;B.add('stalk',cylG(.022,.03,h,5),MX(x,h/2,z));B.add('sunHead',cylG(.17,.17,.05,10),MX(x+.1,h-.05,z,0,1.2+R()*.4))}
  // bench by the gate
  if(R()<.75){B.add('woodBrown',boxG(1.7,.05,.32),MX(1.5,.45,zf+.55));for(const s of[-.7,.7])B.add('woodBrown',boxG(.07,.43,.28),MX(1.5+s,.215,zf+.55));B.add('woodBrown',boxG(1.7,.22,.04),MX(1.5,.72,zf+.38))}
  // flowers along fence, trees
  for(let x=-10;x<3.6;x+=.55)if(R()<.6)FLOWERPL.push(F.toW(x+R()*.2,zf-.45-R()*.35));
  const tw=F.toW(-7.5,hz-D/2-9.5);TREEPL.walnut.push({x:tw.x,z:tw.z,s:.9+R()*.25,ry:R()*6.28});
  for(const[ax,az]of[[-1,-31],[-6,-33],[1.8,-27.5]]){const p=F.toW(ax+R(),az+R());TREEPL.apple.push({x:p.x,z:p.z,s:.85+R()*.3,ry:R()*6.28})}
  if(R()<.6){const p=F.toW(-9.3,zf-1.6);TREEPL.apple.push({x:p.x,z:p.z,s:.7,ry:R()*6.28})}
  DROPS.push(F.toW(hres.attach.x,hres.attach.z,hres.attach.y));
  B.flush(F.grp)}
function buildShop(sp,F,R){const B=F.B,zf=-7.5,W=12,D=9,hz=zf-1.6-D/2,hx=0,pl=.35,wh=3.1,top=pl+wh,ov=.45,rise=1.3,ye=top-ov*rise/(D/2),yr=top+rise;
  B.add('plinthGrey',boxG(W+.12,pl,D+.12),MX(hx,pl/2,hz));B.add('brickSil',boxG(W,wh,D),MX(hx,pl+wh/2,hz));gableRoof(B,'metalBlue','brickSil',hx,hz,W,D,ov,.3,top,ye,yr);
  const fz=hz+D/2;for(const x of[-3.4,3.4]){addWin(B,MX(x,pl+1.6,fz),2.3,1.6,{frame:'pvc',lit:true});for(let i=0;i<14;i++)B.add('dark',cylG(.012,.012,1.7,5),MX(x-1.1+i*.17,pl+1.6,fz+.12));B.add('dark',boxG(2.4,.04,.04),MX(x,pl+.75,fz+.12));B.add('dark',boxG(2.4,.04,.04),MX(x,pl+2.45,fz+.12))}
  B.add('metalBrown',boxG(1.1,2.15,.06),MX(0,pl+1.07,fz+.03));B.add('galv',boxG(.03,.2,.05),MX(.38,pl+1.05,fz+.08));B.add('metalGreen',boxG(1.8,.04,1.1),MX(0,pl+2.5,fz+.55,0,-.12));
  for(const s of[-1,1])B.add('dark',beamG(V(s*.85,pl+2.5,fz),V(s*.85,pl+2.42,fz+1.05),.015));
  B.add('signShop',planeG(5.2,.95),MX(0,top-.2,fz+.025));B.add('paper',planeG(.9,.45),MX(-1.25,pl+1.5,fz+.02));
  for(let i=0;i<3;i++)B.add('concrete',boxG(2.2,.12*(i+1),.32*(3-i)),MX(0,.06*(i+1),fz+.16*(3-i)));
  B.add('asphalt',polyG([V(-8,.014,zf+.3),V(8,.014,zf+.3),V(8,.014,fz),V(-8,.014,fz)]));
  B.add('woodBrown',boxG(1.8,.05,.34),MX(-4.8,.46,fz+.6));for(const s of[-.75,.75])B.add('dark',boxG(.06,.44,.3),MX(-4.8+s,.22,fz+.6));
  B.add('galv',cylG(.26,.22,.75,12),MX(1.6,.375,fz+.5));
  // bicycle leaning on wall
  {const bx=-1.8,bz=fz+.35,lean=.22;const bm=MX(bx,0,bz,0,0,lean);const BP=(g,k)=>B.add(k,g,new T.Matrix4().multiplyMatrices(bm,new T.Matrix4()));
    for(const ox of[-.52,.52]){const t=new T.TorusGeometry(.33,.022,6,22);t.translate(ox,.34,0);BP(t,'rubber')}
    const fr=[[V(-.52,.34,0),V(-.05,.36,0)],[V(-.05,.36,0),V(.36,.78,0)],[V(-.05,.36,0),V(-.2,.8,0)],[V(-.2,.8,0),V(.36,.78,0)],[V(.36,.78,0),V(.52,.34,0)],[V(-.52,.34,0),V(-.2,.8,0)],[V(.36,.78,0),V(.32,.95,0)]];
    fr.forEach(([a,b])=>BP(beamG(a,b,.016),'metalBlue'));BP(beamG(V(.2,.97,-.25),V(.2,.97,.25),.014),'dark');BP(boxG(.22,.05,.09).translate(-.2,.84,0),'dark')}
  F.colBox(hx-W/2-.1,hz-D/2-.1,hx+W/2+.1,hz+D/2+.1,yr+.4);
  // old sedan parked in front
  const sd=makeSedan();sd.position.set(5.6,0,zf+1.7);sd.rotation.y=Math.PI/2;F.grp.add(sd);F.colBox(3.4,zf+.85,7.8,zf+2.55,1.6);
  DROPS.push(F.toW(hx+W/2-1,fz,top+.2));
  const t=F.toW(-7.5,hz-D/2-3);TREEPL.walnut.push({x:t.x,z:t.z,s:1.05,ry:2});
  B.flush(F.grp)}
function buildBusStop(sp,F){const B=F.B;
  B.add('concrete',boxG(4.6,.08,2.1),MX(0,.04,-5.2));B.add('concrete',boxG(4.4,2.4,.16),MX(0,1.2,-6.15));B.add('mosaic',planeG(4.1,1.75),MX(0,1.35,-6.06));
  for(const s of[-1,1])B.add('concrete',boxG(.16,2.4,1.8),MX(s*2.2,1.2,-5.3));B.add('concrete',boxG(4.9,.16,2.3),MX(0,2.48,-5.15));
  B.add('concrete',boxG(3.2,.42,.38),MX(0,.21,-5.75));B.add('woodBrown',boxG(3.3,.05,.42),MX(0,.45,-5.75));
  B.add('galv',cylG(.035,.035,2.7,6),MX(2.9,1.35,-4.15));B.add('busSign',planeG(.5,.5),MX(2.9,2.45,-4.1));
  F.colBox(-2.35,-6.3,2.35,-4.3,2.6)}
function makeSedan(){const g=new T.Group(),R=rngS(77);const paint=std({map:texPaint('#93a7b2',false),roughness:.55,metalness:.3,envMapIntensity:.8});
  const prof=[[-2.1,.44],[-1.65,.44],...arcPts(-1.25,.32,.4,Math.PI,0,8),[.85,.44],...arcPts(1.25,.32,.4,Math.PI,0,8),[2.05,.44],[2.12,.56],[2.12,.8],[2.0,.86],[1.0,.92],[.36,1.34],[-.68,1.36],[-1.34,.97],[-2.06,.94],[-2.12,.62]];
  const W=1.6,bev=.05;const body=new T.Mesh(extrudeProfile(prof,W,bev),paint);body.castShadow=body.receiveShadow=true;g.add(body);
  const glass=std({color:'#141a1e',roughness:.05,metalness:.2,envMapIntensity:1.5});
  const sw=new T.Mesh(extrudeProfile([[-1.22,.98],[.92,.97],[.34,1.3],[-.64,1.32]],W+.012,0),glass);g.add(sw);
  g.add(new T.Mesh(polyG([V(-.72,.98,1.02),V(.72,.98,1.02),V(.72,1.35,.42),V(-.72,1.35,.42)]),glass));g.add(new T.Mesh(polyG([V(.7,1.0,-1.38),V(-.7,1.0,-1.38),V(-.7,1.33,-.74),V(.7,1.33,-.74)]),glass));
  const dark=std({color:'#222',roughness:.7}),chrome=std({color:'#c8ccce',roughness:.2,metalness:.9});
  for(const z of[2.14,-2.14]){const m=new T.Mesh(boxG(1.64,.14,.12),chrome);m.position.set(0,.55,z);g.add(m)}
  for(const s of[-.55,.55]){const h=new T.Mesh(boxG(.28,.14,.04),std({color:'#e8e2c8',emissive:'#151208',roughness:.2}));h.position.set(s,.75,2.13);g.add(h)}
  for(const[x,z]of[[-.72,1.25],[.72,1.25],[-.72,-1.25],[.72,-1.25]]){const w=tireMesh(.3,.17,dark,chrome);w.position.set(x,.3,z);g.add(w)}
  g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}});return g}
function arcPts(cx,cy,r,a0,a1,n){const o=[];for(let i=0;i<=n;i++){const t=a0+(a1-a0)*i/n;o.push([cx+Math.cos(t)*r,cy+Math.sin(t)*r])}return o}
function extrudeProfile(pts,W,bev){const s=new T.Shape();s.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)s.lineTo(pts[i][0],pts[i][1]);s.lineTo(pts[0][0],pts[0][1]);
  const d=Math.max(.002,W-2*bev),g=new T.ExtrudeGeometry(s,{depth:d,bevelEnabled:bev>0,bevelThickness:bev,bevelSize:bev,bevelSegments:2,curveSegments:4});g.translate(0,0,-d/2);g.rotateY(-Math.PI/2);return g}
function tireMesh(r,w,rubber,rimM){const grp=new T.Group();const pr=[[r*.62,-w/2],[r*.9,-w/2-.005],[r*.97,-w*.4],[r,-w*.15],[r,w*.15],[r*.97,w*.4],[r*.9,w/2+.005],[r*.62,w/2]].map(p=>new T.Vector2(p[0],p[1]));
  const t=new T.Mesh(new T.LatheGeometry(pr,20),rubber);t.rotation.z=Math.PI/2;grp.add(t);const rim=new T.Mesh(cylG(r*.62,r*.62,w*.85,16),rimM);rim.rotation.z=Math.PI/2;grp.add(rim);
  const hub=new T.Mesh(cylG(r*.2,r*.24,w*.95,10),rimM);hub.rotation.z=Math.PI/2;grp.add(hub);
  for(let i=0;i<5;i++){const s=new T.Mesh(boxG(w*.9,r*.08,r*.5),rimM);s.position.set(0,0,0);s.rotation.x=i/5*Math.PI*2;s.translateY(r*.3);grp.add(s)}
  grp.traverse(o=>{if(o.isMesh)o.castShadow=true});return grp}
function buildRoadAndPoles(){const B=new Bld(),R=rngS(404),x0=-127,x1=-25;
  // rutted dirt road ribbon
  const pos=[],uv=[],idx=[],offs=[-3.5,-1.6,-.8,0,.8,1.6,3.5];let s=0,prev=null,row=0;
  for(let x=x0;x<=x1+.001;x+=1){const z=roadMain(x),dz=(roadMain(x+.5)-roadMain(x-.5)),l=Math.hypot(1,dz),nx=-dz/l,nz=1/l;if(prev)s+=Math.hypot(x-prev[0],z-prev[1]);prev=[x,z];
    for(const o of offs){const px=x+nx*o,pz=z+nz*o;pos.push(px,H(px,pz)+.025,pz);uv.push((o+3.5)/7,s/16)}
    if(row>0){const a=(row-1)*offs.length,b=row*offs.length;for(let k=0;k<offs.length-1;k++){idx.push(a+k,b+k,a+k+1,a+k+1,b+k,b+k+1)}}row++}
  const rg=new T.BufferGeometry();rg.setAttribute('position',new T.Float32BufferAttribute(pos,3));rg.setAttribute('uv',new T.Float32BufferAttribute(uv,2));rg.setIndex(idx);rg.computeVertexNormals();
  const rm=new T.Mesh(rg,MATS.road);rm.receiveShadow=true;scene.add(rm);
  // puddles in the ruts
  for(const x of[-119,-111,-98,-84,-73,-57,-46,-35]){const sd=R()<.5?-1:1,z=roadMain(x),th=Math.atan(roadMain(x+.5)-roadMain(x-.5)),cx=x-Math.sin(th)*sd*.82,cz=z+Math.cos(th)*sd*.82;
    const L=.7+R()*1.1,Wd=.24+R()*.12,pts=[];for(let i=0;i<12;i++){const a=i/12*Math.PI*2,k=.85+R()*.25;pts.push(V(cx+Math.cos(a)*L*k*Math.cos(th)-Math.sin(a)*Wd*k*Math.sin(th),.05,cz+Math.cos(a)*L*k*Math.sin(th)+Math.sin(a)*Wd*k*Math.cos(th)))}
    B.add('water',polyG(pts.reverse()));puddles.push({x:cx,z:cz,rx:L,rz:Wd+.2})}
  // concrete power poles (north verge) with wires and street lamps
  const poles=[];for(let i=0;i<4;i++){const x=-121+i*30.5,z=roadMain(x)-6.3;poles.push([x,z]);
    const g=cylG(.085,.15,9.6,4);g.rotateY(Math.PI/4);B.add('concrete',g,MX(x,4.8,z));B.add('dark',boxG(.09,.09,1.9),MX(x,9.0,z));
    for(const o of[-.85,-.3,.3,.85])B.add('insul',cylG(.035,.05,.13,8),MX(x,9.12,z+o));addCol({t:'c',x,z,r:.18});
    if(i%2===0){B.add('galv',beamG(V(x,8.3,z),V(x,8.15,z+1.7),.03));B.add('lamp',boxG(.26,.12,.48),MX(x,8.08,z+1.85))}}
  for(let i=0;i<poles.length-1;i++)for(const o of[-.85,-.3,.3,.85])WIRES.push([V(poles[i][0],9.18,poles[i][1]+o),V(poles[i+1][0],9.18,poles[i+1][1]+o),.45]);
  WIRES.push([V(poles[0][0],9.18,poles[0][1]-.85),V(poles[0][0]-30,9.18,roadMain(poles[0][0]-30)-6.3),.45]);
  for(const d of DROPS){let best=poles[0],bd=1e9;for(const p of poles){const dd=dist2(p[0],p[1],d.x,d.z);if(dd<bd){bd=dd;best=p}}WIRES.push([V(best[0],9.1,best[1]+.85),d,.35])}
  // street name sign
  {const x=-119,z=roadMain(x)+5.2;B.add('galv',cylG(.04,.04,2.6,6),MX(x,1.3,z));B.add('street',planeG(1.3,.33),MX(x,2.45,z,-Math.PI/2));addCol({t:'c',x,z,r:.12})}
  // roadside acacias
  for(const[x,o]of[[-115,5.6],[-73,5.4],[-37,5.6],[-100,-5.4]]){TREEPL.acacia.push({x,z:roadMain(x)+o,s:.85+R()*.3,ry:R()*6.28})}
  B.flush(scene);
  // wires as catenaries
  const wp=[];for(const[a,b,sag]of WIRES){let pa=a;for(let i=1;i<=14;i++){const t=i/14,p=V(lerp(a.x,b.x,t),lerp(a.y,b.y,t)-sag*4*t*(1-t),lerp(a.z,b.z,t));wp.push(pa.x,pa.y,pa.z,p.x,p.y,p.z);pa=p}}
  const wg=new T.BufferGeometry();wg.setAttribute('position',new T.Float32BufferAttribute(wp,3));scene.add(new T.LineSegments(wg,new T.LineBasicMaterial({color:0x1a1a1a})))}
function buildGrass(){const n=QL.grass,R=rngS(808),pl=[];
  for(let i=0;i<n*3&&pl.length<n;i++){const x=SHOWX0+2+R()*(SHOWX1-SHOWX0-4),side=R()<.5?-1:1;const verge=R()<.42,d=verge?3.15+R()*4.1:7.8+R()*37;const z=roadMain(x)+side*d;
    if(colAt(x,z))continue;if(!verge&&R()<.35)continue;pl.push([x,z,verge?.75+R()*.6:.35+R()*.4,R()*6.28])}
  const g1=new T.PlaneGeometry(1,.75);g1.translate(0,.375,0);const g2=g1.clone();g2.rotateY(Math.PI/2);const g=mergeGeos([g1,g2]);
  const m=new T.InstancedMesh(g,MATS.grassC,pl.length);pl.forEach((p,i)=>{_o.position.set(p[0],H(p[0],p[1])-.02,p[1]);_o.rotation.set(0,p[3],0);_o.scale.set(p[2]*1.2,p[2],p[2]*1.2);_o.updateMatrix();m.setMatrixAt(i,_o.matrix)});
  m.receiveShadow=true;scene.add(m);
  if(FLOWERPL.length){const f=new T.InstancedMesh(mergeGeos([new T.PlaneGeometry(.6,.6).translate(0,.3,0),new T.PlaneGeometry(.6,.6).translate(0,.3,0).rotateY(Math.PI/2)]),MATS.flower,FLOWERPL.length);
    FLOWERPL.forEach((p,i)=>{_o.position.set(p.x,0,p.z);_o.rotation.set(0,R()*6,0);_o.scale.setScalar(.8+R()*.5);_o.updateMatrix();f.setMatrixAt(i,_o.matrix)});f.receiveShadow=true;scene.add(f)}}
async function buildStreet(){await tick('Вулиця Садова: хати…',82);
  {const s=new T.Shape();s.moveTo(-.045,0);s.lineTo(.045,0);s.lineTo(.045,1.25);s.lineTo(0,1.36);s.lineTo(-.045,1.25);s.lineTo(-.045,0);PICKET=new T.ExtrudeGeometry(s,{depth:.02,bevelEnabled:false});}
  GB=new Bld();for(const sp of STREET)buildPlot(sp);GB.flush(scene);
  await tick('Вулиця Садова: дорога, стовпи, дерева…',88);
  buildRoadAndPoles();buildTrees();buildGrass()}

