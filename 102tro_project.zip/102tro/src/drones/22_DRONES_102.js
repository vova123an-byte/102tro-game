/* ================= DRONES 102 ================= */
const DRONES=[
  {n:'Розвідник «Птаха»',i:'🛰️',spd:13,acc:5,bat:210,climb:5,fpv:false,col:'#3a3f44',d:'Стабільний квадрокоптер для огляду села з неба. Камера ззаду, довга батарея.'},
  {n:'FPV «Стриж»',i:'⚡',spd:30,acc:13,bat:150,climb:11,fpv:true,col:'#2a2d30',d:'Швидкісний спортивний дрон для перегонів крізь кільця. Камера від першої особи.'},
  {n:'Вантажний «Чумак»',i:'📦',spd:9,acc:4,bat:180,climb:4,fpv:false,col:'#4f5a3c',cargo:true,d:'Великий дрон із гаком для доставки аптечок і припасів (місії 5 і 8).'}];
if(!S.drones)S.drones=[0];if(S.drone==null)S.drone=0;if(S.dbat==null)S.dbat=1;
const D={on:false,x:0,y:0,z:0,vx:0,vy:0,vz:0,roll:0,tilt:0,fpv:false,mesh:null,props:[],t:0,hit:0};
function makeDroneMesh(k){D.crate=null;const sp=DRONES[k],g=new T.Group(),body=std({color:S.dcol?DCOL[S.dcol].c:sp.col,roughness:.45,metalness:.4}),dark=std({color:'#151617',roughness:.6}),prop=std({color:'#111',roughness:.5,transparent:true,opacity:.55,side:T.DoubleSide});
  const sc=sp.cargo?1.7:sp.fpv?.75:1;const add=(geo,m,x,y,z,rx,ry,rz)=>{const me=new T.Mesh(geo,m);me.position.set(x*sc,y*sc,z*sc);me.rotation.set(rx||0,ry||0,rz||0);me.castShadow=true;g.add(me);return me};
  add(rbox(.26*sc,.08*sc,.36*sc,.03*sc),body,0,0,0);add(rbox(.16*sc,.05*sc,.18*sc,.02*sc),dark,0,.06,-.02);
  D.props=[];for(const[x,z]of[[-.24,.24],[.24,.24],[-.24,-.24],[.24,-.24]]){add(boxG(.35*sc,.03*sc,.04*sc),body,x/2,0,z/2,0,Math.atan2(x,z)+Math.PI/2);add(cylG(.035*sc,.04*sc,.06*sc,10),dark,x,.03,z);
    const pr=add(new T.CircleGeometry(.15*sc,18).rotateX(-Math.PI/2),prop,x,.07,z);D.props.push(pr)}
  add(new T.SphereGeometry(.045*sc,10,8),std({color:'#0a0c0e',roughness:.1,metalness:.5}),0,-.02,.19);
  const led=add(new T.SphereGeometry(.02*sc,6,5),std({color:'#ff3020',emissive:'#ff2010',roughness:.3}),0,.03,-.18);D.led=led;
  if(sp.cargo){add(cylG(.01,.01,.5,4),dark,0,-.3,0);const box=add(rbox(.28,.22,.28,.03),std({color:'#e8e2d4',roughness:.8}),0,-.62,0);add(boxG(.18,.05,.01),std({color:'#2f8a4a'}),0,-.62,.141);add(boxG(.05,.18,.01),std({color:'#2f8a4a'}),0,-.62,.141);D.crate=box;box.visible=false}
  for(let i=0;i<3;i++)add(boxG(.02*sc,.06*sc,.2*sc),dark,i===0?-.1:.1,-.06,0);
  return g}
function launchDrone(){if(P.inCar){toast('Вийди з авто, щоб запустити дрон');return}const sp=DRONES[S.drone];
  if(S.dbat<.15){toast('🔋 Батарея дрона розряджена ('+Math.round(S.dbat*100)+'%) — зачекай зарядку');return}
  if(D.mesh)scene.remove(D.mesh);D.mesh=makeDroneMesh(S.drone);linearizeAll(D.mesh);scene.add(D.mesh);
  const fx=Math.sin(P.yaw),fz=Math.cos(P.yaw);D.x=P.x+fx*1.4;D.z=P.z+fz*1.4;D.y=P.y+1.2;D.vx=D.vy=D.vz=0;D.on=true;D.fpv=sp.fpv;D.t=0;cam.yaw=P.yaw;cam.pitch=.32;
  hudMode='';toast(sp.i+' '+sp.n+' у повітрі');SFX.ring()}
function landDrone(why){if(!D.on)return;D.on=false;if(D.mesh)D.mesh.visible=false;hudMode='';cam.yaw=P.yaw;
  if(why==='bat')toast('🔋 Батарея сіла — дрон повернувся автоматично');else if(why!=='quiet')toast('Дрон повернувся до бійця');
  if(drAud)drAud.g.gain.setTargetAtTime(0,AC.currentTime,.1)}
let drAud=null;
function droneAudio(on,sp){if(!AC)return;if(!drAud){const o=AC.createOscillator(),o2=AC.createOscillator(),f=AC.createBiquadFilter(),g=AC.createGain();o.type='sawtooth';o2.type='square';f.type='bandpass';f.frequency.value=1400;f.Q.value=.8;g.gain.value=0;o.connect(f);o2.connect(f);f.connect(g).connect(sfxG);o.start();o2.start();drAud={o,o2,f,g}}
  const t=AC.currentTime;drAud.g.gain.setTargetAtTime(on&&S.sound?.035:0,t,.1);drAud.o.frequency.setTargetAtTime(170+sp*7,t,.08);drAud.o2.frequency.setTargetAtTime(171+sp*7.3,t,.08)}
function updDrone(dt){if(!D.on){S.dbat=Math.min(1,S.dbat+dt/45);if(edge.drone)launchDrone();return}
  const sp=DRONES[S.drone];D.t+=dt;
  if(edge.drone||edge.dland){missionEvent('droneLand');if(D.on)landDrone();return}
  if(edge.dcam){D.fpv=!D.fpv;toast(D.fpv?'Камера: від першої особи':'Камера: ззаду')}
  const fx=Math.sin(cam.yaw),fz=Math.cos(cam.yaw),rx=-fz,rz=fx,fwd=-inp.jy,str=inp.jx;
  const up=(inp.up||keys.KeyR?1:0)-(inp.down||keys.KeyF?1:0);
  const tx=(fx*fwd+rx*str)*sp.spd,tz=(fz*fwd+rz*str)*sp.spd,ty=up*sp.climb,k=Math.min(1,dt*sp.acc*.35);
  D.vx=lerp(D.vx,tx,k);D.vz=lerp(D.vz,tz,k);D.vy=lerp(D.vy,ty,Math.min(1,dt*4));
  const ox=D.x,oy=D.y,oz=D.z;D.x+=D.vx*dt;D.y+=D.vy*dt;D.z+=D.vz*dt;
  const gh=H(D.x,D.z)+.45;if(D.y<gh){D.y=gh;if(D.vy<-3){SFX.bump();cam.shake=.4}D.vy=Math.max(0,D.vy)}
  if(D.y>130){D.y=130;D.vy=0}D.x=clamp(D.x,-285,285);D.z=clamp(D.z,-285,285);
  if(colAt(D.x,D.z,D.y)){D.x=ox;D.z=oz;D.y=oy;const s=Math.hypot(D.vx,D.vz);D.vx*=-.35;D.vz*=-.35;if(s>4&&D.hit<=0){SFX.bump();cam.shake=.6;S.dbat=Math.max(0,S.dbat-.03);D.hit=.5;toast('💥 Зіткнення! −3% батареї')}}
  D.hit-=dt;
  const spd=Math.hypot(D.vx,D.vz),frac=spd/sp.spd;S.dbat-=dt/sp.bat*(.65+.35*frac+(up>0?.15:0));
  if(S.dbat<=0){S.dbat=0;missionEvent('droneBat');landDrone('bat');return}
  if(S.dbat<.2&&Math.floor(D.t*2)%4===0&&Math.floor((D.t-dt)*2)%4!==0)toast('🔋 Низький заряд: '+Math.round(S.dbat*100)+'%');
  // tilt visuals
  const lf=(D.vx*fx+D.vz*fz)/sp.spd,ls=(D.vx*rx+D.vz*rz)/sp.spd;D.tilt=lerp(D.tilt,lf*.35,dt*6);D.roll=lerp(D.roll,ls*.4,dt*6);
  D.mesh.position.set(D.x,D.y+Math.sin(D.t*3)*.03,D.z);D.mesh.rotation.set(D.tilt,cam.yaw,-D.roll,'YXZ');D.mesh.visible=!D.fpv;
  D.props.forEach((p,i)=>p.rotation.y+=dt*(40+i));if(D.led)D.led.visible=Math.floor(D.t*3)%2===0;
  droneAudio(true,spd);
  if(spd>6&&D.y-gh<3&&Math.random()<dt*20)emit(D.x,gh,D.z,(Math.random()-.5)*3,.8,(Math.random()-.5)*3,1,.5,'#a08a66',.35,1.4)}
function droneCamera(dt){const sp=DRONES[S.drone];
  if(D.fpv){const p=.3-cam.pitch;camera.position.set(D.x,D.y+.05,D.z);camera.rotation.set(clamp(p,-1.2,.6)-D.tilt*.6,cam.yaw+Math.PI,-D.roll*.8,'YXZ');
    const f=92;if(Math.abs(camera.fov-f)>.1){camera.fov=f;camera.updateProjectionMatrix()}}
  else{const dist=sp.cargo?7:5,cp=Math.cos(cam.pitch*.7),spp=Math.sin(cam.pitch*.7);let x=D.x-Math.sin(cam.yaw)*dist*cp,z=D.z-Math.cos(cam.yaw)*dist*cp,y=D.y+1+dist*spp;const gh=H(x,z)+.4;if(y<gh)y=gh;
    const cf=1-Math.exp(-dt*8);camera.position.set(lerp(camera.position.x,x,cf),lerp(camera.position.y,y,cf),lerp(camera.position.z,z,cf));camera.lookAt(D.x,D.y+.3,D.z);
    const f=66;if(Math.abs(camera.fov-f)>.1){camera.fov=lerp(camera.fov,f,dt*4);camera.updateProjectionMatrix()}}}
function droneOSD(){const o=$('#dOsd');if(!D.on){o.style.display='none';return}o.style.display='block';const sp=DRONES[S.drone],b=Math.round(S.dbat*100);
  o.innerHTML=`${sp.i} ${sp.n} · <b style="color:${b<20?'#ff7a5a':b<45?'#ffd84a':'#9fe08a'}">🔋 ${b}%</b> · ВИС ${Math.max(0,Math.round(D.y-H(D.x,D.z)))} м · ${Math.round(Math.hypot(D.vx,D.vz)*3.6)} км/год<div class="bar"><i style="width:${b}%"></i></div>`}

