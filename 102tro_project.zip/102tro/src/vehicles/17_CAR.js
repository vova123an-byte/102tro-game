/* ================= CAR ================= */
const CARCOL=[{n:'Олива',c:'#5b6b3a',cost:0},{n:'Пісок',c:'#b09461',cost:80},{n:'Піксель',c:'#56603a',camo:true,cost:160},{n:'Графіт',c:'#34383a',cost:120},{n:'Синьо-жовтий',c:'#2357b8',stripe:true,cost:250}];
function makeCarOld(){
  const grp=new T.Group(),body=new T.Group();grp.add(body);
  const col=CARCOL[S.carColor]||CARCOL[0];
  const paint=new T.MeshLambertMaterial(col.camo?{map:camoTex('#56603a',['#3e4628','#7a7a4e','#2f3520'])}:{color:col.c});
  const dark=new T.MeshLambertMaterial({color:0x22262a}),glass=new T.MeshLambertMaterial({color:0x2c3e4c,emissive:0x0a1218}),chrome=new T.MeshLambertMaterial({color:0x9aa0a4});
  const mk=(m,x,y,z,sx,sy,sz,par)=>{const me=new T.Mesh(GEO.box,m);me.position.set(x,y,z);me.scale.set(sx,sy,sz);me.castShadow=true;(par||body).add(me);return me};
  mk(paint,0,.95,0,2.0,.62,5.1);                 // lower body
  mk(paint,0,1.62,.35,1.9,.78,2.1);              // cab
  mk(glass,0,1.66,1.42,1.74,.6,.05);             // windshield
  mk(glass,0,1.7,-.71,1.6,.45,.05);              // rear window
  for(const sx of[-.96,.96])mk(glass,sx,1.68,.35,.05,.5,1.8);
  mk(paint,0,1.36,1.95,1.95,.16,1.2);            // hood
  mk(dark,0,.78,2.6,2.05,.32,.2);mk(dark,0,.78,-2.6,2.05,.3,.18); // bumpers
  mk(dark,0,1.32,-1.55,1.85,.06,1.9);            // bed floor
  for(const sx of[-.96,.96])mk(paint,sx,1.45,-1.55,.08,.36,1.95);mk(paint,0,1.45,-2.5,1.9,.36,.08);
  mk(dark,0,2.06,.35,1.6,.06,1.6);               // roof rack
  for(const sx of[-.7,.7])mk(chrome,sx,2.12,.35,.06,.06,1.7);
  const hl=new T.MeshLambertMaterial({color:0xfff3c4,emissive:0x665a30});for(const sx of[-.72,.72])mk(hl,sx,1.12,2.56,.42,.2,.06);
  const tl=new T.MeshLambertMaterial({color:0xb01a1a,emissive:0x400000});for(const sx of[-.86,.86])mk(tl,sx,1.2,-2.56,.22,.28,.06);
  if(col.stripe){const y=new T.MeshLambertMaterial({color:0xffd500});mk(y,0,1.275,1.95,.5,.02,1.21);mk(y,0,2.012,.35,.5,.02,2.11)}
  // door decals 102
  const dc=document.createElement('canvas');dc.width=128;dc.height=64;const dx=dc.getContext('2d');dx.fillStyle='#ffd500';dx.font='bold 46px "Russo One",Arial';dx.textAlign='center';dx.textBaseline='middle';dx.fillText('102',64,34);
  const dm=new T.MeshBasicMaterial({map:new T.CanvasTexture(dc),transparent:true});for(const sx of[-1,1]){const p=new T.Mesh(new T.PlaneGeometry(.9,.45),dm);p.position.set(sx*1.005,1.0,.4);p.rotation.y=sx*Math.PI/2;body.add(p)}
  // wheels
  const wg=new T.CylinderGeometry(.43,.43,.34,14);wg.rotateZ(Math.PI/2);const tire=new T.MeshLambertMaterial({color:0x1b1b1b}),rim=new T.MeshLambertMaterial({color:0x6d6f6a});
  const wheels=[];for(const[x,z,f]of[[-.95,1.62,1],[.95,1.62,1],[-.95,-1.6,0],[.95,-1.6,0]]){const piv=new T.Group();piv.position.set(x,.43,z);grp.add(piv);const sp=new T.Group();piv.add(sp);
    const w=new T.Mesh(wg,tire);w.castShadow=true;sp.add(w);const r=new T.Mesh(GEO.box,rim);r.scale.set(.36,.42,.12);sp.add(r);const r2=r.clone();r2.rotation.x=Math.PI/2;sp.add(r2);wheels.push({piv,sp,f,x,z})}
  // headlights
  const spot=new T.SpotLight(0xfff1c0,0,55,.5,.55,1.3);spot.position.set(0,1.1,2.4);const tg=new T.Object3D();tg.position.set(0,-1.5,18);grp.add(spot);grp.add(tg);spot.target=tg;
  return{grp,body,wheels,spot,paint};
}

