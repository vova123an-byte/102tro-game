/* ================= VEHICLES: 5 авто, гараж 102 ================= */
const VT={
  hilux:{n:'Пікап «Степовик»',s:'у стилі Toyota Hilux',i:'🛻',max:25,acc:8.5,turn:1.85,off:.4,hp:100,len:5.3,wd:1.86,wr:.44,un:'є з початку гри',col:0},
  l200:{n:'Пікап «Сокіл»',s:'у стилі Mitsubishi L200',i:'🛻',max:25.5,acc:9,turn:1.95,off:.45,hp:95,len:5.25,wd:1.84,wr:.43,un:'відкривається після місії 2',col:3},
  uaz:{n:'Позашляховик «Бобик»',s:'у стилі УАЗ',i:'🚙',max:20,acc:7.6,turn:2.1,off:.95,hp:90,len:4.05,wd:1.78,wr:.42,un:'відкривається після місії 3',col:0},
  van:{n:'Мікроавтобус «Мандрівник»',s:'у стилі Volkswagen Transporter',i:'🚐',max:22,acc:7,turn:1.6,off:.5,hp:110,len:4.95,wd:1.9,wr:.37,un:'відкривається після місії 5',col:1},
  patrol:{n:'Позашляховик «Буревій»',s:'у стилі Nissan Patrol',i:'🚙',max:27,acc:9.5,turn:1.8,off:.8,hp:130,len:5.0,wd:1.98,wr:.43,un:'місія 6 «Гараж 102»',col:3}};
const VORDER=['hilux','l200','uaz','van','patrol'],VUNLOCK={2:'l200',3:'uaz',5:'van',6:'patrol'};
if(!S.vun)S.vun=['hilux'];if(!S.vact||!VT[S.vact])S.vact='hilux';if(!S.vcol)S.vcol={};if(!S.vpos)S.vpos={};if(S.cmode==null)S.cmode=0;if(S.lights==null)S.lights=0;
const vehColor=t=>S.vcol[t]!=null?S.vcol[t]:(t==='hilux'?(S.carColor||0):VT[t].col);
const GARAGE={x:-170,z:roadMain(-170)-25};
const PARKS=[-184,-177.5,-171,-164.5,-158].map(x=>({x,z:roadMain(x)-14.4,yaw:.55}));
function vcfg(t){const A=(wz,wc,ar)=>arcPts(wz,wc,ar,Math.PI,0,9);
  if(t==='l200'){const w1=1.6,w2=-1.6,c=.45,a=.57;return{w1,w2,c,prof:[[-2.6,.52],[w2-a,.52],...A(w2,c,a),[w1-a,.52],...A(w1,c,a),[2.52,.52],[2.62,.68],[2.6,.97],[2.45,1.1],[1.25,1.2],[.55,1.8],[-.35,1.86],[-.62,1.78],[-.66,.98],[-2.6,.98]],
    glass:[[[-.55,1.2],[1.05,1.24],[.6,1.72],[-.33,1.8],[-.57,1.72]]],pill:[.28],ws:[[1.25,1.2],[.55,1.8]],rear:{z:-.66,y0:1.3,y1:1.72},bed:[-.66,-2.6]}}
  if(t==='patrol'){const w1=1.45,w2=-1.55,c=.46,a=.58;return{w1,w2,c,prof:[[-2.45,.55],[w2-a,.55],...A(w2,c,a),[w1-a,.55],...A(w1,c,a),[2.4,.55],[2.5,.7],[2.5,1.05],[2.4,1.18],[1.25,1.27],[.75,1.95],[-2.3,1.98],[-2.45,1.9],[-2.48,1.1]],
    glass:[[[-2.2,1.32],[1.05,1.33],[.72,1.85],[-2.2,1.88]]],pill:[.05,-1.05],ws:[[1.25,1.27],[.75,1.95]],rear:{z:-2.48,y0:1.35,y1:1.85},spare:-2.62,rack:[-2.1,.6,1.99]}}
  if(t==='van'){const w1=1.6,w2=-1.45,c=.38,a=.5;return{w1,w2,c,prof:[[-2.45,.45],[w2-a,.45],...A(w2,c,a),[w1-a,.45],...A(w1,c,a),[2.35,.45],[2.47,.6],[2.48,.95],[2.3,1.1],[1.85,1.3],[1.3,1.9],[1.0,1.98],[-2.35,2.0],[-2.45,1.9]],
    glass:[[[-2.15,1.3],[1.15,1.3],[.98,1.86],[-2.15,1.9]]],pill:[.45,-.4,-1.3],ws:[[1.85,1.3],[1.3,1.9]],rear:{z:-2.45,y0:1.3,y1:1.85},slide:true}}
  /* uaz */const w1=1.15,w2=-1.2,c=.44,a=.55;return{w1,w2,c,prof:[[-2.0,.55],[w2-a,.55],...A(w2,c,a),[w1-a,.55],...A(w1,c,a),[1.95,.55],[2.02,.7],[2.02,1.05],[1.9,1.12],[.75,1.17],[.7,1.2],[-2.0,1.2]],
    glass:[],pill:[],ws:null,rear:null,uaz:true,spare:-2.1}}
function makeVehicleT(t){const v=VT[t],cf=vcfg(t),grp=new T.Group(),body=new T.Group();grp.add(body);const col=CARCOL[vehColor(t)]||CARCOL[0];
  const paint=std({map:texPaint(col.c,col.camo),roughness:.45,metalness:.35,envMapIntensity:.9});
  const plastic=std({color:'#242526',roughness:.72}),chrome=std({color:'#c8ccce',roughness:.22,metalness:.9}),glass=std({color:'#121719',roughness:.04,metalness:.2,envMapIntensity:1.7});
  const lens=std({color:'#f2ecd6',emissive:'#4a4330',roughness:.15}),tail=std({color:'#8a1612',emissive:'#2a0000',roughness:.3}),rimM=std({color:'#5d605e',roughness:.4,metalness:.7}),rubber=std({color:'#171717',roughness:.93});
  const mk=(g,m,x,y,z,rx,ry,rz)=>{const me=new T.Mesh(g,m);me.position.set(x||0,y||0,z||0);me.rotation.set(rx||0,ry||0,rz||0);me.castShadow=true;me.receiveShadow=true;body.add(me);return me};
  const Wd=v.wd,zf=Math.max(...cf.prof.map(p=>p[0]))+.06,zr=Math.min(...cf.prof.map(p=>p[0]))-.06;
  mk(extrudeProfile(cf.prof,Wd,.06),paint);
  cf.glass.forEach(g=>mk(extrudeProfile(g,Wd+.012,0),glass));cf.pill.forEach(z=>{for(const s of[-1,1])mk(boxG(.012,.62,.1),plastic,s*(Wd/2+.007),1.58,z)});
  if(cf.ws){const[b,tp]=cf.ws,dz=tp[0]-b[0],dy=tp[1]-b[1],l=Math.hypot(dz,dy),nz=dy/l*.075,ny=-dz/l*.075,iz=dz/l*.05,iy=dy/l*.05,xw=Wd/2-.1;
    mk(polyG([V(-xw,b[1]+ny+iy,b[0]+nz+iz),V(xw,b[1]+ny+iy,b[0]+nz+iz),V(xw,tp[1]+ny-iy,tp[0]+nz-iz),V(-xw,tp[1]+ny-iy,tp[0]+nz-iz)]),glass)}
  if(cf.rear){const z=cf.rear.z-.075,xw=Wd/2-.16;mk(polyG([V(xw,cf.rear.y0,z),V(-xw,cf.rear.y0,z),V(-xw,cf.rear.y1,z),V(xw,cf.rear.y1,z)]),glass)}
  if(cf.bed){const[b0,b1]=cf.bed,L=b0-b1,zc=(b0+b1)/2;mk(boxG(Wd-.14,.03,L-.1),plastic,0,1.0,zc);for(const s of[-1,1]){mk(boxG(.07,.24,L),paint,s*(Wd/2-.035),1.1,zc);mk(boxG(.07,.04,L),chrome,s*(Wd/2-.035),1.235,zc)}mk(boxG(Wd,.24,.07),paint,0,1.1,b1+.02)}
  if(cf.slide)for(const s of[-1,1]){mk(boxG(.006,1.25,.012),plastic,s*(Wd/2+.004),1.15,.15);mk(boxG(.006,1.25,.012),plastic,s*(Wd/2+.004),1.15,-1.05);mk(boxG(.008,.025,1.2),chrome,s*(Wd/2+.005),1.9,-.45)}
  else if(!cf.uaz)for(const z of[(cf.ws?cf.ws[0][0]:1)-.08,cf.pill[0]||0])for(const s of[-1,1])mk(boxG(.006,.6,.012),plastic,s*(Wd/2+.004),.9,z);
  if(cf.uaz){const canvasM=std({color:'#4b5236',roughness:1}),xw=Wd/2-.08;mk(polyG([V(-xw,1.22,.78),V(xw,1.22,.78),V(xw,1.8,.7),V(-xw,1.8,.7)]),glass);
    mk(boxG(Wd-.1,.05,.05),paint,0,1.82,.7);for(const s of[-1,1])mk(boxG(.05,.62,.05),paint,s*(Wd/2-.05),1.5,.74);
    mk(rbox(Wd-.02,.8,2.66,.08),canvasM,0,1.58,-.63);for(const s of[-1,1]){mk(planeG(.9,.42),glass,s*(Wd/2+.0),1.66,.1,0,s*Math.PI/2);mk(planeG(.7,.42),glass,s*(Wd/2+.0),1.66,-1.1,0,s*Math.PI/2)}
    mk(planeG(.9,.38),glass,0,1.62,-1.97,0,Math.PI);for(let i=0;i<7;i++)mk(boxG(.05,.32,.03),plastic,-.36+i*.12,.9,zf+.01);
    for(const s of[-1,1]){const h=new T.Mesh(cylG(.1,.1,.06,16),lens);h.rotation.x=Math.PI/2;h.position.set(s*.62,.95,zf-.01);body.add(h)}}
  else{mk(boxG(1.1,.3,.04),plastic,0,.9,zf+.01);for(let i=0;i<4;i++)mk(boxG(1.0,.022,.02),chrome,0,.8+i*.07,zf+.035);for(const s of[-1,1])mk(rbox(.34,.16,.06,.025),lens,s*.66,1.0,zf-.01)}
  for(const s of[-1,1])mk(rbox(.18,.3,.05,.02),tail,s*(Wd/2-.14),1.05,zr+.01);
  mk(rbox(Wd+.1,.24,.22,.05),plastic,0,.6,zf+.02);mk(rbox(Wd+.1,.22,.2,.05),plastic,0,.6,zr-.02);
  const mz=cf.ws?cf.ws[0][0]-.3:.6,my=cf.ws?cf.ws[0][1]+.18:1.38;for(const s of[-1,1]){mk(rbox(.08,.15,.24,.03),plastic,s*(Wd/2+.15),my,mz);mk(boxG(.14,.03,.05),plastic,s*(Wd/2+.07),my-.04,mz)}
  for(const s of[-1,1])for(const z of[cf.w1,cf.w2]){const tr=new T.TorusGeometry(v.wr+.16,.05,6,16,Math.PI);tr.rotateY(Math.PI/2);mk(tr,plastic,s*(Wd/2+.015),cf.c,z)}
  if(cf.spare!=null){const sw=tireMesh(v.wr,.26,rubber,rimM);sw.rotation.y=Math.PI/2;sw.position.set(0,1.15,cf.spare);body.add(sw)}
  if(cf.rack){const[z0,z1,y]=cf.rack;for(const s of[-1,1])mk(beamG(V(s*.75,y,z0),V(s*.75,y,z1),.02),chrome);for(let i=0;i<4;i++)mk(beamG(V(-.75,y+.01,z0+i*(z1-z0)/3),V(.75,y+.01,z0+i*(z1-z0)/3),.015),plastic)}
  if(col.stripe){const yM=std({color:'#ffd500',roughness:.45});mk(boxG(.5,.006,1.2),yM,0,cf.uaz?2.0:(cf.ws?cf.ws[1][1]+.04:1.9),-.2)}
  const dc=document.createElement('canvas');dc.width=128;dc.height=64;const dx=dc.getContext('2d');dx.fillStyle='rgba(235,200,40,.92)';dx.font='bold 46px Arial';dx.textAlign='center';dx.textBaseline='middle';dx.fillText('102',64,34);
  const dt=new T.CanvasTexture(dc);dt.encoding=T.sRGBEncoding;const dm=std({map:dt,transparent:true,roughness:.5});for(const s of[-1,1]){const p=new T.Mesh(planeG(.66,.33),dm);p.position.set(s*(Wd/2+.008),.9,(cf.w1+cf.w2)/2+.2);p.rotation.y=s*Math.PI/2;body.add(p)}
  const wheels=[];for(const[x,z,f]of[[-(Wd/2-.07),cf.w1,1],[(Wd/2-.07),cf.w1,1],[-(Wd/2-.07),cf.w2,0],[(Wd/2-.07),cf.w2,0]]){const piv=new T.Group();piv.position.set(x,cf.c,z);grp.add(piv);const sp=new T.Group();piv.add(sp);sp.add(tireMesh(v.wr,.28,rubber,rimM));wheels.push({piv,sp,f,x,z})}
  const spot=new T.SpotLight(0xfff1c0,0,55,.5,.55,1.3);spot.position.set(0,1.0,zf);const tg=new T.Object3D();tg.position.set(0,-1.5,18);grp.add(spot);grp.add(tg);spot.target=tg;
  return{grp,body,wheels,spot,paint,t}}
/* parked vehicles */
const PARKED={};
function parkCols(p){const v=VT[p.t],fx=Math.sin(p.yaw),fz=Math.cos(p.yaw),k=v.len*.27,r=v.wd*.56;if(p.cols)p.cols.forEach(c=>c.off=true);p.cols=[addCol({t:'c',x:p.x+fx*k,z:p.z+fz*k,r}),addCol({t:'c',x:p.x-fx*k,z:p.z-fz*k,r})]}
function placeParked(t,x,z,yaw,hp){let p=PARKED[t];if(!p){const o=makeCar(t);linearizeAll(o.grp);scene.add(o.grp);p=PARKED[t]={t,obj:o}}p.x=x;p.z=z;p.yaw=yaw;p.hp=hp==null?100:hp;
  const y=H(x,z),fx=Math.sin(yaw),fz=Math.cos(yaw),hf=H(x+fx*1.5,z+fz*1.5),hb=H(x-fx*1.5,z-fz*1.5);p.obj.grp.position.set(x,y,z);p.obj.grp.rotation.set(-Math.atan2(hf-hb,3),yaw,0,'YXZ');p.obj.grp.visible=true;parkCols(p);S.vpos[t]={x,z,yaw,hp:p.hp}}
function spawnParked(){VORDER.forEach((t,i)=>{if(t===S.vact||!S.vun.includes(t))return;const sp=S.vpos[t]||{x:PARKS[i].x,z:PARKS[i].z,yaw:PARKS[i].yaw,hp:100};placeParked(t,sp.x,sp.z,sp.yaw,sp.hp)})}
function unlockVehicle(t){if(S.vun.includes(t))return;S.vun.push(t);if(S.vun.length>=5)grant('garage');const i=VORDER.indexOf(t);placeParked(t,PARKS[i].x,PARKS[i].z,PARKS[i].yaw,100);toast(VT[t].i+' Відкрито: '+VT[t].n+' — стоїть біля «Гаража 102»');persist()}
function switchVehicle(t){const p=PARKED[t];if(!p||t===S.vact)return;const old=S.vact,oldObj=car;
  // park the old one where it is
  PARKED[old]={t:old,obj:oldObj};const op=PARKED[old];op.x=C.x;op.z=C.z;op.yaw=C.yaw;op.hp=C.hp;parkCols(op);S.vpos[old]={x:C.x,z:C.z,yaw:C.yaw,hp:C.hp};
  // take the new one
  p.cols.forEach(c=>c.off=true);delete PARKED[t];car=p.obj;S.vact=t;C.x=p.x;C.z=p.z;C.yaw=p.yaw;C.hp=p.hp;C.v=0;C.y=H(C.x,C.z);
  if(ASSET.pickup&&ASSET.pickup.gltf&&(t==='hilux'||t==='l200'))setTimeout(()=>{try{applyAsset('pickup')}catch(e){}},0)}
function nearParked(){let best=null,bd=3.8;for(const t in PARKED){const p=PARKED[t];if(!p.obj.grp.visible)continue;const d=dist2(P.x,P.z,p.x,p.z);if(d<bd){bd=d;best=t}}return best}
function summonVehicle(t){const fx=Math.sin(P.yaw),fz=Math.cos(P.yaw);let x=P.x+fx*5,z=P.z+fz*5;const o={x,z};resolve(o,1.4);x=o.x;z=o.z;
  if(t===S.vact){C.x=x;C.z=z;C.yaw=P.yaw;C.v=0;C.y=H(x,z)}else if(PARKED[t])placeParked(t,x,z,P.yaw,PARKED[t].hp);toast(VT[t].i+' '+VT[t].n+' поруч')}
/* garage building */
function buildGarage(){const g=GARAGE,y=H(g.x,g.z),B=new Bld();
  B.add('plinthGrey',boxG(17,1.2,8.6),MX(g.x,y-.3,g.z));B.add('brickSil',boxG(16,4.1,8),MX(g.x,y+2.05,g.z));B.add('metalBlue',boxG(16.8,.16,8.9),MX(g.x,y+4.2,g.z,0,-.04));
  for(const dx of[-5,0,5]){const dp=planeG(3.6,3.1);dp.rotateZ(Math.PI/2);B.add('galv',dp,MX(g.x+dx,y+1.6,g.z+4.02));B.add('dark',boxG(3.9,.12,.12),MX(g.x+dx,y+3.2,g.z+4.06))}
  B.add('concrete',polyG([V(g.x-9,y+.02,g.z+4.3),V(g.x+9,y+.02,g.z+4.3),V(g.x+9,y+.02,g.z+11),V(g.x-9,y+.02,g.z+11)].map(p=>(p.y=H(p.x,p.z)+.03,p)).reverse()));
  B.add('dark',beamG(V(g.x+8.5,y,g.z+4.6),V(g.x+8.5,y+3.4,g.z+4.6),.05));
  B.flush(scene);
  const sm=std({map:textTex(512,128,(x,w,h)=>{x.fillStyle='#2c3a1f';x.fillRect(0,0,w,h);x.strokeStyle='#ffd500';x.lineWidth=6;x.strokeRect(6,6,w-12,h-12);x.fillStyle='#ffd500';x.font='bold 64px Arial';x.textAlign='center';x.textBaseline='middle';x.fillText('ГАРАЖ 102',w/2,h/2+3)}),roughness:.6});
  const s=new T.Mesh(planeG(4.4,1.1),sm);s.position.set(g.x,y+3.65,g.z+4.03);scene.add(s);
  addCol({t:'b',x0:g.x-8.1,x1:g.x+8.1,z0:g.z-4.1,z1:g.z+4.1,h:4.4})}
function garageRepair(dt){if(!P.inCar)return;const d=dist2(C.x,C.z,GARAGE.x,GARAGE.z+7);if(d<9&&Math.abs(C.v)<1&&C.hp<100){if(!garageRepair.on)toast('🔧 Гараж 102: ремонтуємо…');garageRepair.on=true;C.hp=Math.min(100,C.hp+22*dt);if(C.hp>=100)toast('✅ Авто відремонтовано')}else garageRepair.on=false}

