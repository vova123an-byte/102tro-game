/* ================= МЕШКАНЦІ, ПОБІЧНІ ЗАВДАННЯ ================= */
if(!S.sq)S.sq={};if(!S.cos)S.cos={bull:[],light:[],snork:[]};if(S.dcol==null)S.dcol=0;if(!S.dcols)S.dcols=[0];
const VIL=[
 {n:'Баба Галя',x:-55,z:roadMain(-55)+5.6,o:{shirt:'#6b4a6a',pants:'#3a3036',cap:'#8a5a6a'},say:['Ой, синку, як добре, що ви є. Спокійніше на душі.','Заходь на вареники з вишнями!','Мурчик знову десь бігає, вітрогон…']},
 {n:'Дід Степан',x:60,z:roadMain(60)-6.5,o:{shirt:'#47453c',pants:'#2f3138',cap:'#3a3936',mustache:true},say:['Мої бджоли цього року — золото, а не бджоли!','У сорок років я на тракторі пів району переорав.','Мед — найкращі ліки, кажу тобі.']},
 {n:'Тітка Оля',x:-60,z:roadMain(-60)-7.6,o:{shirt:'#7a5a3a',pants:'#3a3a4a',cap:'#a04a3a'},say:['Хліб свіжий, молоко з ранку — заходь!','У нас у магазині все є, крім спокою.','Телефон — то біда: вічно десь губиться.']},
 {n:'Пан Василь',x:44,z:roadMain(44)+6.5,o:{shirt:'#3a5a4a',pants:'#2a2d3a',cap:'#2a3a2a',mustache:true},say:['Сільрада — серце села, а люди — його кров.','Хутір звідси видно хіба що з неба.','Паркан у нас старий, як я.']},
 {n:'Андрійко',x:WELL.x+5,z:WELL.z+3,o:{shirt:'#2f6fd6',pants:'#3a3a4a',cap:'#ffd500'},say:['А ти правда на дроні літаєш? Круто!','Коли виросту — теж буду в 102-й!','Мій м’яч знову полетів на поле…']},
 {n:'Фермер Іван',x:M3FARM.x-2,z:M3FARM.z+5,o:{shirt:'#5a4a3a',pants:'#33352f',cap:'#2f3a2a',mustache:true},say:['Трактор після тих запчастин — як новий!','Зорька в мене корова з характером.','Земля тут чорна — хоч на хліб мажи.']},
 {n:'Листоноша Ніна',x:230.4,z:236,o:{shirt:'#2457a8',pants:'#2a2d3a',cap:'#e8c33a'},say:['Пошта працює, хоч що б там було.','Листи — це ниточки між людьми.','Сумка сьогодні важка, як ніколи.']},
 {n:'Бариста Тарас',x:230.4,z:221,o:{shirt:'#3a2a22',pants:'#2a2a2a',cap:'#7a2f22'},say:['Кава за рецептом бабусі — найкраща в Гуляйполі!','Кафе «Ласунка» відчинене для всіх.','Для 102-ї — завжди без черги.']},
 {n:'Механік Сергій',x:249,z:232,o:{shirt:'#3a4a6a',pants:'#2a2d3a',cap:'#2a2d3a'},say:['Гаражі — моє царство.','«Бобик» не ламається — він просто відпочиває.','Шини треба перевіряти перед кожною дорогою.']},
 {n:'Сторож Петро',x:250,z:150,o:{shirt:'#4a4a42',pants:'#2f3138',cap:'#3a3a32',mustache:true},say:['Площа — наше обличчя, тримаємо в чистоті.','Вночі тут тихо — і це добре.','Прапор має майоріти щодня.']}];
const SQS=[
 {g:0,n:'Кіт Мурчик',ty:'fetch',p:[[-74,roadMain(-74)+40]],it:'🐈',d:'Знайди кота Мурчика на городах за хатами й принеси бабі Галі.',rw:[30,30]},
 {g:0,n:'Відро води',ty:'fetch',p:[[WELL.x,WELL.z]],it:'🪣',d:'Набери відро води з криниці в центрі й принеси бабі Галі.',rw:[25,25]},
 {g:1,n:'Пасіка',ty:'visit',p:[[112,-40]],it:'🐝',d:'Перевір вулики діда Степана на полі на схід від села.',rw:[30,30],ret:true},
 {g:1,n:'Яблука для Івана',ty:'deliver',p:[[M3FARM.x-2,M3FARM.z+5]],it:'🍎',d:'Відвези мішок яблук фермеру Івану на хутір за посадкою.',rw:[40,45]},
 {g:2,n:'Загублений телефон',ty:'fetch',p:[[-20,-111]],it:'📱',d:'Тітка Оля загубила телефон у посадці. Знайди його.',rw:[35,35]},
 {g:2,n:'П’ять яблук',ty:'collect',p:[[-92,roadMain(-92)+30],[-86,roadMain(-86)+33],[-98,roadMain(-98)+34],[-106,roadMain(-106)+30],[-81,roadMain(-81)+29]],it:'🍏',d:'Збери 5 яблук у садах за хатами вулиці Садової.',rw:[40,40]},
 {g:3,n:'Фото хутора',ty:'drone',p:[[M3FARM.x,M3FARM.z]],h:15,it:'📷',d:'Пролети дроном над хутором на висоті 15+ м — пан Василь хоче фото для сільради.',rw:[45,45]},
 {g:3,n:'Старий паркан',ty:'visit',p:[[92,roadMain(92)+22]],it:'🔨',d:'Підлатай паркан за сільрадою (підійди пішки).',rw:[30,30],foot:true,ret:true},
 {g:4,n:'М’яч Андрійка',ty:'fetch',p:[[18,64]],it:'⚽',d:'М’яч Андрійка залетів на поле на південь від центру.',rw:[25,25]},
 {g:4,n:'Над посадкою',ty:'drone',p:[[0,-115]],h:12,it:'🛰️',d:'Покажи Андрійку політ: пролети дроном над посадкою на висоті 12+ м.',rw:[35,35]},
 {g:5,n:'Корова Зорька',ty:'fetch',p:[[40,-232]],it:'🐄',d:'Зорька втекла в поле. Знайди її й поверни фермеру Івану.',rw:[40,40]},
 {g:5,n:'Солярка',ty:'deliver',p:[[M3FARM.x-2,M3FARM.z+5]],start:[GARAGE.x,GARAGE.z+7],it:'🛢️',d:'Забери каністру солярки в «Гаражі 102» (зупинись на майданчику) і привези Івану.',rw:[45,50],car:true},
 {g:6,n:'Три листи',ty:'collect',p:[[180,100],[180,176],[270,160]],it:'✉️',d:'Рознеси три листи до приватних будинків Гуляйполя.',rw:[40,40]},
 {g:6,n:'Посилка для Миколи',ty:'deliver',p:[[-223,roadMain(-223)+8.6]],it:'📦',d:'Відвези посилку дядькові Миколі на в’їзд у Малинівку.',rw:[45,50]},
 {g:7,n:'Кава для Ганни',ty:'deliver',p:[[RADA.x-3,RADA.z+2]],it:'☕',d:'Відвези каву голові сільради Ганні, поки гаряча (90 с).',rw:[45,45],t:90},
 {g:7,n:'Старий рецепт',ty:'fetch',p:[[215,142]],it:'📜',d:'Знайди стару газету з рецептом біля пошкодженої п’ятиповерхівки.',rw:[35,35]},
 {g:8,n:'Огляд шин',ty:'visit',p:[[GARAGE.x,GARAGE.z+7]],it:'🛞',d:'Під’їдь на будь-якому авто до «Гаража 102» у Малинівці й зупинись.',rw:[30,35],car:true,ret:false},
 {g:8,n:'Перегін до Малинівки',ty:'visit',p:[[WELL.x,WELL.z+6]],it:'⏱️',d:'Доїдь від гаражів Гуляйполя до криниці в Малинівці за 70 секунд.',rw:[50,60],car:true,t:70,ret:false},
 {g:9,n:'Прапор на площі',ty:'visit',p:[[251,154]],it:'🇺🇦',d:'Перевір прапор на площі (підійди до флагштока).',rw:[25,25],foot:true,ret:true},
 {g:9,n:'Нічний обхід',ty:'collect',p:[[205,70],[265,130],[205,250]],it:'🔦',d:'Обійди три перехрестя Гуляйполя й переконайся, що все спокійно.',rw:[40,40]}];
SQS.forEach((q,i)=>q.id=i);
let SQ=null,VILN=[];
function spawnVillagers(){VILN=VIL.map((v,i)=>{const h=makeHuman(Object.assign({pants:'#2f3138'},v.o));linearizeAll(h.grp);h.grp.position.set(v.x,H(v.x,v.z),v.z);scene.add(h.grp);addCol({t:'c',x:v.x,z:v.z,r:.35});
  const mk=new T.Mesh(new T.ConeGeometry(.16,.4,4),std({color:'#ffd500',emissive:'#8a7000'}));mk.rotation.x=Math.PI;mk.position.y=2.35;h.grp.add(mk);h.mark=mk;return h})}
function villagerNear(){for(let i=0;i<VIL.length;i++){if(dist2(P.x,P.z,VIL[i].x,VIL[i].z)<3)return i}return-1}
function sqAvailFor(g){return SQS.filter(q=>q.g===g&&!S.sq[q.id])}
function sqItem(x,z){const g=new T.Group(),m=std({color:'#ffd500',emissive:'#7a6400',roughness:.4}),b=new T.Mesh(new T.OctahedronGeometry(.32,0),m);g.add(b);g.position.set(x,H(x,z)+1,z);scene.add(g);return g}
function sqClear(){if(SQ&&SQ.marks)SQ.marks.forEach(m=>scene.remove(m));SQ=null}
function sqStart(q){sqClear();SQ={q,got:[],stage:q.start?0:1,t0:gameT,marks:[]};if(!q.start||SQ.stage>0)sqMarks();toast(q.it+' Завдання: '+q.n)}
function sqMarks(){const q=SQ.q;SQ.marks.forEach(m=>scene.remove(m));SQ.marks=[];if(q.ty==='fetch'||q.ty==='collect')q.p.forEach((p,i)=>{if(!SQ.got.includes(i))SQ.marks.push(sqItem(p[0],p[1]))})}
function sqDone(q){S.sq[q.id]=2;addXP(q.rw[0]);S.coins+=q.rw[1];SFX.win();toast(`✅ ${q.n}: +${q.rw[0]} досвіду, +${q.rw[1]} 🪙`);const n=Object.values(S.sq).filter(v=>v===2).length;if(n>=10)grant('side10');if(n>=20)grant('side20');sqClear();persist()}
function talkVillager(i){const v=VIL[i];S.stats.talk++;grant('talk');
  if(SQ&&SQ.q.g===i&&SQ.ready){const q=SQ.q;showDialog([{w:v.n,t:'Ох, дякую тобі, {cs}! '+['Виручив!','Ти золото, а не боєць!','Спасибі від щирого серця.'][q.id%3]}],()=>sqDone(q));return}
  if(SQ&&SQ.q.g===i){showDialog([{w:v.n,t:'Ну що, {cs}? '+SQ.q.d}]);return}
  const av=sqAvailFor(i);if(av.length&&!(mis&&mis.id)&&!SQ){const q=av[0];showDialog([{w:v.n,t:v.say[q.id%v.say.length]},{w:v.n,t:'{cs}, допоможеш? '+q.d+`\nНагорода: ${q.rw[1]} 🪙 і ${q.rw[0]} досвіду.`}],()=>sqStart(q));return}
  if(av.length&&(SQ||mis))toast(SQ?'Спершу заверши поточне побічне завдання':'Побічні завдання — після поточної місії або у вільному світі');
  showDialog([{w:v.n,t:v.say[(Math.random()*v.say.length)|0]}])}
function sqObjective(){if(!SQ)return null;const q=SQ.q;const left=q.t?Math.max(0,q.t-(gameT-SQ.t0)):null,tt=left!=null?` · ⏱ ${Math.ceil(left)} с`:'';
  if(SQ.ready)return{t:'ЗАВДАННЯ · '+q.n.toUpperCase(),d:'Повернись до: '+VIL[q.g].n+tt,tg:V3(VIL[q.g].x,VIL[q.g].z)};
  if(SQ.stage===0)return{t:'ЗАВДАННЯ · '+q.n.toUpperCase(),d:'Забери вантаж у «Гаражі 102» (зупинись на майданчику)',tg:V3(q.start[0],q.start[1])};
  const idx=q.p.findIndex((p,i)=>!SQ.got.includes(i)),p=q.p[Math.max(0,idx)];return{t:'ЗАВДАННЯ · '+q.n.toUpperCase(),d:q.d+(q.ty==='collect'?` (${SQ.got.length}/${q.p.length})`:'')+tt,tg:V3(p[0],p[1])}}
function updSide(dt){VILN.forEach((h,i)=>{if(h.mark){h.mark.visible=(!SQ&&!mis&&sqAvailFor(i).length>0)||(SQ&&SQ.q.g===i&&SQ.ready);h.mark.rotation.y+=dt*2;h.mark.position.y=2.35+Math.sin(gameT*3+i)*.08}const v=VIL[i],d=dist2(P.x,P.z,v.x,v.z);if(d<14)h.grp.rotation.y=lerpA(h.grp.rotation.y,Math.atan2(P.x-v.x,P.z-v.z),dt*3);h.head.rotation.z=Math.sin(gameT*.7+i)*.05});
  if(!inTown(P.x,P.z)){}else grant('town');
  if(!SQ)return;const q=SQ.q;SQ.marks.forEach((m,i)=>{m.rotation.y+=dt*2});
  if(q.t&&!SQ.ready&&gameT-SQ.t0>q.t){toast('⏱ Час вийшов — завдання «'+q.n+'» можна взяти знову');sqClear();return}
  if(SQ.ready)return;const px=P.inCar?C.x:P.x,pz=P.inCar?C.z:P.z,r=P.inCar?6.5:2.6;
  if(SQ.stage===0){if(stopped(q.start[0],q.start[1],9)){SQ.stage=1;SFX.pick();toast(q.it+' Вантаж забрано')}return}
  const fin=()=>{if(q.ty==='fetch'||q.ty==='collect'||q.ret)SQ.ready=true,toast(q.it+' Готово! Повернись до: '+VIL[q.g].n);else sqDone(q)};
  if(q.ty==='drone'){if(D.on&&dist2(D.x,D.z,q.p[0][0],q.p[0][1])<12&&D.y-H(D.x,D.z)>=q.h){SFX.ring();fin()}return}
  if(q.car&&!P.inCar)return;if(q.foot&&P.inCar)return;
  q.p.forEach((p,i)=>{if(SQ&&!SQ.ready&&!SQ.got.includes(i)&&dist2(px,pz,p[0],p[1])<r){SQ.got.push(i);SFX.pick();if(SQ.marks.length)sqMarks();if(q.ty==='collect'&&SQ.got.length<q.p.length)toast(`${q.it} ${SQ.got.length}/${q.p.length}`);else fin()}})}
/* косметика авто й дронів */
const COS=[{k:'bull',n:'Кенгурятник',i:'🛡️',c:120},{k:'light',n:'Світлова балка на дах',i:'💡',c:150},{k:'snork',n:'Шнорхель',i:'🌊',c:90}];
const DCOL=[{n:'Графіт',c:'#2a2d30',cost:0},{n:'Олива',c:'#4f5a3c',cost:60},{n:'Пісок',c:'#9a8a62',cost:60},{n:'Синьо-жовтий',c:'#2357b8',cost:120}];
function carExtras(o,t){const v=VT[t]||VT.hilux,zf=v.len/2+.1,top=t==='van'?2.04:t==='uaz'?2.0:t==='patrol'?2.0:1.92,bm=std({color:'#1d1e1f',roughness:.5,metalness:.6}),add=(g,m,x,y,z)=>{const me=new T.Mesh(g,m);me.position.set(x,y,z);me.castShadow=true;o.body.add(me)};
  if(S.cos.bull.includes(t)){for(const s of[-1,1])add(beamG(V(s*.55,.45,zf),V(s*.5,1.15,zf+.12),.04),bm,0,0,0);add(beamG(V(-.6,1.1,zf+.12),V(.6,1.1,zf+.12),.04),bm,0,0,0);add(beamG(V(-.7,.62,zf+.15),V(.7,.62,zf+.15),.045),bm,0,0,0)}
  if(S.cos.light.includes(t)){add(rbox(1.2,.1,.16,.03),bm,0,top+.07,v.len*.12);add(boxG(1.1,.06,.02),std({color:'#fff6d8',emissive:'#8a8060',roughness:.2}),0,top+.07,v.len*.12+.09)}
  if(S.cos.snork.includes(t)){const x=v.wd/2+.04,z=v.len*.24;add(beamG(V(x,.8,z),V(x,top-.05,z-.2),.045),bm,0,0,0);add(boxG(.12,.12,.16),bm,x,top,z-.25)}}

