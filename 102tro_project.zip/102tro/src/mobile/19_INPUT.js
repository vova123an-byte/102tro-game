/* ================= INPUT ================= */
const inp={jx:0,jy:0,jm:0,steer:0,gas:false,brake:false,run:false,crouch:false};
const edge={};
const joy={id:null,bx:0,by:0,x:0,y:0},look={id:null,x:0,y:0},wh={id:null,x0:0,ang:0};
const touch=$('#touch');
touch.addEventListener('pointerdown',e=>{if(state!=='play')return;e.preventDefault();initAudio();
  if(e.clientX<window.innerWidth*.45){ if(P.inCar){if(wh.id===null){wh.id=e.pointerId;wh.x0=e.clientX}} else if(joy.id===null){joy.id=e.pointerId;joy.bx=joy.x=e.clientX;joy.by=joy.y=e.clientY} }
  else if(look.id===null){look.id=e.pointerId;look.x=e.clientX;look.y=e.clientY}
  try{touch.setPointerCapture(e.pointerId)}catch(_){}});
touch.addEventListener('pointermove',e=>{
  if(e.pointerId===joy.id){joy.x=e.clientX;joy.y=e.clientY}
  else if(e.pointerId===wh.id){wh.ang=clamp((e.clientX-wh.x0)/70,-1,1)}
  else if(e.pointerId===look.id){const dx=e.clientX-look.x,dy=e.clientY-look.y;look.x=e.clientX;look.y=e.clientY;cam.yaw-=dx*.0065*S.sens;cam.pitch=clamp(cam.pitch+dy*.005*S.sens,-.05,1.15);cam.lastDrag=gameT}});
const tEnd=e=>{if(e.pointerId===joy.id)joy.id=null;if(e.pointerId===wh.id){wh.id=null;wh.ang=0}if(e.pointerId===look.id)look.id=null};
touch.addEventListener('pointerup',tEnd);touch.addEventListener('pointercancel',tEnd);
$$('[data-k]').forEach(b=>{const k=b.dataset.k;
  b.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();initAudio();
    if(k==='run'){inp.run=!inp.run;b.classList.toggle('tog',inp.run);return}
    if(k==='crouch'){inp.crouch=!inp.crouch;b.classList.toggle('tog',inp.crouch);return}
    inp[k]=true;edge[k]=true;b.classList.add('on')});
  const off=e=>{if(k==='run'||k==='crouch')return;inp[k]=false;b.classList.remove('on')};
  ['pointerup','pointercancel','pointerleave'].forEach(t=>b.addEventListener(t,off))});
const keys={};
addEventListener('keydown',e=>{if(e.target.tagName==='INPUT')return;keys[e.code]=true;
  if(state!=='play'){if(state==='dialog'&&(e.code==='Space'||e.code==='Enter'))dlgNext();return}
  if(e.code==='Space')edge.jump=true;if(e.code==='KeyE'||e.code==='KeyF'){edge.act=true;edge.exit=true}if(e.code==='KeyC'){inp.crouch=!inp.crouch;$('#bCrouch').classList.toggle('tog',inp.crouch)}
  if(e.code==='KeyH')edge.horn=true;if(e.code==='KeyV'){edge.dcam=true;edge.ccam=true}if(e.code==='KeyL')edge.lights=true;if(e.code==='KeyQ')edge.drone=true;if(e.code==='Escape'||e.code==='KeyP')pauseGame()});
addEventListener('keyup',e=>{keys[e.code]=false});
function readInput(){
  // joystick
  if(joy.id!==null){const dx=joy.x-joy.bx,dy=joy.y-joy.by,d=Math.hypot(dx,dy),R=55;if(d>R){joy.bx=joy.x-dx/d*R;joy.by=joy.y-dy/d*R}const m=Math.min(1,d/R);inp.jm=m<.12?0:m;inp.jx=d?dx/d*inp.jm:0;inp.jy=d?dy/d*inp.jm:0}else{inp.jx=inp.jy=inp.jm=0}
  const kx=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0),ky=(keys.KeyS||keys.ArrowDown?1:0)-(keys.KeyW||keys.ArrowUp?1:0);
  if(!P.inCar&&(kx||ky)){const l=Math.hypot(kx,ky);inp.jx=kx/l;inp.jy=ky/l;inp.jm=1}
  {const jb=$('#joyB'),jk=$('#joyK');if(joy.id!==null){jb.style.left=joy.bx+'px';jb.style.top=joy.by+'px';jb.style.opacity=1;jk.style.transform=`translate(${joy.x-joy.bx}px,${joy.y-joy.by}px)`}else{jb.style.left='calc(85px + env(safe-area-inset-left))';jb.style.top=(window.innerHeight-90)+'px';jb.style.opacity=.4;jk.style.transform='none'}}
  inp.steer=wh.id!==null?wh.ang:0;if(P.inCar&&kx)inp.steer=kx;
  inp.gasK=P.inCar&&ky<0;inp.brakeK=P.inCar&&ky>0;
  if(keys.ShiftLeft||keys.ShiftRight)inp.runK=true;else inp.runK=false;
}

