/* ================= CHARACTERS ================= */
function camoTex(base,cols){const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d');x.fillStyle=base;x.fillRect(0,0,64,64);const R=rngS(cols.length*31+base.length);
  for(let i=0;i<70;i++){x.fillStyle=cols[R()*cols.length|0];const px=(R()*16|0)*4,py=(R()*16|0)*4;x.fillRect(px,py,4*(1+(R()*3|0)),4*(1+(R()*2|0)))}
  const t=new T.CanvasTexture(c);t.magFilter=T.NearestFilter;t.wrapS=t.wrapT=T.RepeatWrapping;return t}
const SKINS=[{n:'Піксель ММ-14',base:'#8a8665',c:['#5c6042','#46422f','#6e7150','#a39f80'],helm:'#5d6340',cost:0},
  {n:'Мультикам',base:'#9e8e6c',c:['#6a6944','#7c694b','#c1ac86','#4e4932'],helm:'#7d7050',cost:150},
  {n:'Зимовий',base:'#c8cac2',c:['#9ea29a','#e6e7e1','#7c817a','#b4b7ae'],helm:'#b8bcb4',cost:300}];
function makeHumanOld(o){
  const grp=new T.Group(),body=new T.Group();grp.add(body);
  const cm=o.camo?new T.MeshLambertMaterial({map:camoTex(o.camo.base,o.camo.c)}):new T.MeshLambertMaterial({color:o.shirt});
  const pm=o.camo?cm:new T.MeshLambertMaterial({color:o.pants});
  const skin=new T.MeshLambertMaterial({color:0xe2b58e}),boot=new T.MeshLambertMaterial({color:0x2a2620});
  const mk=(g,m,x,y,z,sx,sy,sz,par)=>{const me=new T.Mesh(g,m);me.position.set(x,y,z);me.scale.set(sx,sy,sz);me.castShadow=true;(par||body).add(me);return me};
  const hips=new T.Group();hips.position.y=.95;body.add(hips);
  const legs=[];for(const sx of[-.13,.13]){const lg=new T.Group();lg.position.set(sx,0,0);hips.add(lg);mk(GEO.box,pm,0,-.42,0,.2,.84,.24,lg);mk(GEO.box,boot,0,-.88,.04,.22,.14,.32,lg);legs.push(lg)}
  const torso=mk(GEO.box,cm,0,1.27,0,.52,.62,.3);
  const arms=[];for(const sx of[-.34,.34]){const a=new T.Group();a.position.set(sx,1.52,0);body.add(a);mk(GEO.box,cm,0,-.3,0,.15,.6,.17,a);mk(GEO.box,skin,0,-.65,0,.13,.13,.13,a);arms.push(a)}
  const head=new T.Group();head.position.y=1.72;body.add(head);mk(GEO.box,skin,0,.13,0,.26,.28,.26,head);
  if(o.helm){mk(GEO.ico1,new T.MeshLambertMaterial({color:o.helm}),0,.25,0,.21,.16,.22,head);
    mk(GEO.box,new T.MeshLambertMaterial({color:0x2a2a2a}),0,.16,.14,.2,.04,.02,head);
    mk(GEO.box,new T.MeshLambertMaterial({color:o.camo?o.camo.c[0]:0x444444}),0,1.27,-.24,.42,.5,.18); // backpack
    const fl=new T.Mesh(new T.PlaneGeometry(.12,.08),new T.MeshBasicMaterial({map:flagTex(),side:T.DoubleSide}));fl.position.set(.345,1.45,.01);fl.rotation.y=Math.PI/2;body.add(fl);
    const fl2=fl.clone();fl2.position.x=-.345;fl2.rotation.y=-Math.PI/2;body.add(fl2);}
  if(o.cap){mk(GEO.cylB,new T.MeshLambertMaterial({color:o.cap}),0,.24,0,.3,.1,.3,head);mk(GEO.box,new T.MeshLambertMaterial({color:o.cap}),0,.26,.16,.26,.03,.14,head)}
  if(o.mustache)mk(GEO.box,new T.MeshLambertMaterial({color:0xd8d8d0}),0,.06,.135,.16,.04,.02,head);
  // eyes
  for(const sx of[-.06,.06])mk(GEO.box,new T.MeshBasicMaterial({color:0x111111}),sx,.15,.131,.035,.035,.01,head);
  return{grp,body,legs,arms,head,torso,hips,cm};
}
let flagT=null;function flagTex(){if(flagT)return flagT;const c=document.createElement('canvas');c.width=64;c.height=42;const x=c.getContext('2d');x.fillStyle='#2f6fd6';x.fillRect(0,0,64,21);x.fillStyle='#ffd500';x.fillRect(0,21,64,21);flagT=new T.CanvasTexture(c);return flagT}

