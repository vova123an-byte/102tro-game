/* ================= NEW CHARACTER & PICKUP MODELS ================= */
function makeHuman(o){
  const grp=new T.Group(),body=new T.Group();grp.add(body);const mil=!!o.camo;
  const camoT=mil?texCamo(o.camo):null;
  const cloth=mil?std({map:camoT,roughness:.92}):std({color:o.shirt,roughness:.95});
  const pantsM=mil?cloth:std({color:o.pants,roughness:.95});
  const skin=std({color:'#c49a7e',roughness:.65}),boot=std({color:'#2b251f',roughness:.55}),dark=std({color:'#24251f',roughness:.6}),glove=std({color:'#3d3a2c',roughness:.85});
  const vest=std({color:mil?'#5c5a42':'#3a3934',roughness:.88}),helmM=mil?std({map:camoT,color:'#d8d4c4',roughness:.85}):null;
  const mk=(geo,m,x,y,z,par,rx,ry,rz)=>{const me=new T.Mesh(geo,m);me.position.set(x,y,z);me.rotation.set(rx||0,ry||0,rz||0);me.castShadow=true;me.receiveShadow=true;(par||body).add(me);return me};
  const hips=new T.Group();hips.position.y=.95;body.add(hips);
  mk(rbox(.36,.22,.24,.07),pantsM,0,0,0,hips);
  const legs=[],knees=[];
  for(const sx of[-.1,.1]){const lg=new T.Group();lg.position.set(sx,0,0);hips.add(lg);
    mk(cylG(.068,.088,.46,10),pantsM,0,-.23,0,lg);
    const kn=new T.Group();kn.position.y=-.46;lg.add(kn);mk(new T.SphereGeometry(.07,10,8),pantsM,0,0,0,kn);
    if(mil)mk(rbox(.12,.14,.07,.03),dark,0,-.02,.06,kn);
    mk(cylG(.052,.066,.42,10),pantsM,0,-.21,0,kn);
    mk(rbox(.12,.13,.28,.045),boot,0,-.43,.035,kn);mk(boxG(.13,.03,.3),dark,0,-.49,.035,kn);
    legs.push(lg);knees.push(kn)}
  const torso=mk(rbox(.38,.5,.23,.09),cloth,0,1.28,0);
  if(mil){mk(rbox(.42,.34,.31,.05),vest,0,1.32,0);
    for(const x of[-.12,0,.12])mk(rbox(.1,.15,.06,.02),vest,x,1.24,.18);mk(rbox(.08,.12,.05,.02),vest,.15,1.42,.17);
    mk(rbox(.3,.38,.15,.05),std({color:'#4f4d38',roughness:.9}),0,1.32,-.23);mk(boxG(.26,.04,.12),dark,0,1.53,-.23);
    const fl=new T.Mesh(planeG(.09,.06),new T.MeshBasicMaterial({map:flagTex(),side:T.DoubleSide}));fl.position.set(.235,1.43,.0);fl.rotation.y=Math.PI/2;body.add(fl);const fl2=fl.clone();fl2.position.x=-.235;fl2.rotation.y=-Math.PI/2;body.add(fl2)}
  else{mk(rbox(.41,.36,.27,.07),vest,0,1.3,0)}
  const arms=[],elbows=[];
  for(const sx of[-.235,.235]){const a=new T.Group();a.position.set(sx,1.5,0);body.add(a);mk(new T.SphereGeometry(.075,10,8),cloth,0,0,0,a);
    mk(cylG(.052,.064,.3,9),cloth,0,-.15,0,a);const el=new T.Group();el.position.y=-.3;a.add(el);
    mk(cylG(.044,.052,.27,9),cloth,0,-.135,0,el);mk(rbox(.08,.1,.06,.025),mil?glove:skin,0,-.3,0,el);arms.push(a);elbows.push(el)}
  mk(cylG(.055,.06,.1,10),skin,0,1.58,0);
  const head=new T.Group();head.position.y=1.63;body.add(head);
  const hm=mk(new T.SphereGeometry(.105,16,12),skin,0,.11,.0,head);hm.scale.set(.92,1.08,1);
  mk(boxG(.03,.04,.04),skin,0,.1,.105,head);for(const s of[-1,1])mk(new T.SphereGeometry(.025,8,6),skin,s*.1,.1,0,head);
  if(mil){mk(new T.SphereGeometry(.142,18,10,0,Math.PI*2,0,Math.PI*.52),helmM,0,.13,-.005,head);mk(new T.TorusGeometry(.136,.012,6,24),helmM,0,.135,-.005,head,Math.PI/2);
    mk(boxG(.17,.045,.02),std({color:'#111',roughness:.1,metalness:.5}),0,.135,.104,head);
    mk(cylG(.1,.107,.1,14),std({color:'#55573e',roughness:1}),0,.03,.006,head);
    mk(rbox(.09,.06,.05,.015),dark,0,.24,-.12,head)}
  else{mk(cylG(.115,.112,.07,14),std({color:o.cap,roughness:.9}),0,.2,0,head);mk(boxG(.2,.015,.1),std({color:o.cap,roughness:.9}),0,.17,.1,head,.15);
    for(const s of[-1,1])mk(new T.SphereGeometry(.013,6,5),std({color:'#1a1512'}),s*.035,.125,.098,head);
    if(o.mustache)mk(rbox(.08,.022,.02,.008),std({color:'#cfcac0',roughness:1}),0,.07,.1,head);
    mk(boxG(.03,.008,.01),std({color:'#cfcac0'}),-.035,.145,.1,head);mk(boxG(.03,.008,.01),std({color:'#cfcac0'}),.035,.145,.1,head)}
  return{grp,body,legs,arms,head,torso,hips,knees,elbows};
}
function makeCar(t){t=t||S.vact||'hilux';const o=t!=='hilux'?makeVehicleT(t):makeHilux();try{carExtras(o,t)}catch(e){}return o}
function makeHilux(){
  const grp=new T.Group(),body=new T.Group();grp.add(body);
  const col=CARCOL[vehColor('hilux')]||CARCOL[0];
  const paint=std({map:texPaint(col.c,col.camo),roughness:.45,metalness:.35,envMapIntensity:.9});
  const plastic=std({color:'#242526',roughness:.72}),chrome=std({color:'#c8ccce',roughness:.22,metalness:.9}),glass=std({color:'#121719',roughness:.04,metalness:.2,envMapIntensity:1.7});
  const lens=std({color:'#f2ecd6',emissive:'#4a4330',roughness:.15}),tail=std({color:'#8a1612',emissive:'#2a0000',roughness:.3}),rimM=std({color:'#5d605e',roughness:.4,metalness:.7}),rubber=std({color:'#171717',roughness:.93});
  const mk=(g,m,x,y,z,rx,ry,rz)=>{const me=new T.Mesh(g,m);me.position.set(x||0,y||0,z||0);me.rotation.set(rx||0,ry||0,rz||0);me.castShadow=true;me.receiveShadow=true;body.add(me);return me};
  const Wd=1.86,bev=.06,wz1=1.62,wz2=-1.6,wc=.45,ar=.58;
  const prof=[[-2.56,.52],[wz2-ar,.52],...arcPts(wz2,wc,ar,Math.PI,0,9),[wz1-ar,.52],...arcPts(wz1,wc,ar,Math.PI,0,9),[2.5,.52],[2.6,.66],[2.62,.98],[2.55,1.12],[1.3,1.22],[.48,1.86],[-.55,1.9],[-.7,1.84],[-.74,.98],[-2.56,.98]];
  mk(extrudeProfile(prof,Wd,bev),paint);
  mk(extrudeProfile([[-.62,1.2],[1.12,1.25],[.52,1.8],[-.54,1.83]],Wd+.012,0),glass);
  mk(boxG(.012,.62,.09),plastic,Wd/2+.007,1.5,.3);mk(boxG(.012,.62,.09),plastic,-Wd/2-.007,1.5,.3);
  mk(polyG([V(-.8,1.3,1.3),V(.8,1.3,1.3),V(.8,1.86,.58),V(-.8,1.86,.58)]),glass);
  mk(polyG([V(.72,1.3,-.81),V(-.72,1.3,-.81),V(-.72,1.76,-.81),V(.72,1.76,-.81)]),glass);
  // bed
  mk(boxG(Wd-.14,.03,1.78),plastic,0,1.0,-1.66);for(const s of[-1,1])mk(boxG(.07,.24,1.84),paint,s*(Wd/2-.035),1.1,-1.66);mk(boxG(Wd,.24,.07),paint,0,1.1,-2.59);
  for(const s of[-1,1])mk(boxG(.07,.04,1.84),chrome,s*(Wd/2-.035),1.235,-1.66);
  // door seams & handles
  for(const z of[1.18,.32,-.64])for(const s of[-1,1])mk(boxG(.006,.62,.012),plastic,s*(Wd/2+.004),.88,z);
  for(const z of[.75,-.12])for(const s of[-1,1])mk(boxG(.02,.035,.16),chrome,s*(Wd/2+.01),1.12,z);
  // front: grille, lights, bumper
  mk(boxG(1.18,.3,.04),plastic,0,.9,2.69);for(let i=0;i<4;i++)mk(boxG(1.1,.022,.02),chrome,0,.8+i*.07,2.715);
  for(const s of[-1,1]){mk(rbox(.36,.17,.06,.025),lens,s*.67,1.0,2.67);mk(rbox(.12,.08,.04,.015),lens,s*.62,.62,2.79);mk(rbox(.2,.32,.05,.02),tail,s*.83,1.05,-2.64)}
  mk(rbox(1.98,.24,.22,.05),plastic,0,.62,2.69);mk(rbox(1.98,.22,.2,.05),plastic,0,.62,-2.66);mk(boxG(.24,.05,.1),chrome,0,.62,-2.78);
  // mirrors, roof rails, flares, mud flaps
  for(const s of[-1,1]){mk(rbox(.08,.15,.24,.03),plastic,s*(Wd/2+.15),1.42,.98);mk(boxG(.14,.03,.05),plastic,s*(Wd/2+.07),1.38,1.0);
    mk(beamG(V(s*.7,1.98,-.45),V(s*.7,1.98,.9),.018),chrome);
    for(const z of[wz1,wz2]){const t=new T.TorusGeometry(.6,.05,6,16,Math.PI);t.rotateY(Math.PI/2);mk(t,plastic,s*(Wd/2+.015),wc,z)}
    mk(boxG(.02,.26,.22),rubber,s*(Wd/2-.12),.35,wz1-.72);mk(boxG(.02,.26,.22),rubber,s*(Wd/2-.12),.35,wz2-.72)}
  if(col.stripe){const y=std({color:'#ffd500',roughness:.45});mk(boxG(.5,.006,1.0),y,0,1.965,.2);mk(boxG(.5,.006,1.1),y,0,1.2,1.92,0,0,0)}
  // 102 decals
  const dc=document.createElement('canvas');dc.width=128;dc.height=64;const dx=dc.getContext('2d');dx.fillStyle='rgba(235,200,40,.92)';dx.font='bold 46px Arial';dx.textAlign='center';dx.textBaseline='middle';dx.fillText('102',64,34);
  const dt=new T.CanvasTexture(dc);dt.encoding=T.sRGBEncoding;const dm=std({map:dt,transparent:true,roughness:.5});
  for(const s of[-1,1]){const p=new T.Mesh(planeG(.7,.35),dm);p.position.set(s*(Wd/2+.008),.88,.72);p.rotation.y=s*Math.PI/2;body.add(p)}
  // wheels
  const wheels=[];for(const[x,z,f]of[[-.86,wz1,1],[.86,wz1,1],[-.86,wz2,0],[.86,wz2,0]]){const piv=new T.Group();piv.position.set(x,wc,z);grp.add(piv);const sp=new T.Group();piv.add(sp);sp.add(tireMesh(.44,.3,rubber,rimM));wheels.push({piv,sp,f,x,z})}
  const spot=new T.SpotLight(0xfff1c0,0,55,.5,.55,1.3);spot.position.set(0,1.0,2.6);const tg=new T.Object3D();tg.position.set(0,-1.5,18);grp.add(spot);grp.add(tg);spot.target=tg;
  return{grp,body,wheels,spot,paint,t:'hilux'};
}

